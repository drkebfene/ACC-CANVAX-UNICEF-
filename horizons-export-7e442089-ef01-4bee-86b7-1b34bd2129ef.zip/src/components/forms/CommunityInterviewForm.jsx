import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save, PlusCircle, Trash2, CalendarDays, MapPin, Users, MessageSquare, Info, Lightbulb, AlertTriangle, Smile, ThumbsUp, ClipboardEdit } from 'lucide-react';

const SectionTitle = ({ icon, title }) => (
  <div className="flex items-center text-xl font-semibold text-yellow-300 mb-4 mt-6">
    {React.cloneElement(icon, { className: "mr-3 h-6 w-6 text-yellow-400" })}
    {title}
  </div>
);

const FormRow = ({ children }) => <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">{children}</div>;
const FullWidthFormRow = ({ children }) => <div className="mb-4">{children}</div>;

const defaultQuestionAnswer = { question: '', reponse: '', observations: '' };

const defaultDynamicRow = {
  connaissances_informations: defaultQuestionAnswer,
  perception_services: defaultQuestionAnswer,
  barrieres_obstacles: defaultQuestionAnswer,
  rumeurs_fausses_croyances: defaultQuestionAnswer,
  engagement_communautaire: defaultQuestionAnswer,
  experiences_personnelles: defaultQuestionAnswer,
  suggestions_amelioration: defaultQuestionAnswer,
};

const CommunityInterviewForm = ({ onSubmit, initialData, readOnly = false }) => {
  const [formData, setFormData] = useState(
    initialData ? 
    { 
      ...initialData,
      ...Object.keys(defaultDynamicRow).reduce((acc, key) => {
        acc[key] = (initialData[key] && initialData[key].length > 0) ? initialData[key] : [defaultDynamicRow[key]];
        return acc;
      }, {})
    } 
    : {
      localite: '', district_sanitaire: '', province: '', date_entretien: new Date().toISOString().slice(0,10),
      type_entretien: '', nom_enqueteur: '', nombre_participants: '',
      connaissances_informations: [defaultDynamicRow.connaissances_informations],
      perception_services: [defaultDynamicRow.perception_services],
      barrieres_obstacles: [defaultDynamicRow.barrieres_obstacles],
      rumeurs_fausses_croyances: [defaultDynamicRow.rumeurs_fausses_croyances],
      engagement_communautaire: [defaultDynamicRow.engagement_communautaire],
      experiences_personnelles: [defaultDynamicRow.experiences_personnelles],
      suggestions_amelioration: [defaultDynamicRow.suggestions_amelioration],
      observations_facilitateur: '',
      status: 'Brouillon',
  });

  useEffect(() => {
    if (initialData) {
      const updatedFormData = { ...initialData };
      Object.keys(defaultDynamicRow).forEach(key => {
        if (!updatedFormData[key] || updatedFormData[key].length === 0) {
          updatedFormData[key] = [defaultDynamicRow[key]];
        }
      });
      setFormData(updatedFormData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    if (readOnly) return;
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseInt(value) || 0 : value }));
  };
  
  const handleSelectChange = (name, value) => {
    if (readOnly) return;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDynamicRowChange = (section, index, e) => {
    if (readOnly) return;
    const { name, value } = e.target;
    const updatedSection = [...formData[section]];
    updatedSection[index] = { ...updatedSection[index], [name]: value };
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const addDynamicRow = (section) => {
    if (readOnly) return;
    setFormData(prev => ({
      ...prev,
      [section]: [...(prev[section] || []), defaultDynamicRow[section]]
    }));
  };

  const removeDynamicRow = (section, index) => {
    if (readOnly) return;
    if (formData[section].length <= 1 && Object.keys(defaultDynamicRow).includes(section) ) return; 
    const updatedSection = formData[section].filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    onSubmit(formData);
  };

  const renderDynamicSection = (sectionKey, title, icon) => (
    <>
      <SectionTitle icon={icon} title={title} />
      {formData[sectionKey]?.map((item, index) => (
        <div key={`${sectionKey}-${index}`} className="p-4 border border-slate-600 rounded-md mb-4 bg-slate-800/30 relative">
          <h4 className="font-semibold text-lg mb-3 text-amber-400">Point {index + 1}</h4>
          {!readOnly && formData[sectionKey].length > 1 && (
            <Button type="button" variant="destructive" size="sm" onClick={() => removeDynamicRow(sectionKey, index)} className="absolute top-4 right-4">
              <Trash2 className="h-4 w-4 mr-1" /> Supprimer
            </Button>
          )}
          <div className="mb-3">
            <Label htmlFor={`${sectionKey}-${index}-question`}>Question / Sujet Clé</Label>
            <Textarea name="question" id={`${sectionKey}-${index}-question`} value={item.question || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Entrez la question ou le sujet abordé"/>
          </div>
          <div className="mb-3">
            <Label htmlFor={`${sectionKey}-${index}-reponse`}>Réponse / Discussion</Label>
            <Textarea name="reponse" id={`${sectionKey}-${index}-reponse`} value={item.reponse || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Notez les réponses, verbatims, points clés de la discussion"/>
          </div>
           <div className="mb-3">
            <Label htmlFor={`${sectionKey}-${index}-observations`}>Observations du facilitateur</Label>
            <Textarea name="observations" id={`${sectionKey}-${index}-observations`} value={item.observations || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Attitudes, non-dits, dynamique de groupe..."/>
          </div>
        </div>
      ))}
      {!readOnly && (
        <Button type="button" variant="outline" onClick={() => addDynamicRow(sectionKey)} className="border-yellow-400 text-yellow-300 hover:bg-yellow-500 hover:text-white">
          <PlusCircle className="h-4 w-4 mr-2" /> Ajouter un Point à "{title}"
        </Button>
      )}
    </>
  );
  
  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-2">
      <SectionTitle icon={<ClipboardEdit />} title="Informations Générales sur l'Entretien" />
      <FormRow>
        <div><Label htmlFor="localite">Localité</Label><Input name="localite" value={formData.localite || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="district_sanitaire">District Sanitaire</Label><Input name="district_sanitaire" value={formData.district_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="province">Province</Label><Input name="province" value={formData.province || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FormRow>
        <div><Label htmlFor="date_entretien">Date de l'entretien</Label><Input name="date_entretien" type="date" value={formData.date_entretien || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div>
            <Label htmlFor="type_entretien">Type d'entretien</Label>
            <Select name="type_entretien" onValueChange={(value) => handleSelectChange("type_entretien", value)} value={formData.type_entretien || ''} disabled={readOnly}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Sélectionner un type" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="Focus Group">Focus Group</SelectItem>
                    <SelectItem value="Entretien Individuel">Entretien Individuel</SelectItem>
                    <SelectItem value="Observation Participante">Observation Participante</SelectItem>
                    <SelectItem value="Autre">Autre</SelectItem>
                </SelectContent>
            </Select>
        </div>
         <div><Label htmlFor="nom_enqueteur">Nom de l'enquêteur/facilitateur</Label><Input name="nom_enqueteur" value={formData.nom_enqueteur || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
         <div><Label htmlFor="nombre_participants">Nombre de participants (si applicable)</Label><Input name="nombre_participants" type="number" value={formData.nombre_participants || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      {renderDynamicSection('connaissances_informations', "Connaissances et Informations sur la Vaccination", <Info />)}
      {renderDynamicSection('perception_services', "Perception des Services de Vaccination", <Smile />)}
      {renderDynamicSection('barrieres_obstacles', "Barrières et Obstacles à la Vaccination", <AlertTriangle />)}
      {renderDynamicSection('rumeurs_fausses_croyances', "Rumeurs et Fausses Croyances", <MessageSquare />)}
      {renderDynamicSection('engagement_communautaire', "Engagement Communautaire et Participation", <Users />)}
      {renderDynamicSection('experiences_personnelles', "Expériences Personnelles avec la Vaccination", <Lightbulb />)}
      {renderDynamicSection('suggestions_amelioration', "Suggestions d'Amélioration", <ThumbsUp />)}
      
      <SectionTitle icon={<ClipboardEdit />} title="Observations Générales du Facilitateur" />
      <FullWidthFormRow>
        <Textarea name="observations_facilitateur" value={formData.observations_facilitateur || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" rows={5} placeholder="Synthèse des observations générales, dynamique du groupe, points saillants non couverts ailleurs..."/>
      </FullWidthFormRow>
      
      {!readOnly && (
        <div className="flex justify-end mt-10 pt-6 border-t border-slate-700">
          <Button type="submit" className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white font-semibold px-8 py-3 text-lg">
            <Save className="mr-2 h-5 w-5" /> {initialData ? 'Mettre à Jour l\'Entretien' : 'Sauvegarder l\'Entretien'}
          </Button>
        </div>
      )}
    </form>
  );
};

export default CommunityInterviewForm;
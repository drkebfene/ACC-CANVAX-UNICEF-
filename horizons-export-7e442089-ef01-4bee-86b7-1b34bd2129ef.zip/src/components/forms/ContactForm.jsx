
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const ContactForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (!name || !email || !message) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir votre nom, email et message.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    const { error } = await supabase
      .from('contact_messages')
      .insert([{ name, email, subject, message }]);

    setIsLoading(false);

    if (error) {
      toast({
        title: "Erreur d'envoi",
        description: "Une erreur s'est produite lors de l'envoi de votre message. " + error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Message Envoyé !",
        description: "Merci de nous avoir contactés. Nous vous répondrons bientôt.",
      });
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    }
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-6 bg-card p-8 rounded-xl shadow-2xl border border-border/20"
      variants={fadeIn}
      initial="hidden"
      animate="visible"
    >
      <div>
        <Label htmlFor="name" className="text-muted-foreground">Nom complet</Label>
        <Input
          id="name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Votre nom complet"
          className="mt-1 bg-background/70 border-border/50 focus:border-primary"
          required
        />
      </div>
      <div>
        <Label htmlFor="email" className="text-muted-foreground">Adresse Email</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="votre.email@example.com"
          className="mt-1 bg-background/70 border-border/50 focus:border-primary"
          required
        />
      </div>
      <div>
        <Label htmlFor="subject" className="text-muted-foreground">Sujet (Optionnel)</Label>
        <Input
          id="subject"
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Sujet de votre message"
          className="mt-1 bg-background/70 border-border/50 focus:border-primary"
        />
      </div>
      <div>
        <Label htmlFor="message" className="text-muted-foreground">Votre Message</Label>
        <Textarea
          id="message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Écrivez votre message ici..."
          rows={5}
          className="mt-1 bg-background/70 border-border/50 focus:border-primary"
          required
        />
      </div>
      <Button 
        type="submit" 
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 text-lg shadow-lg transform hover:scale-105 transition-transform duration-300"
        disabled={isLoading}
      >
        {isLoading ? (
          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
        ) : (
          <Send className="mr-2 h-5 w-5" />
        )}
        Envoyer le Message
      </Button>
    </motion.form>
  );
};

export default ContactForm;

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Save, PlusCircle, Trash2, MapPin, Target as TargetIcon, Users, CalendarDays, ListChecks, DollarSign, CheckCircle, FileText as FileTextIcon } from 'lucide-react';

const SectionTitle = ({ icon, title }) => (
  <div className="flex items-center text-xl font-semibold text-lime-300 mb-4 mt-6">
    {React.cloneElement(icon, { className: "mr-3 h-6 w-6 text-lime-400" })}
    {title}
  </div>
);

const FormRow = ({ children }) => <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">{children}</div>;
const FullWidthFormRow = ({ children }) => <div className="mb-4">{children}</div>;

const defaultDynamicRow = {
  planification_activites: { semaine_mois: '', activite: '', responsable: '', lieu_cible: '', ressources_necessaires: '', resultat_attendu: '' },
  ciblage_geographique: { localite_ou_district: '', enfants_0_23_mois: '', zero_dose: '', justification: '' },
  mobilisation_communautaire: { activite: '', public_cible: '', date_prevue: '', responsable: '', support_utilise: '' },
  suivi_supervision: { date: '', lieu_ou_district: '', type_supervision: '', problemes_identifies: '', actions_correctives: '' },
  indicateurs_cles: { indicateur: '', valeur_reference: '', cible: '', resultat: '', pourcentage_realise: '' },
  budget_simplifie: { activite: '', ressources: '', cout_fcfa: '', source_financement: '' },
  objectifs_operationnels: { objectif: '' },
};


const RoadmapDSPForm = ({ onSubmit, initialData, readOnly = false }) => {
  const [formData, setFormData] = useState(
    initialData ? 
    { 
      ...initialData,
      objectifs_operationnels: initialData.objectifs_operationnels && initialData.objectifs_operationnels.length > 0 ? initialData.objectifs_operationnels : [defaultDynamicRow.objectifs_operationnels],
      planification_activites: initialData.planification_activites && initialData.planification_activites.length > 0 ? initialData.planification_activites : [defaultDynamicRow.planification_activites],
      ciblage_geographique: initialData.ciblage_geographique && initialData.ciblage_geographique.length > 0 ? initialData.ciblage_geographique : [defaultDynamicRow.ciblage_geographique],
      mobilisation_communautaire: initialData.mobilisation_communautaire && initialData.mobilisation_communautaire.length > 0 ? initialData.mobilisation_communautaire : [defaultDynamicRow.mobilisation_communautaire],
      suivi_supervision: initialData.suivi_supervision && initialData.suivi_supervision.length > 0 ? initialData.suivi_supervision : [defaultDynamicRow.suivi_supervision],
      indicateurs_cles: initialData.indicateurs_cles && initialData.indicateurs_cles.length > 0 ? initialData.indicateurs_cles : [defaultDynamicRow.indicateurs_cles],
      budget_simplifie: initialData.budget_simplifie && initialData.budget_simplifie.length > 0 ? initialData.budget_simplifie : [defaultDynamicRow.budget_simplifie],
    } 
    : {
      province: '', district_sanitaire: '', centre_sante_aire_sante: '', nom_responsable: '', date_elaboration: new Date().toISOString().slice(0,10),
      objectifs_operationnels: [defaultDynamicRow.objectifs_operationnels],
      planification_activites: [defaultDynamicRow.planification_activites],
      ciblage_geographique: [defaultDynamicRow.ciblage_geographique],
      mobilisation_communautaire: [defaultDynamicRow.mobilisation_communautaire],
      suivi_supervision: [defaultDynamicRow.suivi_supervision],
      indicateurs_cles: [defaultDynamicRow.indicateurs_cles],
      budget_simplifie: [defaultDynamicRow.budget_simplifie],
      validation_nom: '', validation_fonction: '', validation_signature: '', validation_date: new Date().toISOString().slice(0,10),
      annexes_microplan_link: '', annexes_carte_priorisation_link: '', annexes_liste_zero_dose_link: '', annexes_rapport_supervision_link: '',
      status: 'Brouillon',
  });

  useEffect(() => {
    if (initialData) {
      const updatedFormData = { ...initialData };
      Object.keys(defaultDynamicRow).forEach(key => {
        if (!updatedFormData[key] || updatedFormData[key].length === 0) {
          updatedFormData[key] = [defaultDynamicRow[key]];
        }
      });
      setFormData(updatedFormData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    if (readOnly) return;
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDynamicRowChange = (section, index, e) => {
    if (readOnly) return;
    const { name, value } = e.target;
    const updatedSection = [...formData[section]];
    updatedSection[index] = { ...updatedSection[index], [name]: value };
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const addDynamicRow = (section) => {
    if (readOnly) return;
    setFormData(prev => ({
      ...prev,
      [section]: [...prev[section], defaultDynamicRow[section]]
    }));
  };

  const removeDynamicRow = (section, index) => {
    if (readOnly) return;
    if (formData[section].length <= 1) return; 
    const updatedSection = formData[section].filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    onSubmit(formData);
  };

  const renderDynamicSection = (sectionKey, title, fields, icon) => (
    <>
      <SectionTitle icon={icon} title={title} />
      {formData[sectionKey]?.map((item, index) => (
        <div key={index} className="p-4 border border-slate-600 rounded-md mb-4 bg-slate-800/30 relative">
          <h4 className="font-semibold text-lg mb-3 text-green-400">Élément {index + 1}</h4>
          {!readOnly && formData[sectionKey].length > 1 && (
            <Button type="button" variant="destructive" size="sm" onClick={() => removeDynamicRow(sectionKey, index)} className="absolute top-4 right-4">
              <Trash2 className="h-4 w-4 mr-1" /> Supprimer
            </Button>
          )}
          {fields.map(field => (
            <div key={field.name} className="mb-3">
              <Label htmlFor={`${sectionKey}-${index}-${field.name}`}>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              ) : (
                <Input type={field.type || 'text'} name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              )}
            </div>
          ))}
        </div>
      ))}
      {!readOnly && (
        <Button type="button" variant="outline" onClick={() => addDynamicRow(sectionKey)} className="border-lime-400 text-lime-300 hover:bg-lime-500 hover:text-white">
          <PlusCircle className="h-4 w-4 mr-2" /> Ajouter un élément à "{title}"
        </Button>
      )}
    </>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-2">
      <SectionTitle icon={<MapPin />} title="1. Identification du niveau opérationnel (Provincial)" />
      <FormRow>
        <div><Label htmlFor="province">Province</Label><Input name="province" value={formData.province || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="nom_responsable">Nom du Responsable (DSP)</Label><Input name="nom_responsable" value={formData.nom_responsable || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FormRow>
        <div><Label htmlFor="district_sanitaire">District Sanitaire (Focus si applicable)</Label><Input name="district_sanitaire" value={formData.district_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Optionnel"/></div>
        <div><Label htmlFor="centre_sante_aire_sante">Centre de Santé / Aire de Santé (Focus si applicable)</Label><Input name="centre_sante_aire_sante" value={formData.centre_sante_aire_sante || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Optionnel"/></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="date_elaboration">Date d’élaboration</Label><Input name="date_elaboration" type="date" value={formData.date_elaboration || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      {renderDynamicSection('objectifs_operationnels', '2. Objectifs opérationnels spécifiques (Province)', [{ name: 'objectif', label: 'Objectif (Ex: Assurer 95% de couverture Penta 3 dans la province)', type: 'textarea', placeholder: 'Décrire l\'objectif provincial...' }], <TargetIcon />)}
      {renderDynamicSection('planification_activites', '3. Planification des activités (Niveau Provincial)', [
        { name: 'semaine_mois', label: 'Semaine/Mois' }, { name: 'activite', label: 'Activité (Coordination, Supervision des DS, Plaidoyer)', type: 'textarea' }, { name: 'responsable', label: 'Responsable (DSP, Partenaires)' },
        { name: 'lieu_cible', label: 'Lieu ciblé (Districts, Régions spécifiques)' }, { name: 'ressources_necessaires', label: 'Ressources nécessaires', type: 'textarea' }, { name: 'resultat_attendu', label: 'Résultat attendu', type: 'textarea' }
      ], <CalendarDays />)}
      {renderDynamicSection('ciblage_geographique', '4. Ciblage géographique et démographique (Consolidation Provinciale)', [
        { name: 'localite_ou_district', label: 'District Sanitaire / Zone' }, { name: 'enfants_0_23_mois', label: 'Enfants 0–23 mois', type: 'number' },
        { name: 'zero_dose', label: 'Zéro dose', type: 'number' }, { name: 'justification', label: 'Justification/Stratégie provinciale', type: 'textarea' }
      ], <Users />)}
      {renderDynamicSection('mobilisation_communautaire', '5. Mobilisation communautaire planifiée (Coordination Provinciale)', [
        { name: 'activite', label: 'Activité (Campagnes médiatiques, Coordination des DS)', type: 'textarea' }, { name: 'public_cible', label: 'Public cible (Population générale, Leaders d\'opinion)' }, { name: 'date_prevue', label: 'Date prévue', type: 'date' },
        { name: 'responsable', label: 'Responsable (DSP, Partenaires Com)' }, { name: 'support_utilise', label: 'Support utilisé (Médias, Plateformes)' }
      ], <Users />)}
      {renderDynamicSection('suivi_supervision', '6. Suivi, supervision et feedback (Plan Provincial)', [
        { name: 'date', label: 'Date', type: 'date' }, { name: 'lieu_ou_district', label: 'Lieu (District Sanitaire)' }, { name: 'type_supervision', label: 'Type de Supervision (Supervision formative des DS)' },
        { name: 'problemes_identifies', label: 'Problèmes identifiés', type: 'textarea' }, { name: 'actions_correctives', label: 'Actions correctives', type: 'textarea' }
      ], <ListChecks />)}
      {renderDynamicSection('indicateurs_cles', '7. Indicateurs clés à suivre (Niveau Provincial)', [
        { name: 'indicateur', label: 'Indicateur Provincial' }, { name: 'valeur_reference', label: 'Valeur de référence' }, { name: 'cible', label: 'Cible Provinciale' },
        { name: 'resultat', label: 'Résultat consolidé province' }, { name: 'pourcentage_realise', label: '% Réalisé' }
      ], <TargetIcon />)}
      {renderDynamicSection('budget_simplifie', '8. Budget simplifié (Consolidation Provinciale)', [
        { name: 'activite', label: 'Activité/Ligne budgétaire' }, { name: 'ressources', label: 'Ressources/Description' }, { name: 'cout_fcfa', label: 'Coût (FCFA)', type: 'number' },
        { name: 'source_financement', label: 'Source de financement' }
      ], <DollarSign />)}

      <SectionTitle icon={<CheckCircle />} title="9. Signature et validation" />
      <FormRow>
        <div><Label htmlFor="validation_nom">Nom (Responsable DSP)</Label><Input name="validation_nom" value={formData.validation_nom || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="validation_fonction">Fonction (Responsable DSP)</Label><Input name="validation_fonction" value={formData.validation_fonction || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FormRow>
        <div><Label htmlFor="validation_signature">Signature (placeholder)</Label><Input name="validation_signature" value={formData.validation_signature || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Entrez 'Signé' ou un lien vers l'image"/></div>
        <div><Label htmlFor="validation_date">Date de validation</Label><Input name="validation_date" type="date" value={formData.validation_date || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>

      <SectionTitle icon={<FileTextIcon />} title="Annexes recommandées (liens ou références)" />
        <FullWidthFormRow>
            <div><Label htmlFor="annexes_microplan_link">Microplan ACD (consolidé provincial)</Label><Input name="annexes_microplan_link" value={formData.annexes_microplan_link || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Lien ou référence"/></div>
        </FullWidthFormRow>
        <FullWidthFormRow>
            <div><Label htmlFor="annexes_carte_priorisation_link">Carte de priorisation (provinciale)</Label><Input name="annexes_carte_priorisation_link" value={formData.annexes_carte_priorisation_link || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Lien ou référence"/></div>
        </FullWidthFormRow>
        <FullWidthFormRow>
            <div><Label htmlFor="annexes_liste_zero_dose_link">Liste des enfants zéro dose (consolidée provinciale)</Label><Input name="annexes_liste_zero_dose_link" value={formData.annexes_liste_zero_dose_link || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Lien ou référence"/></div>
        </FullWidthFormRow>
        <FullWidthFormRow>
            <div><Label htmlFor="annexes_rapport_supervision_link">Rapport de supervision (consolidé provincial)</Label><Input name="annexes_rapport_supervision_link" value={formData.annexes_rapport_supervision_link || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Lien ou référence"/></div>
        </FullWidthFormRow>

      {!readOnly && (
        <div className="flex justify-end mt-10 pt-6 border-t border-slate-700">
          <Button type="submit" className="bg-gradient-to-r from-lime-500 to-green-600 hover:from-lime-600 hover:to-green-700 text-white font-semibold px-8 py-3 text-lg">
            <Save className="mr-2 h-5 w-5" /> {initialData ? 'Mettre à Jour la Feuille de Route DSP' : 'Sauvegarder la Feuille de Route DSP'}
          </Button>
        </div>
      )}
    </form>
  );
};

export default RoadmapDSPForm;
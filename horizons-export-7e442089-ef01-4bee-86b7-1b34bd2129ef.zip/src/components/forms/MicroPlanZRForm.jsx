
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Save, Users, MapPin, TrendingUp, DollarSign, CalendarDays, KeyRound as UsersRound, BarChart3, Target, ListChecks, Lightbulb, AlertTriangle, CheckCircle } from 'lucide-react';

const SectionTitle = ({ icon, title }) => (
  <div className="flex items-center text-xl font-semibold text-purple-300 mb-4 mt-6">
    {React.cloneElement(icon, { className: "mr-3 h-6 w-6 text-purple-400" })}
    {title}
  </div>
);

const FormRow = ({ children }) => <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">{children}</div>;
const FullWidthFormRow = ({ children }) => <div className="mb-4">{children}</div>;

const MicroPlanZRForm = ({ onSubmit, initialData, readOnly = false }) => {
  const defaultActivity = { type: 'Sensibilisation', description: '', lieu: '', date: '', responsable: '', indicateur: '', budget: '', sourceFinancement: '', observations: '' };
  const [formData, setFormData] = useState(initialData ? 
    { ...initialData, activites: initialData.activites || [defaultActivity] } : 
    {
    region_sanitaire: '', district_sanitaire: '', aire_de_sante: '', centre_de_sante: '',
    periode_implementation: '', population_cible_totale: '', population_cible_vaccination: '', population_cible_supplementaire: '',
    problemes_identifies: '', causes_problemes: '', strategies_resolution: '',
    activites: [defaultActivity],
    indicateurs_performance_cle: '', methodes_collecte_donnees: '', frequence_suivi: '', responsable_suivi_evaluation: '',
    besoins_logistiques: '', besoins_financiers: '', besoins_humains: '', ressources_disponibles: '',
    risques_potentiels: '', strategies_attenuation: '',
    nom_responsable_zr: '', date_validation: '',
  });

  useEffect(() => {
    if (initialData) {
      // Ensure activites is an array, even if it's null/undefined in initialData
      const activities = initialData.activites && Array.isArray(initialData.activites) ? initialData.activites : [defaultActivity];
      // Ensure each activity has all fields, providing defaults if missing
      const completeActivities = activities.map(act => ({ ...defaultActivity, ...act }));
      setFormData({ ...initialData, activites: completeActivities });
    }
  }, [initialData]);


  const handleChange = (e) => {
    if (readOnly) return;
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleActivityChange = (index, e) => {
    if (readOnly) return;
    const { name, value } = e.target;
    const newActivites = [...formData.activites];
    newActivites[index] = { ...newActivites[index], [name]: value };
    setFormData(prev => ({ ...prev, activites: newActivites }));
  };

  const addActivity = () => {
    if (readOnly) return;
    setFormData(prev => ({
      ...prev,
      activites: [
        ...prev.activites,
        defaultActivity
      ]
    }));
  };

  const removeActivity = (index) => {
    if (readOnly) return;
    const newActivites = formData.activites.filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, activites: newActivites }));
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    // Map form field names to DB column names if they differ
    const dbData = {
        ...formData, // spread existing formData
        // Example: if form field is 'regionSanitaire' but DB is 'region_sanitaire'
        // region_sanitaire: formData.regionSanitaire, 
        // This is already handled by using DB names in form state
    };
    onSubmit(dbData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-2">
      
      <SectionTitle icon={<Users />} title="1. Informations Générales" />
      <FormRow>
        <div><Label htmlFor="region_sanitaire">Région Sanitaire</Label><Input name="region_sanitaire" value={formData.region_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="district_sanitaire">District Sanitaire</Label><Input name="district_sanitaire" value={formData.district_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FormRow>
        <div><Label htmlFor="aire_de_sante">Aire de Santé</Label><Input name="aire_de_sante" value={formData.aire_de_sante || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="centre_de_sante">Centre de Santé (ZR)</Label><Input name="centre_de_sante" value={formData.centre_de_sante || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="periode_implementation">Période de mise en œuvre</Label><Input name="periode_implementation" type="text" placeholder="Ex: Jan 2024 - Mars 2024" value={formData.periode_implementation || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FormRow>
        <div><Label htmlFor="population_cible_totale">Population Cible Totale (0-59 mois)</Label><Input type="number" name="population_cible_totale" value={formData.population_cible_totale || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="population_cible_vaccination">Pop. Cible Vaccination (Ex: 0-11 mois)</Label><Input type="number" name="population_cible_vaccination" value={formData.population_cible_vaccination || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
       <FullWidthFormRow>
        <div><Label htmlFor="population_cible_supplementaire">Pop. Cible Activités Supplémentaires (Ex: VAD, Déparasitage)</Label><Input type="number" name="population_cible_supplementaire" value={formData.population_cible_supplementaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>


      <SectionTitle icon={<Lightbulb />} title="2. Analyse de la Situation" />
      <FullWidthFormRow>
        <div><Label htmlFor="problemes_identifies">Problèmes identifiés (basée sur données de couverture, abandon, etc.)</Label><Textarea name="problemes_identifies" value={formData.problemes_identifies || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="causes_problemes">Causes probables des problèmes</Label><Textarea name="causes_problemes" value={formData.causes_problemes || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="strategies_resolution">Stratégies de résolution proposées</Label><Textarea name="strategies_resolution" value={formData.strategies_resolution || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      <SectionTitle icon={<ListChecks />} title="3. Planification des Activités" />
      {formData.activites && formData.activites.map((activity, index) => (
        <div key={index} className="p-4 border border-slate-600 rounded-md mb-4 bg-slate-800/30 relative">
          <h4 className="font-semibold text-lg mb-3 text-pink-400">Activité {index + 1}</h4>
          {!readOnly && formData.activites.length > 1 && (
            <Button type="button" variant="destructive" size="sm" onClick={() => removeActivity(index)} className="absolute top-4 right-4">
              Supprimer
            </Button>
          )}
          <FormRow>
            <div>
              <Label htmlFor={`type-${index}`}>Type d'activité</Label>
              <select name="type" id={`type-${index}`} value={activity.type || 'Sensibilisation'} onChange={(e) => handleActivityChange(index, e)} disabled={readOnly} className="w-full h-10 rounded-md border border-input bg-slate-700 px-3 py-2 text-sm text-white">
                <option value="Sensibilisation">Sensibilisation</option>
                <option value="VaccinationFixe">Vaccination Fixe</option>
                <option value="VaccinationAvancee">Vaccination Avancée</option>
                <option value="VaccinationMobile">Vaccination Mobile</option>
                <option value="Suivi">Suivi des enfants</option>
                <option value="Reunion">Réunion de coordination</option>
                <option value="Formation">Formation</option>
                <option value="Autre">Autre</option>
              </select>
            </div>
            <div><Label htmlFor={`description-${index}`}>Description</Label><Input name="description" id={`description-${index}`} value={activity.description || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
          </FormRow>
          <FormRow>
            <div><Label htmlFor={`lieu-${index}`}>Lieu</Label><Input name="lieu" id={`lieu-${index}`} value={activity.lieu || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
            <div><Label htmlFor={`date-${index}`}>Date/Période</Label><Input name="date" id={`date-${index}`} type="date" value={activity.date || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
          </FormRow>
          <FormRow>
            <div><Label htmlFor={`responsable-${index}`}>Responsable(s)</Label><Input name="responsable" id={`responsable-${index}`} value={activity.responsable || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
            <div><Label htmlFor={`indicateur-${index}`}>Indicateur de suivi</Label><Input name="indicateur" id={`indicateur-${index}`} value={activity.indicateur || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
          </FormRow>
          <FormRow>
            <div><Label htmlFor={`budget-${index}`}>Budget estimé (FCFA)</Label><Input name="budget" id={`budget-${index}`} type="number" value={activity.budget || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
            <div><Label htmlFor={`sourceFinancement-${index}`}>Source de financement</Label><Input name="sourceFinancement" id={`sourceFinancement-${index}`} value={activity.sourceFinancement || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
          </FormRow>
          <FullWidthFormRow>
            <div><Label htmlFor={`observations-${index}`}>Observations</Label><Textarea name="observations" id={`observations-${index}`} value={activity.observations || ''} onChange={(e) => handleActivityChange(index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
          </FullWidthFormRow>
        </div>
      ))}
      {!readOnly && (
        <Button type="button" variant="outline" onClick={addActivity} className="border-purple-400 text-purple-300 hover:bg-purple-500 hover:text-white">
          Ajouter une autre activité
        </Button>
      )}

      <SectionTitle icon={<BarChart3 />} title="4. Suivi et Évaluation" />
      <FullWidthFormRow>
        <div><Label htmlFor="indicateurs_performance_cle">Indicateurs de performance clés (SMART)</Label><Textarea name="indicateurs_performance_cle" value={formData.indicateurs_performance_cle || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FormRow>
        <div><Label htmlFor="methodes_collecte_donnees">Méthodes de collecte de données</Label><Input name="methodes_collecte_donnees" value={formData.methodes_collecte_donnees || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="frequence_suivi">Fréquence de suivi</Label><Input name="frequence_suivi" value={formData.frequence_suivi || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="responsable_suivi_evaluation">Responsable du suivi et évaluation</Label><Input name="responsable_suivi_evaluation" value={formData.responsable_suivi_evaluation || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      <SectionTitle icon={<Target />} title="5. Besoins et Ressources" />
      <FullWidthFormRow>
        <div><Label htmlFor="besoins_logistiques">Besoins Logistiques (matériel, transport, etc.)</Label><Textarea name="besoins_logistiques" value={formData.besoins_logistiques || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FormRow>
        <div><Label htmlFor="besoins_financiers">Besoins Financiers (détaillés)</Label><Textarea name="besoins_financiers" value={formData.besoins_financiers || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_humains">Besoins Humains (personnel, volontaires)</Label><Textarea name="besoins_humains" value={formData.besoins_humains || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="ressources_disponibles">Ressources disponibles (locales, partenaires)</Label><Textarea name="ressources_disponibles" value={formData.ressources_disponibles || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      <SectionTitle icon={<AlertTriangle />} title="6. Risques et Stratégies d'Atténuation" />
      <FullWidthFormRow>
        <div><Label htmlFor="risques_potentiels">Risques potentiels (liés à la mise en œuvre)</Label><Textarea name="risques_potentiels" value={formData.risques_potentiels || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="strategies_attenuation">Stratégies d'atténuation</Label><Textarea name="strategies_attenuation" value={formData.strategies_attenuation || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      <SectionTitle icon={<CheckCircle />} title="7. Validation" />
      <FormRow>
        <div><Label htmlFor="nom_responsable_zr">Nom et Prénom du Responsable ZR</Label><Input name="nom_responsable_zr" value={formData.nom_responsable_zr || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="date_validation">Date de validation</Label><Input name="date_validation" type="date" value={formData.date_validation || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      
      {!readOnly && (
        <div className="flex justify-end mt-10 pt-6 border-t border-slate-700">
          <Button type="submit" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold px-8 py-3 text-lg">
            <Save className="mr-2 h-5 w-5" /> {initialData ? 'Mettre à Jour le Micro-plan' : 'Sauvegarder le Micro-plan ZR'}
          </Button>
        </div>
      )}
    </form>
  );
};

export default MicroPlanZRForm;

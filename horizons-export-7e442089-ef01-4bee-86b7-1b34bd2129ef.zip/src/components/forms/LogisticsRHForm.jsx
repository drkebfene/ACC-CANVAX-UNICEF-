
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox'; // Assurez-vous d'avoir ce composant
import { Save, PlusCircle, Trash2, CalendarDays, MapPin, Users2, Package, Thermometer, Radio, KeyRound as UsersRound, FileText } from 'lucide-react';

const SectionTitle = ({ icon, title }) => (
  <div className="flex items-center text-xl font-semibold text-indigo-300 mb-4 mt-6">
    {React.cloneElement(icon, { className: "mr-3 h-6 w-6 text-indigo-400" })}
    {title}
  </div>
);

const FormRow = ({ children }) => <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">{children}</div>;
const FullWidthFormRow = ({ children }) => <div className="mb-4">{children}</div>;
const CheckboxField = ({ label, name, checked, onChange, readOnly }) => (
  <div className="flex items-center space-x-2">
    <Checkbox id={name} name={name} checked={checked} onCheckedChange={(val) => onChange({ target: { name, value: val, type: 'checkbox' }})} disabled={readOnly} />
    <Label htmlFor={name} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
      {label}
    </Label>
  </div>
);


const defaultDynamicRow = {
  gestion_stocks_vaccins_consommables: { produit: '', stock_initial: '', entrees: '', sorties: '', stock_final: '' },
};

const LogisticsRHForm = ({ onSubmit, initialData, readOnly = false }) => {
  const [formData, setFormData] = useState(
    initialData ? 
    { 
      ...initialData,
      gestion_stocks_vaccins_consommables: initialData.gestion_stocks_vaccins_consommables && initialData.gestion_stocks_vaccins_consommables.length > 0 ? initialData.gestion_stocks_vaccins_consommables : [defaultDynamicRow.gestion_stocks_vaccins_consommables],
    } 
    : {
      province: '', district_sanitaire: '', aire_sante: '', date_rapport: new Date().toISOString().slice(0,10),
      besoins_vaccins_population_cible: '', besoins_vaccins_doses_necessaires: '', besoins_vaccins_reserve_operationnelle: '', besoins_vaccins_total_commander: '',
      besoins_materiel_quantites_estimees: '',
      besoins_personnel_vaccinateurs: '', besoins_personnel_superviseurs: '', besoins_personnel_mobilisateurs: '',
      gestion_stocks_vaccins_consommables: [defaultDynamicRow.gestion_stocks_vaccins_consommables],
      suivi_chaine_froid_refrigerateurs_fonctionnels: '', suivi_chaine_froid_porte_vaccins_glacieres: '', suivi_chaine_froid_packs_refrigerants: '',
      materiel_sensibilisation_supports_imprimes: '', materiel_sensibilisation_supports_audio: '', materiel_sensibilisation_equipements_transport: '',
      checklist_rh_liste_agents_affectes: false, checklist_rh_contrats_affectation: false, checklist_rh_indemnites_validees: false, checklist_rh_planning_travail: false, checklist_rh_notes: '',
      status: 'Brouillon',
  });

  useEffect(() => {
    if (initialData) {
      const updatedFormData = { ...initialData };
      if (!updatedFormData.gestion_stocks_vaccins_consommables || updatedFormData.gestion_stocks_vaccins_consommables.length === 0) {
        updatedFormData.gestion_stocks_vaccins_consommables = [defaultDynamicRow.gestion_stocks_vaccins_consommables];
      }
      // Ensure boolean fields are booleans
      ['checklist_rh_liste_agents_affectes', 'checklist_rh_contrats_affectation', 'checklist_rh_indemnites_validees', 'checklist_rh_planning_travail'].forEach(key => {
        updatedFormData[key] = !!updatedFormData[key];
      });
      setFormData(updatedFormData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    if (readOnly) return;
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) || 0 : value) }));
  };

  const handleDynamicRowChange = (section, index, e) => {
    if (readOnly) return;
    const { name, value, type } = e.target;
    const updatedSection = [...formData[section]];
    updatedSection[index] = { ...updatedSection[index], [name]: type === 'number' ? parseFloat(value) || 0 : value };
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const addDynamicRow = (section) => {
    if (readOnly) return;
    setFormData(prev => ({
      ...prev,
      [section]: [...prev[section], defaultDynamicRow[section]]
    }));
  };

  const removeDynamicRow = (section, index) => {
    if (readOnly) return;
    if (formData[section].length <= 1) return;
    const updatedSection = formData[section].filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    onSubmit(formData);
  };
  
  const renderDynamicSection = (sectionKey, title, fields, icon) => (
    <>
      <SectionTitle icon={icon} title={title} />
      {formData[sectionKey]?.map((item, index) => (
        <div key={index} className="p-4 border border-slate-600 rounded-md mb-4 bg-slate-800/30 relative">
          <h4 className="font-semibold text-lg mb-3 text-cyan-400">Élément {index + 1}</h4>
          {!readOnly && formData[sectionKey].length > 1 && (
            <Button type="button" variant="destructive" size="sm" onClick={() => removeDynamicRow(sectionKey, index)} className="absolute top-4 right-4">
              <Trash2 className="h-4 w-4 mr-1" /> Supprimer
            </Button>
          )}
          {fields.map(field => (
            <div key={field.name} className="mb-3">
              <Label htmlFor={`${sectionKey}-${index}-${field.name}`}>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              ) : (
                <Input type={field.type || 'text'} name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              )}
            </div>
          ))}
        </div>
      ))}
      {!readOnly && (
        <Button type="button" variant="outline" onClick={() => addDynamicRow(sectionKey)} className="border-indigo-400 text-indigo-300 hover:bg-indigo-500 hover:text-white">
          <PlusCircle className="h-4 w-4 mr-2" /> Ajouter à "{title}"
        </Button>
      )}
    </>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-2">
      <SectionTitle icon={<MapPin />} title="Identification" />
      <FormRow>
        <div><Label htmlFor="province">Province</Label><Input name="province" value={formData.province || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="district_sanitaire">District Sanitaire</Label><Input name="district_sanitaire" value={formData.district_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="aire_sante">Aire de Santé</Label><Input name="aire_sante" value={formData.aire_sante || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="date_rapport">Date du Rapport</Label><Input name="date_rapport" type="date" value={formData.date_rapport || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      <SectionTitle icon={<Package />} title="1. Planification des vaccins, matériel et personnel" />
      <h3 className="text-lg font-medium text-cyan-300 mb-2">a. Estimation des besoins en vaccins :</h3>
      <FormRow>
        <div><Label htmlFor="besoins_vaccins_population_cible">Population cible estimée</Label><Input name="besoins_vaccins_population_cible" type="number" value={formData.besoins_vaccins_population_cible || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_vaccins_doses_necessaires">Nombre de doses nécessaires</Label><Input name="besoins_vaccins_doses_necessaires" type="number" value={formData.besoins_vaccins_doses_necessaires || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_vaccins_reserve_operationnelle">Réserve opérationnelle (ex: 10%)</Label><Input name="besoins_vaccins_reserve_operationnelle" type="number" value={formData.besoins_vaccins_reserve_operationnelle || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_vaccins_total_commander">Total à commander</Label><Input name="besoins_vaccins_total_commander" type="number" value={formData.besoins_vaccins_total_commander || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <h3 className="text-lg font-medium text-cyan-300 mb-2 mt-4">b. Besoins en matériel :</h3>
      <FullWidthFormRow>
        <div><Label htmlFor="besoins_materiel_quantites_estimees">Carnets, stylos, seringues, boîtes sécu. (Quantités estimées)</Label><Textarea name="besoins_materiel_quantites_estimees" value={formData.besoins_materiel_quantites_estimees || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Ex: Carnets: 500, Seringues: 1000..."/></div>
      </FullWidthFormRow>
      <h3 className="text-lg font-medium text-cyan-300 mb-2 mt-4">c. Besoins en personnel :</h3>
      <FormRow>
        <div><Label htmlFor="besoins_personnel_vaccinateurs">Nombre de vaccinateurs</Label><Input name="besoins_personnel_vaccinateurs" type="number" value={formData.besoins_personnel_vaccinateurs || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_personnel_superviseurs">Superviseurs</Label><Input name="besoins_personnel_superviseurs" type="number" value={formData.besoins_personnel_superviseurs || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="besoins_personnel_mobilisateurs">Mobilisateurs sociaux</Label><Input name="besoins_personnel_mobilisateurs" type="number" value={formData.besoins_personnel_mobilisateurs || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>

      {renderDynamicSection('gestion_stocks_vaccins_consommables', '2. Gestion des stocks de vaccins et matériel', [
        { name: 'produit', label: 'Produit' }, { name: 'stock_initial', label: 'Stock initial', type: 'number' },
        { name: 'entrees', label: 'Entrées', type: 'number' }, { name: 'sorties', label: 'Sorties', type: 'number' }, { name: 'stock_final', label: 'Stock final', type: 'number' }
      ], <Package />)}
      
      <SectionTitle icon={<Thermometer />} title="Suivi de la chaîne du froid" />
      <FormRow>
        <div><Label htmlFor="suivi_chaine_froid_refrigerateurs_fonctionnels">Nombre de réfrigérateurs fonctionnels</Label><Input name="suivi_chaine_froid_refrigerateurs_fonctionnels" type="number" value={formData.suivi_chaine_froid_refrigerateurs_fonctionnels || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="suivi_chaine_froid_porte_vaccins_glacieres">Nombre de porte-vaccins et glacières</Label><Input name="suivi_chaine_froid_porte_vaccins_glacieres" type="number" value={formData.suivi_chaine_froid_porte_vaccins_glacieres || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="suivi_chaine_froid_packs_refrigerants">Packs réfrigérants disponibles</Label><Input name="suivi_chaine_froid_packs_refrigerants" type="number" value={formData.suivi_chaine_froid_packs_refrigerants || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>

      <SectionTitle icon={<Radio />} title="3. Matériel de sensibilisation et déploiement des équipes" />
      <FormRow>
        <div><Label htmlFor="materiel_sensibilisation_supports_imprimes">Supports imprimés (affiches, flyers)</Label><Input name="materiel_sensibilisation_supports_imprimes" value={formData.materiel_sensibilisation_supports_imprimes || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Ex: 100 affiches, 500 flyers"/></div>
        <div><Label htmlFor="materiel_sensibilisation_supports_audio">Supports audio (radios, mégaphones)</Label><Input name="materiel_sensibilisation_supports_audio" value={formData.materiel_sensibilisation_supports_audio || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Ex: 2 mégaphones"/></div>
        <div><Label htmlFor="materiel_sensibilisation_equipements_transport">Équipements de transport des équipes</Label><Input name="materiel_sensibilisation_equipements_transport" value={formData.materiel_sensibilisation_equipements_transport || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder="Ex: 3 motos, 1 véhicule"/></div>
      </FormRow>

      <SectionTitle icon={<UsersRound />} title="4. Checklist Ressources Humaines" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 p-4 border border-slate-600 rounded-md bg-slate-800/30">
        <CheckboxField label="Liste des agents affectés par aire de santé" name="checklist_rh_liste_agents_affectes" checked={formData.checklist_rh_liste_agents_affectes} onChange={handleChange} readOnly={readOnly} />
        <CheckboxField label="Contrats / notes d'affectation disponibles" name="checklist_rh_contrats_affectation" checked={formData.checklist_rh_contrats_affectation} onChange={handleChange} readOnly={readOnly} />
        <CheckboxField label="Indemnités validées et programmées" name="checklist_rh_indemnites_validees" checked={formData.checklist_rh_indemnites_validees} onChange={handleChange} readOnly={readOnly} />
        <CheckboxField label="Planning de travail quotidien disponible" name="checklist_rh_planning_travail" checked={formData.checklist_rh_planning_travail} onChange={handleChange} readOnly={readOnly} />
      </div>
      <FullWidthFormRow>
        <div><Label htmlFor="checklist_rh_notes">Notes additionnelles sur RH</Label><Textarea name="checklist_rh_notes" value={formData.checklist_rh_notes || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      
      {!readOnly && (
        <div className="flex justify-end mt-10 pt-6 border-t border-slate-700">
          <Button type="submit" className="bg-gradient-to-r from-indigo-500 to-cyan-600 hover:from-indigo-600 hover:to-cyan-700 text-white font-semibold px-8 py-3 text-lg">
            <Save className="mr-2 h-5 w-5" /> {initialData ? 'Mettre à Jour' : 'Sauvegarder les Données'}
          </Button>
        </div>
      )}
    </form>
  );
};

export default LogisticsRHForm;
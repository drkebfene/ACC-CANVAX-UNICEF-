
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Save, PlusCircle, Trash2, CalendarDays, MapPin, DollarSign, FileText as FileTextIcon, Percent } from 'lucide-react';

const SectionTitle = ({ icon, title }) => (
  <div className="flex items-center text-xl font-semibold text-green-300 mb-4 mt-6">
    {React.cloneElement(icon, { className: "mr-3 h-6 w-6 text-green-400" })}
    {title}
  </div>
);

const FormRow = ({ children }) => <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">{children}</div>;
const FullWidthFormRow = ({ children }) => <div className="mb-4">{children}</div>;

const defaultDynamicRow = {
  ressources_mobilisees: { partenaire: '', montant_recu: '', contribution_locale: '' },
  utilisation_fonds: { activite: '', depenses_engagees: '', montant_justifie: '', observations: '' },
};

const FinancialReportACDForm = ({ onSubmit, initialData, readOnly = false }) => {
  const [formData, setFormData] = useState(
    initialData ? 
    { 
      ...initialData,
      ressources_mobilisees: initialData.ressources_mobilisees && initialData.ressources_mobilisees.length > 0 ? initialData.ressources_mobilisees : [defaultDynamicRow.ressources_mobilisees],
      utilisation_fonds: initialData.utilisation_fonds && initialData.utilisation_fonds.length > 0 ? initialData.utilisation_fonds : [defaultDynamicRow.utilisation_fonds],
    } 
    : {
      periode_couverte_debut: '', periode_couverte_fin: '', province: '', district_sanitaire: '', aire_sante: '',
      ressources_mobilisees: [defaultDynamicRow.ressources_mobilisees],
      utilisation_fonds: [defaultDynamicRow.utilisation_fonds],
      taux_execution_budgetaire: '', depassements_economies: '', problemes_rencontres: '', recommandations: '',
      status: 'Brouillon',
  });

  useEffect(() => {
    if (initialData) {
      const updatedFormData = { ...initialData };
      Object.keys(defaultDynamicRow).forEach(key => {
        if (!updatedFormData[key] || updatedFormData[key].length === 0) {
          updatedFormData[key] = [defaultDynamicRow[key]];
        }
      });
      setFormData(updatedFormData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    if (readOnly) return;
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) : value }));
  };

  const handleDynamicRowChange = (section, index, e) => {
    if (readOnly) return;
    const { name, value, type } = e.target;
    const updatedSection = [...formData[section]];
    updatedSection[index] = { ...updatedSection[index], [name]: type === 'number' ? parseFloat(value) : value };
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const addDynamicRow = (section) => {
    if (readOnly) return;
    setFormData(prev => ({
      ...prev,
      [section]: [...prev[section], defaultDynamicRow[section]]
    }));
  };

  const removeDynamicRow = (section, index) => {
    if (readOnly) return;
    if (formData[section].length <= 1) return;
    const updatedSection = formData[section].filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    onSubmit(formData);
  };

  const renderDynamicSection = (sectionKey, title, fields, icon) => (
    <>
      <SectionTitle icon={icon} title={title} />
      {formData[sectionKey]?.map((item, index) => (
        <div key={index} className="p-4 border border-slate-600 rounded-md mb-4 bg-slate-800/30 relative">
          <h4 className="font-semibold text-lg mb-3 text-emerald-400">Élément {index + 1}</h4>
          {!readOnly && formData[sectionKey].length > 1 && (
            <Button type="button" variant="destructive" size="sm" onClick={() => removeDynamicRow(sectionKey, index)} className="absolute top-4 right-4">
              <Trash2 className="h-4 w-4 mr-1" /> Supprimer
            </Button>
          )}
          {fields.map(field => (
            <div key={field.name} className="mb-3">
              <Label htmlFor={`${sectionKey}-${index}-${field.name}`}>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              ) : (
                <Input type={field.type || 'text'} name={field.name} id={`${sectionKey}-${index}-${field.name}`} value={item[field.name] || ''} onChange={(e) => handleDynamicRowChange(sectionKey, index, e)} readOnly={readOnly} className="bg-slate-700 border-slate-600" placeholder={field.placeholder}/>
              )}
            </div>
          ))}
        </div>
      ))}
      {!readOnly && (
        <Button type="button" variant="outline" onClick={() => addDynamicRow(sectionKey)} className="border-green-400 text-green-300 hover:bg-green-500 hover:text-white">
          <PlusCircle className="h-4 w-4 mr-2" /> Ajouter à "{title}"
        </Button>
      )}
    </>
  );
  
  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-2">
      <SectionTitle icon={<MapPin />} title="Identification" />
      <FormRow>
        <div><Label htmlFor="periode_couverte_debut">Période Couverte (Début)</Label><Input name="periode_couverte_debut" type="date" value={formData.periode_couverte_debut || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="periode_couverte_fin">Période Couverte (Fin)</Label><Input name="periode_couverte_fin" type="date" value={formData.periode_couverte_fin || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FormRow>
        <div><Label htmlFor="province">Province</Label><Input name="province" value={formData.province || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
        <div><Label htmlFor="district_sanitaire">District Sanitaire</Label><Input name="district_sanitaire" value={formData.district_sanitaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="aire_sante">Aire de Santé</Label><Input name="aire_sante" value={formData.aire_sante || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>

      {renderDynamicSection('ressources_mobilisees', '1. Ressources mobilisées', [
        { name: 'partenaire', label: 'Partenaire' }, { name: 'montant_recu', label: 'Montant reçu (FCFA)', type: 'number' }, { name: 'contribution_locale', label: 'Contribution locale', type: 'textarea' }
      ], <DollarSign />)}
      
      {renderDynamicSection('utilisation_fonds', '2. Utilisation des fonds par activité', [
        { name: 'activite', label: 'Activité', type: 'textarea' }, { name: 'depenses_engagees', label: 'Dépenses engagées (FCFA)', type: 'number' },
        { name: 'montant_justifie', label: 'Montant justifié (FCFA)', type: 'number' }, { name: 'observations', label: 'Observations', type: 'textarea' }
      ], <FileTextIcon />)}

      <SectionTitle icon={<Percent />} title="3. Analyse budgétaire" />
      <FullWidthFormRow>
        <div><Label htmlFor="taux_execution_budgetaire">Taux d'exécution budgétaire (%)</Label><Input name="taux_execution_budgetaire" type="number" step="0.01" value={formData.taux_execution_budgetaire || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="depassements_economies">Dépassements / Économies</Label><Textarea name="depassements_economies" value={formData.depassements_economies || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="problemes_rencontres">Problèmes rencontrés</Label><Textarea name="problemes_rencontres" value={formData.problemes_rencontres || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      <FullWidthFormRow>
        <div><Label htmlFor="recommandations">Recommandations</Label><Textarea name="recommandations" value={formData.recommandations || ''} onChange={handleChange} readOnly={readOnly} className="bg-slate-700 border-slate-600" /></div>
      </FullWidthFormRow>
      
      {!readOnly && (
        <div className="flex justify-end mt-10 pt-6 border-t border-slate-700">
          <Button type="submit" className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold px-8 py-3 text-lg">
            <Save className="mr-2 h-5 w-5" /> {initialData ? 'Mettre à Jour le Rapport' : 'Sauvegarder le Rapport'}
          </Button>
        </div>
      )}
    </form>
  );
};

export default FinancialReportACDForm;
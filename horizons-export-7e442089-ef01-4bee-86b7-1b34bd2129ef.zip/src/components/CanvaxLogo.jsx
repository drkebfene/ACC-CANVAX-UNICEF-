import React from 'react';
import { motion } from 'framer-motion';

const CanvaxLogo = ({ className, ...props }) => (
  <svg
    width="120"
    height="100"
    viewBox="0 0 140 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
    aria-labelledby="canvaxLogoTitle"
  >
    <title id="canvaxLogoTitle">ACD/ACE CANVAX Logo</title>
    
    <defs>
      <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: 'hsl(var(--primary))', stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: 'rgb(251, 146, 60)', stopOpacity: 1 }} />
      </linearGradient>
      <linearGradient id="syringeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" style={{ stopColor: 'hsl(var(--secondary-foreground))', stopOpacity: 0.7 }} />
        <stop offset="100%" style={{ stopColor: 'hsl(var(--secondary-foreground))', stopOpacity: 0.4 }} />
      </linearGradient>
      <linearGradient id="textGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: 'hsl(var(--primary-foreground))', stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: 'hsl(var(--primary-foreground))', stopOpacity: 0.7 }} />
      </linearGradient>
    </defs>

    <motion.path
      d="M60 10 C 30 20, 30 80, 60 110 C 90 80, 90 20, 60 10 Z"
      fill="url(#shieldGradient)"
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    />

    <motion.g 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.5 }}
    >
      <path d="M50 40 L70 60 L65 65 L45 45 Z" fill="hsl(var(--primary-foreground))" opacity="0.8"/>
      <path d="M45 65 L65 45 L70 50 L50 70 Z" fill="hsl(var(--primary-foreground))" opacity="0.8"/>
    </motion.g>
    
    <motion.g
      transform="translate(5, 5) rotate(45 60 60)"
      initial={{ opacity: 0, scale: 0.8, rotate: -45 }}
      animate={{ opacity: 1, scale: 1, rotate: 0 }}
      transition={{ delay: 0.4, duration: 0.6, type: "spring", stiffness: 150 }}
    >
      <rect x="55" y="30" width="10" height="40" rx="3" fill="url(#syringeGradient)" />
      <path d="M50 30 L70 30 L60 20 Z" fill="url(#syringeGradient)" />
      <rect x="52" y="70" width="16" height="5" rx="2" fill="url(#syringeGradient)" />
    </motion.g>

    <motion.circle cx="45" cy="75" r="7" fill="hsl(var(--primary-foreground))" opacity="0.7"
      initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6, type: "spring" }}/>
    <motion.circle cx="75" cy="75" r="7" fill="hsl(var(--primary-foreground))" opacity="0.7"
      initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.7, type: "spring" }}/>
    <motion.path d="M50 60 Q60 50 70 60" stroke="hsl(var(--primary-foreground))" strokeWidth="3" fill="none" opacity="0.7"
      initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.8, duration: 0.5 }}/>
    
    <motion.text
      x="100" 
      y="55" 
      fontFamily="Arial, sans-serif" 
      fontSize="20" 
      fontWeight="bold" 
      fill="url(#textGradient)"
      textAnchor="middle"
      initial={{ opacity: 0, x: 120 }}
      animate={{ opacity: 1, x: 100 }}
      transition={{ delay: 0.9, duration: 0.5 }}
    >
      ACD
    </motion.text>
    <motion.text
      x="100" 
      y="80" 
      fontFamily="Arial, sans-serif" 
      fontSize="20" 
      fontWeight="bold" 
      fill="url(#textGradient)"
      textAnchor="middle"
      initial={{ opacity: 0, x: 120 }}
      animate={{ opacity: 1, x: 100 }}
      transition={{ delay: 1.0, duration: 0.5 }}
    >
      ACE
    </motion.text>
  </svg>
);

export default CanvaxLogo;
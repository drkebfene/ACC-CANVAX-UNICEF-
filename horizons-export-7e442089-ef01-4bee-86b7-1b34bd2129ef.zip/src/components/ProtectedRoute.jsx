
import React, { useContext } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';

const ProtectedRoute = ({ children, requiredRole }) => {
  const { supabaseUser, userRole } = useContext(UserContext);
  const location = useLocation();
  const { toast } = useToast();

  if (!supabaseUser) { 
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (!userRole) {
    // This case might happen if user is authenticated but role is somehow not set.
    // It's a safety net, though App.jsx logic should prevent this.
    toast({
      title: "Erreur de rôle",
      description: "Votre rôle utilisateur n'est pas défini. Veuillez vous reconnecter.",
      variant: "destructive",
    });
    // Optionally, trigger a logout here or redirect to login.
    // For now, redirecting to login will force a re-evaluation of role.
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  if (requiredRole && userRole !== requiredRole) {
    // If a specific role is required and the user doesn't have it
    toast({
      title: "Accès non autorisé",
      description: `Vous n'avez pas les permissions nécessaires (${ROLES[requiredRole] || requiredRole}) pour accéder à cette page.`,
      variant: "destructive",
    });
    return <Navigate to="/" replace />; // Redirect to home page or a "not authorized" page
  }
  
  return children;
};

export default ProtectedRoute;

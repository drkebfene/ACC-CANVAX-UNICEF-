import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, MessageSquare, Send, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area'; 
import { cn } from '@/lib/utils';

const ChatbotWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const predefinedResponses = {
    "bonjour": "Bonjour ! Comment puis-je vous aider avec l'ACD/ACE CANVAX aujourd'hui ?",
    "salut": "Salut ! Prêt à explorer les fonctionnalités de CANVAX ?",
    "acd": "L'ACD (Atteindre Chaque District) est une stratégie visant à améliorer la couverture vaccinale en atteignant toutes les communautés, même les plus reculées.",
    "canvax": "CANVAX est une plateforme pour appuyer la mise en œuvre de l'ACD au Tchad, en fournissant outils, ressources et données.",
    "vaccination": "La vaccination est essentielle pour protéger les enfants contre les maladies évitables. CANVAX aide à optimiser les campagnes.",
    "aide": "Je peux vous donner des informations sur l'ACD, CANVAX, la planification, le monitoring, etc. Posez votre question !",
    "merci": "De rien ! N'hésitez pas si vous avez d'autres questions.",
    "rapport": "Pour générer des rapports, consultez la section 'Monitoring & Revue' ou 'Rapport Général'.",
    "planification": "La section 'Planification' contient des outils pour la microplanification et la budgétisation des activités de vaccination.",
    "monitoring": "Le 'Monitoring & Revue' vous permet de suivre les indicateurs clés et de visualiser les tableaux de bord.",
    "default": "Je suis encore en apprentissage. Pour des questions complexes, veuillez contacter le support via la page 'Contact'."
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{ sender: 'bot', text: "Bonjour ! Je suis l'assistant CANVAX. Comment puis-je vous aider ?" }]);
    }
  }, [isOpen]);

  const handleSendMessage = () => {
    if (inputValue.trim() === '') return;

    const userMessage = { sender: 'user', text: inputValue };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    setTimeout(() => {
      const botResponseText = predefinedResponses[inputValue.toLowerCase().trim()] || predefinedResponses["default"];
      const botMessage = { sender: 'bot', text: botResponseText };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 500);
  };

  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <Button
          size="lg"
          className="rounded-full p-4 h-16 w-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white shadow-xl hover:scale-110 transition-transform"
          onClick={toggleOpen}
          aria-label="Ouvrir le chatbot"
        >
          {isOpen ? <X className="h-8 w-8" /> : <Bot className="h-8 w-8" />}
        </Button>
      </motion.div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-24 right-6 z-40 w-full max-w-sm h-[70vh] max-h-[500px] bg-card shadow-2xl rounded-xl border border-border/30 flex flex-col overflow-hidden glassmorphism"
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.3, ease: "circOut" }}
          >
            <header className="p-4 border-b border-border/50 bg-primary/10">
              <h3 className="font-semibold text-lg text-primary flex items-center">
                <MessageSquare className="h-6 w-6 mr-2 text-primary" /> Assistant CANVAX
              </h3>
            </header>

            <ScrollArea className="flex-grow p-4 space-y-3">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex w-max max-w-[80%] flex-col gap-2 rounded-lg px-3 py-2 text-sm",
                    msg.sender === 'user' ? "ml-auto bg-primary text-primary-foreground" : "bg-muted"
                  )}
                >
                  {msg.text}
                </div>
              ))}
              {isTyping && (
                <div className="flex items-center space-x-1 text-muted-foreground p-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>L'assistant écrit...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </ScrollArea>

            <footer className="p-4 border-t border-border/50">
              <div className="flex items-center space-x-2">
                <Input
                  type="text"
                  placeholder="Posez votre question..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-grow bg-background/70 border-border/50 focus:border-primary"
                />
                <Button onClick={handleSendMessage} size="icon" className="bg-primary hover:bg-primary/90">
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatbotWidget;

import React, { useState, useEffect, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, NavLink, Navigate, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Moon, Sun, Menu, X, LogIn, Home, FileText, Users2, ClipboardList, BarChart2, FolderOpen, Settings as SettingsIcon, Info, BarChartHorizontal, MessageCircle, Bot as BotIcon, Map, Layers, CheckSquare, DollarSign, KeyRound as UsersRound, BookUser } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabaseClient';
import CanvaxLogo from '@/components/CanvaxLogo';
import ProtectedRoute from '@/components/ProtectedRoute';
import ChatbotWidget from '@/components/ChatbotWidget';

import { UserContext, ROLES } from '@/contexts/UserContext';
import { navItemsBase, getVisibleNavItems } from '@/config/navConfig';

import LoginPage from '@/pages/LoginPage';
import HomePage from '@/pages/HomePage';
import PlanificationPage from '@/pages/PlanificationPage';
import RoadmapsPage from '@/pages/RoadmapsPage';
import ConsolidationPage from '@/pages/ConsolidationPage';
import MonitoringPage from '@/pages/MonitoringPage';
import SupervisionPage from '@/pages/SupervisionPage';
import CommunautesPage from '@/pages/CommunautesPage';
import AdminUsersPage from '@/pages/AdminUsersPage';
import FilesPage from '@/pages/FilesPage';
import PlaceholderPage from '@/pages/PlaceholderPage';
import ResultsSynthesisPage from '@/pages/ResultsSynthesisPage';
import ContactPage from '@/pages/ContactPage';
import GeneralReportPage from '@/pages/GeneralReportPage';
import SpatialAnalysisPage from '@/pages/SpatialAnalysisPage';
import FinancialToolsPage from '@/pages/FinancialToolsPage'; 
import LogisticsRHPage from '@/pages/LogisticsRHPage';


function App() {
  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { userRole, setUserRole, supabaseUser, setSupabaseUser } = useContext(UserContext);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSupabaseUser(session?.user ?? null);
      if (session?.user) {
        const appRole = session.user.user_metadata?.app_role;
        if (appRole && ROLES[appRole]) {
          setUserRole(appRole);
          localStorage.setItem('userRole', appRole);
        } else {
           // If role not in metadata or invalid, sign out and clear
           await supabase.auth.signOut();
           setUserRole(null); 
           setSupabaseUser(null);
           localStorage.removeItem('userRole');
        }
      } else {
        setUserRole(null);
        localStorage.removeItem('userRole');
      }
    };
    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSupabaseUser(session?.user ?? null);
        if (session?.user) {
          const appRole = session.user.user_metadata?.app_role;
          if (appRole && ROLES[appRole]) {
            setUserRole(appRole);
            localStorage.setItem('userRole', appRole);
          } else {
             // If role change leads to invalid role, sign out
             await supabase.auth.signOut();
             setUserRole(null);
             setSupabaseUser(null); // Clear supabaseUser as well
             localStorage.removeItem('userRole');
             if (event !== 'SIGNED_OUT') { // Avoid double toast on explicit logout
                toast({title: "Erreur de rôle", description: "Votre rôle utilisateur n'est pas valide. Déconnexion.", variant: "destructive"});
             }
             navigate('/login'); // Redirect to login if role becomes invalid
          }
        } else {
          setUserRole(null);
          localStorage.removeItem('userRole');
        }
      }
    );
    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [setUserRole, setSupabaseUser, toast, navigate]);


  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    toast({
      title: `Thème ${!darkMode ? 'Sombre' : 'Clair'} Activé`,
      description: "L'apparence de l'application a été mise à jour.",
    });
  };

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({ title: "Erreur de déconnexion", description: error.message, variant: "destructive" });
    } else {
      setUserRole(null);
      setSupabaseUser(null);
      localStorage.removeItem('userRole');
      toast({ title: "Déconnexion", description: "Vous avez été déconnecté." });
      navigate('/login');
    }
  };

  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);
  
  const visibleNavItems = getVisibleNavItems(navItemsBase, supabaseUser, userRole);


  return (
      <div className="flex flex-col min-h-screen bg-background text-foreground transition-colors duration-300">
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-20 items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <motion.div whileHover={{ rotate: [0, 5, -5, 0], scale: 1.1 }}>
                <CanvaxLogo className="h-12 w-auto" />
              </motion.div>
              <div className="flex flex-col">
                <span className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">ACD/ACE CANVAX</span>
                <div className="flex items-center space-x-2 mt-1">
                  <img alt="Logo UNICEF" class="h-5" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/00633f1a6e94c26be6c0e0a71d12fbfb.png" />
                  <img alt="Logo MSP" class="h-5" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/8df8c17479f0de209036834303dc3504.png" />
                </div>
              </div>
            </Link>
            
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 text-sm font-medium">
              {visibleNavItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      "transition-colors hover:text-primary px-1.5 py-1 lg:px-2 rounded-md",
                      isActive ? "text-primary font-semibold bg-primary/10" : "text-muted-foreground"
                    )
                  }
                >
                  {item.name}
                </NavLink>
              ))}
            </nav>

            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={toggleDarkMode} aria-label="Toggle dark mode">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={darkMode ? "moon" : "sun"}
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 20, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  </motion.div>
                </AnimatePresence>
              </Button>
              {supabaseUser && userRole ? (
                <div className="flex items-center space-x-2">
                  <span className="hidden lg:inline text-sm text-muted-foreground">({ROLES[userRole] || userRole})</span>
                  <Button className="hidden md:inline-flex" onClick={handleLogout}>
                    <Users className="mr-2 h-4 w-4" /> Déconnexion
                  </Button>
                </div>
              ) : (
                <Button className="hidden md:inline-flex" asChild>
                  <Link to="/login"><LogIn className="mr-2 h-4 w-4" /> Se Connecter</Link>
                </Button>
              )}
              <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMobileMenu} aria-label="Open menu">
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
            >
              <nav className="flex flex-col space-y-2 p-4">
                {visibleNavItems.map((item) => (
                  <NavLink
                    key={item.name}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center space-x-3 px-3 py-2 rounded-md text-base font-medium transition-colors hover:bg-accent hover:text-accent-foreground",
                        isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                      )
                    }
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.name}</span>
                  </NavLink>
                ))}
                {supabaseUser && userRole && (
                  <Button className="w-full mt-2" onClick={() => { handleLogout(); setMobileMenuOpen(false); }}>
                    <Users className="mr-2 h-4 w-4" /> Déconnexion ({ROLES[userRole] || userRole})
                  </Button>
                )}
                 {!supabaseUser && !userRole && (
                   <Button className="w-full mt-2" asChild onClick={() => setMobileMenuOpen(false)}>
                     <Link to="/login"><LogIn className="mr-2 h-4 w-4" /> Se Connecter</Link>
                   </Button>
                 )}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
        
        <main className="flex-grow">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/" element={<HomePage />} />
              <Route path="/fichiers" element={<FilesPage />} />
              <Route path="/communautes" element={<ProtectedRoute><CommunautesPage /></ProtectedRoute>} />
              <Route path="/contact" element={<ContactPage />} />
              
              <Route path="/planification" element={<ProtectedRoute><PlanificationPage /></ProtectedRoute>} />
              <Route path="/feuilles-de-route" element={<ProtectedRoute><RoadmapsPage /></ProtectedRoute>} />
              <Route path="/consolidation-plans" element={<ProtectedRoute><ConsolidationPage /></ProtectedRoute>} />
              <Route path="/populations" element={<ProtectedRoute><PlaceholderPage title="Populations Cibles" /></ProtectedRoute>} />
              <Route path="/supervision" element={<ProtectedRoute><SupervisionPage /></ProtectedRoute>} />
              <Route path="/monitoring" element={<ProtectedRoute><MonitoringPage /></ProtectedRoute>} />
              <Route path="/analyse-spatiale" element={<ProtectedRoute><SpatialAnalysisPage /></ProtectedRoute>} />
              <Route path="/resultats-synthese" element={<ProtectedRoute><ResultsSynthesisPage /></ProtectedRoute>} />
              <Route path="/rapport-general" element={<ProtectedRoute><GeneralReportPage /></ProtectedRoute>} />
              <Route path="/outils-financiers" element={<ProtectedRoute><FinancialToolsPage /></ProtectedRoute>} />
              <Route path="/logistique-rh" element={<ProtectedRoute><LogisticsRHPage /></ProtectedRoute>} />
              <Route path="/admin/users" element={
                <ProtectedRoute requiredRole="ADMIN">
                  <AdminUsersPage />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute requiredRole="ADMIN">
                  <PlaceholderPage title="Paramètres" />
                </ProtectedRoute>
              } />
              
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </AnimatePresence>
        </main>
        
        <ChatbotWidget />

        <footer className="py-8 bg-secondary/50 border-t border-border/40">
          <div className="container mx-auto text-center text-muted-foreground text-sm">
            <div className="flex justify-center items-center space-x-4 mb-2">
                <img alt="Logo UNICEF footer" class="h-8" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/00633f1a6e94c26be6c0e0a71d12fbfb.png" />
                <img alt="Logo MSP footer" class="h-8" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/8df8c17479f0de209036834303dc3504.png" />
            </div>
            <p>&copy; {new Date().getFullYear()} ACD/ACE CANVAX. Développé par Dr KEBFENE Moundiné, MD, PhD.</p>
            <p>Atteindre Chaque District/Enfant (ACD/ACE) appuyé par le projet CANVAX - UNICEF - MSP.</p>
            <p className="mt-2">
              <a href="https://drkebfene.org" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                drkebfene.org
              </a>
            </p>
          </div>
        </footer>
        <Toaster />
      </div>
  );
}


const RootApp = () => {
  const [userRole, setUserRole] = useState(localStorage.getItem('userRole') || null);
  const [supabaseUser, setSupabaseUser] = useState(null);

  return (
    <UserContext.Provider value={{ userRole, setUserRole, supabaseUser, setSupabaseUser }}>
      <Router>
        <App />
      </Router>
    </UserContext.Provider>
  )
}

export default RootApp;

import { Home, FileText, Users2, ClipboardList, BarChart2, FolderOpen, Settings as SettingsIcon, Info, BarChartHorizontal, MessageCircle, Map, Layers, CheckSquare, DollarSign, KeyRound as UsersRound, BookUser } from 'lucide-react';
import { ROLES } from '@/contexts/UserContext';

export const navItemsBase = [
  { name: "Accueil", path: "/", icon: Home, isPublic: true, roles: [], description: "Page d'accueil et présentation du projet." },
  { name: "Planification", path: "/planification", icon: FileText, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Élaboration des micro-plans pour les Zones de Responsabilité." },
  { name: "Feuilles de Route", path: "/feuilles-de-route", icon: CheckSquare, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Suivi des feuilles de route pour chaque niveau opérationnel." },
  { name: "Consolidation", path: "/consolidation-plans", icon: Layers, roles: [ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Consolidation des plans et des données des niveaux inférieurs." },
  { name: "Populations", path: "/populations", icon: UsersRound, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Gestion des données démographiques et des cibles." },
  { name: "Supervision", path: "/supervision", icon: ClipboardList, roles: [ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Outils et rapports de supervision des activités." },
  { name: "Monitoring", path: "/monitoring", icon: BarChart2, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Tableaux de bord et suivi des indicateurs clés." },
  { name: "Analyses Avancées", path: "/analyse-spatiale", icon: Map, roles: [ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Analyse spatiale, qualitative et SIRA." },
  { name: "Outils Financiers", path: "/outils-financiers", icon: DollarSign, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Gestion budgétaire, rapports financiers et suivi." },
  { name: "Logistique & RH", path: "/logistique-rh", icon: Users2, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Planification logistique et gestion des ressources humaines." },
  { name: "Synthèse", path: "/resultats-synthese", icon: BarChartHorizontal, roles: [ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Synthèse des résultats et performances." },
  { name: "Rapports", path: "/rapport-general", icon: BookUser, roles: [ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Génération de rapports généraux et spécifiques." },
  { name: "Communautés", path: "/communautes", icon: MessageCircle, roles: [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.ADMIN, ROLES.MSP, ROLES.UNICEF, ROLES.DV], description: "Engagement communautaire, feedbacks et guides." },
  { name: "Fichiers", path: "/fichiers", icon: FolderOpen, isPublic: true, roles: [], description: "Bibliothèque de documents et ressources téléchargeables." },
  { name: "Admin", path: "/admin/users", icon: SettingsIcon, roles: [ROLES.ADMIN], description: "Gestion des utilisateurs et configuration système." },
  { name: "Contact", path: "/contact", icon: Info, isPublic: true, roles: [], description: "Contactez-nous pour plus d'informations ou du support." },
];

export const getVisibleNavItems = (navItems, supabaseUser, userRole) => {
  return navItems.filter(item => {
    if (item.isPublic) return true; // Public items are always visible
    if (!supabaseUser || !userRole) return false; // If not logged in or no role, non-public items are hidden

    // Ensure ROLES[userRole] is used if userRole is a key like 'CS', 'DS', etc.
    // If userRole is already the string value (e.g. "Centre de Santé"), it will still work
    // For consistency and to ensure it works with keys, use ROLES[userRole]
    const roleValue = ROLES[userRole] || userRole; // Fallback to userRole itself if not a key in ROLES
    
    return item.roles.includes(roleValue) || item.roles.includes(userRole); // Check against both key and value for robustness
  });
};

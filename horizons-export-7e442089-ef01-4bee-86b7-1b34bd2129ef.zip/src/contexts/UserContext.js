import React from 'react';

export const ROLES = {
  CS: 'Centre de Santé',
  DS: 'District Sanitaire',
  DSP: 'Délégation Provinciale Sanitaire',
  DV: 'Direction de la Vaccination',
  UNICEF: 'UNICEF',
  ADMIN: 'Administrateur',
  MSP: 'MSP', 
};

// Added supabaseUser and setSupabaseUser to the context
export const UserContext = React.createContext({ 
  userRole: null, 
  setUserRole: () => {},
  supabaseUser: null,
  setSupabaseUser: () => {} 
});
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, MinusCircle, TrendingUp, TrendingDown, Percent, BarChartBig } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ResultsSynthesisPage = () => {
  const [targets, setTargets] = useState([]);
  const [achievedData, setAchievedData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedLevel, setSelectedLevel] = useState('NATIONAL');
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data: targetsData, error: targetsError } = await supabase
          .from('expected_results_targets')
          .select('*');
        if (targetsError) throw targetsError;
        setTargets(targetsData);

        // For demonstration, we'll insert some mock achieved data if the table is empty
        // In a real scenario, this data would come from user input or other systems
        const { data: currentAchieved, error: achievedErrorCheck } = await supabase
          .from('achieved_results')
          .select('id', { count: 'exact', head: true });

        if (achievedErrorCheck && achievedErrorCheck.code !== 'PGRST116') { // PGRST116 means table is empty, which is fine for initial mock data
          throw achievedErrorCheck;
        }
        
        if (currentAchieved === null || (currentAchieved && currentAchieved.count === 0)) {
            const mockData = [
                { result_key: 'couverture_vaccinale', level_type: 'NATIONAL', level_name: 'National', achieved_value: 5, observation_date: '2025-05-01' },
                { result_key: 'taux_abandon', level_type: 'NATIONAL', level_name: 'National', achieved_value: -2, observation_date: '2025-05-01' },
                { result_key: 'taux_enregistrement', level_type: 'NATIONAL', level_name: 'National', achieved_value: 8, observation_date: '2025-05-01' },
                { result_key: 'rupture_vaccins', level_type: 'NATIONAL', level_name: 'National', achieved_value: 600, observation_date: '2025-05-01' },
                { result_key: 'dqs_realise', level_type: 'NATIONAL', level_name: 'National', achieved_value: 70, observation_date: '2025-05-01' },

                { result_key: 'couverture_vaccinale', level_type: 'PROVINCIAL', level_name: 'Province A', achieved_value: 7, observation_date: '2025-05-01' },
                { result_key: 'taux_abandon', level_type: 'PROVINCIAL', level_name: 'Province A', achieved_value: -1, observation_date: '2025-05-01' },
                { result_key: 'rupture_vaccins', level_type: 'DISTRICT', level_name: 'District X', achieved_value: 10, observation_date: '2025-05-01' }, // Assuming 10 ZR in District X
            ];
            const { error: mockInsertError } = await supabase.from('achieved_results').insert(mockData);
            if (mockInsertError) console.warn("Error inserting mock data:", mockInsertError.message);
        }


        const { data: achievedResultsData, error: achievedError } = await supabase
          .from('achieved_results')
          .select('*')
          .order('observation_date', { ascending: false });
        if (achievedError) throw achievedError;
        setAchievedData(achievedResultsData);

      } catch (err) {
        setError(err.message);
        toast({ title: "Erreur de chargement", description: `Impossible de charger les données: ${err.message}`, variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [toast]);

  const levels = useMemo(() => {
    const uniqueLevels = [...new Set(achievedData.map(item => item.level_type))];
    if (!uniqueLevels.includes('NATIONAL')) uniqueLevels.unshift('NATIONAL'); // Ensure National is an option
    return uniqueLevels.sort();
  }, [achievedData]);


  const synthesizedResults = useMemo(() => {
    if (!targets.length) return [];

    return targets.map(target => {
      const relevantAchieved = achievedData
        .filter(a => a.result_key === target.result_key && a.level_type === selectedLevel)
        // For simplicity, we take the latest entry per level_name. Real aggregation might be more complex.
        .reduce((acc, curr) => {
            if (!acc[curr.level_name] || new Date(curr.observation_date) > new Date(acc[curr.level_name].observation_date)) {
                acc[curr.level_name] = curr;
            }
            return acc;
        }, {});
        
      const aggregatedValues = Object.values(relevantAchieved);
      
      if (aggregatedValues.length === 0) {
        return {
          ...target,
          achieved_value: null,
          progress: 0,
          level_name: selectedLevel === 'NATIONAL' ? 'National' : `Données non disponibles pour ${selectedLevel}`,
        };
      }
      
      // For simplicity, if multiple entries for the same level (e.g. multiple provinces), average them.
      // Or, if it's 'NATIONAL', it should ideally be a single pre-aggregated entry.
      // This logic might need refinement based on how data is structured and aggregated for different levels.
      const averageAchieved = aggregatedValues.reduce((sum, item) => sum + parseFloat(item.achieved_value), 0) / aggregatedValues.length;
      
      let progress = 0;
      if (target.target_value !== null && target.target_value !== 0) {
        // For 'reduction' targets, progress calculation is different
        if (target.result_key === 'taux_abandon') { // Example: target is -5% (reduction)
            // If target is -5, and achieved is -2, progress is (-2 / -5) * 100 = 40%
            // If achieved is -6 (overachieved reduction), progress is (-6 / -5) * 100 clamped to 100% (or allow >100%)
            progress = (averageAchieved / target.target_value) * 100;
        } else {
             // For positive targets, if baseline is involved: (achieved - baseline) / (target - baseline)
            // Simplified: achieved / target * 100 if target is the change itself (e.g. +10 points)
            // Or (current_total / target_total) if target is an absolute value (e.g. 648 ZR)
            if (target.result_key === 'rupture_vaccins') { // Target is an absolute number of ZRs
                progress = (averageAchieved / target.target_value) * 100;
            } else { // Target is a change (e.g. +10 points)
                progress = (averageAchieved / target.target_value) * 100; 
            }
        }
      }
      progress = Math.max(0, Math.min(progress, 100)); // Cap progress at 0-100%

      return {
        ...target,
        achieved_value: averageAchieved,
        progress: isNaN(progress) ? 0 : progress,
        level_name: selectedLevel === 'NATIONAL' ? 'National' : `Moyenne ${selectedLevel}`, 
        // If there are multiple entries (e.g. for PROVINCIAL), this would be 'Moyenne PROVINCIAL'
        // or you might want to list each province individually. This part needs careful design.
      };
    });
  }, [targets, achievedData, selectedLevel]);

  const getProgressColor = (progress) => {
    if (progress < 33) return 'bg-red-500';
    if (progress < 66) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getIcon = (target, achieved) => {
    if (achieved === null || achieved === undefined) return <MinusCircle className="text-slate-500" />;
    
    // Handle reduction target (e.g., taux_abandon where target is negative)
    if (target.target_value < 0) {
      if (achieved <= target.target_value) return <CheckCircle className="text-green-500" />; // Achieved or exceeded reduction
      return <XCircle className="text-red-500" />; // Not met reduction target
    }

    // Handle regular targets (increase or absolute value)
    if (achieved >= target.target_value) return <CheckCircle className="text-green-500" />;
    return <XCircle className="text-red-500" />;
  };


  if (loading) {
    return <div className="container mx-auto p-8 text-center"><p className="text-xl text-purple-300">Chargement de la synthèse des résultats...</p></div>;
  }

  if (error) {
    return <div className="container mx-auto p-8 text-center"><p className="text-xl text-red-500">Erreur: {error}</p></div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">
          Synthèse des Résultats Attendus
        </h1>
        <div className="w-1/4">
          <Select value={selectedLevel} onValueChange={setSelectedLevel}>
            <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
              <SelectValue placeholder="Sélectionner un niveau" />
            </SelectTrigger>
            <SelectContent className="bg-slate-700 text-white">
              {levels.map(level => (
                <SelectItem key={level} value={level} className="hover:bg-slate-600">
                  {level.charAt(0).toUpperCase() + level.slice(1).toLowerCase()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle className="text-2xl text-purple-300">Progression vers les Objectifs ACD ({selectedLevel.charAt(0).toUpperCase() + selectedLevel.slice(1).toLowerCase()})</CardTitle>
          <CardDescription className="text-purple-100">
            Suivi des indicateurs clés par rapport aux cibles définies.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableCaption className="text-purple-200">Dernière mise à jour des données: {new Date().toLocaleDateString()}</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-1/3 text-pink-400">Résultat Attendu</TableHead>
                <TableHead className="text-pink-400">Cible</TableHead>
                <TableHead className="text-pink-400">Atteint ({selectedLevel})</TableHead>
                <TableHead className="text-pink-400">Progression</TableHead>
                <TableHead className="text-pink-400">Statut</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {synthesizedResults.map((item) => (
                <TableRow key={item.result_key} className="text-purple-100">
                  <TableCell className="font-medium">{item.description}</TableCell>
                  <TableCell>
                    {item.target_value > 0 ? <TrendingUp className="inline mr-1 h-4 w-4 text-green-400"/> : (item.target_value < 0 ? <TrendingDown className="inline mr-1 h-4 w-4 text-red-400"/> : '')}
                    {Math.abs(item.target_value)} {item.target_unit}
                  </TableCell>
                   <TableCell>
                    {item.achieved_value !== null ? 
                      `${item.achieved_value.toFixed(item.result_key === 'rupture_vaccins' ? 0 : 1)} ${item.target_unit}` : 
                      'N/A'}
                  </TableCell>
                  <TableCell>
                    {item.achieved_value !== null ? (
                      <div className="flex items-center">
                        <Progress value={item.progress} indicatorClassName={getProgressColor(item.progress)} className="w-3/4 mr-2 h-3" />
                        <span>{item.progress.toFixed(0)}%</span>
                      </div>
                    ) : 'N/A'}
                  </TableCell>
                  <TableCell className="flex justify-center">
                    {getIcon(item, item.achieved_value)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
           {synthesizedResults.length === 0 && (
            <p className="text-center py-4 text-purple-200">Aucune donnée de résultat disponible pour le niveau sélectionné.</p>
          )}
        </CardContent>
      </Card>
      <Card className="glassmorphism mt-8">
        <CardHeader>
            <CardTitle className="text-xl text-purple-300">Notes sur l'interprétation</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-purple-200 space-y-2">
            <p><Percent className="inline h-4 w-4 mr-1"/> Pour les couvertures vaccinales, taux d'abandon et taux d'enregistrement, la "cible" représente l'AMÉLIORATION attendue (ex: +10 points). "Atteint" reflète l'amélioration réalisée. La progression est (Atteint / Cible) * 100.</p>
            <p><BarChartBig className="inline h-4 w-4 mr-1"/> Pour "Aucune rupture de vaccins", la cible est le nombre total de ZR (648). "Atteint" est le nombre de ZR sans rupture. La progression est (Atteint / Cible) * 100.</p>
            <p><TrendingUp className="inline h-4 w-4 mr-1"/> Pour "DQS réalisé", la cible est un pourcentage de centres (80%). "Atteint" est le pourcentage réel. La progression est (Atteint / Cible) * 100.</p>
            <p><TrendingDown className="inline h-4 w-4 mr-1"/> Pour la réduction du taux d'abandon, une valeur "Atteint" plus négative (ou moins positive si le taux de base était positif) est meilleure. Ex: Cible -5 points. Si le taux d'abandon a diminué de 2 points, "Atteint" = -2.</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ResultsSynthesisPage;
import React, { useContext, useState } from 'react';
import { motion } from 'framer-motion';
import { Download, ExternalLink, BarChartHorizontal, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { Link } from 'react-router-dom';

const MonitoringPage = () => {
  const { userRole } = useContext(UserContext);
  const canEdit = userRole && [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.DV, ROLES.ADMIN, ROLES.MSP].includes(ROLES[userRole]);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    penta3: '',
    var_vac: '',
    sessions: '',
    abandon: '',
  });

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleDataSubmit = (e) => {
    e.preventDefault();
    console.log("Données de monitoring soumises:", formData);
    toast({
      title: "Données Soumises",
      description: "Vos données de monitoring ont été enregistrées (simulation).",
    });
    // Here you would typically send data to Supabase
    // e.g., await supabase.from('monitoring_data').insert([formData]);
    // Reset form or close dialog
  };
  
  const handleGenerateReport = () => {
    toast({ title: "Génération de Rapport", description: "Le rapport est en cours de génération et sera téléchargé." });
     window.open('/ACD/documents/Gabarit_Rapport_Mensuel.pptx', '_blank');
  };
  
  const sampleData = [
    { indicator: "Nombre d'enfants 0-11m vaccinés (Penta3)", target: 1200, achieved: 950, coverage: "79%" },
    { indicator: "Nombre d'enfants vaccinés VAR", target: 1100, achieved: 900, coverage: "82%" },
    { indicator: "Nombre de sessions de vaccination avancées réalisées", target: 50, achieved: 45, coverage: "90%" },
    { indicator: "Taux d'abandon (Penta1-Penta3)", target: "<10%", achieved: "8%", coverage: "N/A" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">Monitoring & Revue</h1>
      <Tabs defaultValue="saisie" className="w-full">
        <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 md:grid-cols-5 mb-6">
          <TabsTrigger value="saisie">Saisie Données</TabsTrigger>
          <TabsTrigger value="formulaireCollecte">Form. Collecte ACD</TabsTrigger>
          <TabsTrigger value="dashboard">Tableau de Bord</TabsTrigger>
          <TabsTrigger value="rapports">Rapports & Évaluation</TabsTrigger>
          <TabsTrigger value="syntheseResultats">Synthèse Résultats</TabsTrigger>
        </TabsList>
        <TabsContent value="saisie">
          <Card className="glassmorphism">
            <CardHeader>
                <CardTitle>Saisie des Données de Monitoring</CardTitle>
                <CardDescription className="text-purple-300">Saisissez les indicateurs clés de performance mensuels.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-purple-200">Utilisez le formulaire ci-dessous pour entrer les données de performance ACD.</p>
              {canEdit ? (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                      <Edit className="mr-2 h-4 w-4" /> Saisir les Données de Performance
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[625px]">
                    <DialogHeader>
                      <DialogTitle>Saisie des Indicateurs de Performance</DialogTitle>
                      <DialogDescription>Entrez les valeurs pour chaque indicateur ci-dessous.</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleDataSubmit} className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="penta3" className="text-right">Enfants vaccinés (Penta3)</Label>
                        <Input id="penta3" type="number" value={formData.penta3} onChange={handleInputChange} placeholder="Nombre" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="var_vac" className="text-right">Enfants vaccinés (VAR)</Label>
                        <Input id="var_vac" type="number" value={formData.var_vac} onChange={handleInputChange} placeholder="Nombre" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="sessions" className="text-right">Sessions de vaccination réalisées</Label>
                        <Input id="sessions" type="number" value={formData.sessions} onChange={handleInputChange} placeholder="Nombre" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="abandon" className="text-right">Taux d'abandon (Penta1-Penta3)</Label>
                        <Input id="abandon" type="text" value={formData.abandon} onChange={handleInputChange} placeholder="Ex: 8%" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                      </div>
                      <DialogFooter>
                        <Button type="submit">Soumettre les Données</Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              ) : <p className="text-muted-foreground">Vous n'avez pas les droits pour saisir des données.</p>}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="formulaireCollecte">
          <Card className="glassmorphism">
            <CardHeader>
              <CardTitle>Formulaire de Collecte des Indicateurs ACD</CardTitle>
              <CardDescription className="text-purple-300">Accédez au formulaire HTML interactif pour la saisie mensuelle des indicateurs clés.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="bg-gradient-to-r from-blue-500 to-sky-600 hover:from-blue-600 hover:to-sky-700 text-white">
                <a href="/ACD/Formulaire_Collecte_Indicateurs_ACD.html" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" /> Ouvrir le Formulaire de Collecte
                </a>
              </Button>
               <p className="mt-4 text-sm text-muted-foreground">Ce formulaire permet une saisie directe des données de performance de l'approche ACD. Les données soumises via ce formulaire externe ne sont pas automatiquement intégrées à cette plateforme (nécessite configuration).</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="dashboard">
          <Card className="glassmorphism">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Tableau de Bord de Pilotage ACD</CardTitle>
                <Button variant="outline" onClick={() => {
                  window.open('https://app.powerbi.com/home?experience=power-bi', '_blank'); /* Replace with actual PowerBI link if available */
                  toast({title: "Redirection Power BI", description: "Ouverture de Power BI dans un nouvel onglet. (Lien de démonstration)", duration: 3000 });
                }} className="border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-white">
                    <ExternalLink className="mr-2 h-4 w-4" /> Voir Power BI
                </Button>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-muted-foreground">Visualisez les indicateurs clés de performance (données d'exemple).</p>
              <Table>
                <TableCaption>Aperçu des indicateurs clés.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-purple-300">Indicateur</TableHead>
                    <TableHead className="text-purple-300">Cible</TableHead>
                    <TableHead className="text-purple-300">Atteint</TableHead>
                    <TableHead className="text-purple-300">Couverture/Statut</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sampleData.map((row, i) => (
                    <TableRow key={i} className="text-purple-100">
                      <TableCell>{row.indicator}</TableCell>
                      <TableCell>{row.target}</TableCell>
                      <TableCell>{row.achieved}</TableCell>
                      <TableCell>{row.coverage}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="rapports">
          <Card className="glassmorphism">
            <CardHeader><CardTitle>Génération de Rapports et Évaluation</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <p className="text-purple-200">Générez des rapports standards ou personnalisés pour le partage et les revues.</p>
              <Button onClick={handleGenerateReport} className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white"><Download className="mr-2 h-4 w-4" /> Gabarit Rapport Mensuel (.pptx)</Button>
              <Button variant="outline" asChild className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white">
                <a href="/ACD/documents/Cadre_Suivi_Evaluation.xlsx" download>
                    <Download className="mr-2 h-4 w-4" /> Cadre Suivi & Évaluation (.xlsx)
                </a>
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="syntheseResultats">
          <Card className="glassmorphism">
            <CardHeader>
              <CardTitle>Synthèse des Résultats Attendus</CardTitle>
              <CardDescription className="text-purple-300">Visualisation de la progression vers les résultats clés de l'ACD.</CardDescription>
            </CardHeader>
            <CardContent>
               <p className="mb-4 text-purple-200">Ce module affiche la synthèse des résultats par rapport aux cibles fixées.</p>
                <Button asChild className="bg-gradient-to-r from-indigo-500 to-cyan-600 hover:from-indigo-600 hover:to-cyan-700 text-white">
                  <Link to="/resultats-synthese">
                    <BarChartHorizontal className="mr-2 h-4 w-4" /> Voir la Synthèse des Résultats
                  </Link>
                </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default MonitoringPage;
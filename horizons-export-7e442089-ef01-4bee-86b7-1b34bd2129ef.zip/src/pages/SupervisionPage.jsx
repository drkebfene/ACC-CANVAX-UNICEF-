
import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { ClipboardList, Download, ExternalLink, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';

const supervisionGrids = [
    { name: "Grille Supervision Niveau Central", href: "/ACD/grille_supervision_central.html", description: "Pour la supervision des DSP/Régions." },
    { name: "Grille Supervision Niveau Provincial", href: "/ACD/grille_supervision_provincial.html", description: "Pour la supervision des Districts Sanitaires." },
    { name: "Grille Supervision Niveau District", href: "/ACD/grille_supervision_district.html", description: "Pour la supervision des Centres de Santé par l'ECD." },
    { name: "Grille Supervision Niveau Site (CS)", href: "/ACD/grille_supervision_site.html", description: "Pour la supervision/auto-évaluation des Centres de Santé." },
    { name: "Grille Supervision Niveau Communautaire", href: "/ACD/grille_supervision_communautaire.html", description: "Pour le suivi des relais communautaires." },
];

const SupervisionPage = () => {
  const { userRole } = useContext(UserContext);
  const { toast } = useToast();
  const canSupervise = userRole && [ROLES.DS, ROLES.DSP, ROLES.DV, ROLES.UNICEF, ROLES.ADMIN, ROLES.MSP].includes(ROLES[userRole]);

  const handleSimulatedSubmit = () => {
    toast({
        title: "Fiche de Supervision Soumise",
        description: "Vos données de supervision ont été sauvegardées (simulation).",
    });
    // Actual submission logic to Supabase would go here.
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">Supervision Formative ACD</h1>
      
      <Card className="glassmorphism mb-8">
        <CardHeader>
          <CardTitle>Grilles de Supervision Formative Interactives</CardTitle>
          <CardDescription className="text-purple-300">Accédez aux grilles HTML interactives. Chaque grille permet la saisie, l'impression et une soumission en ligne (simulée).</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {supervisionGrids.map(grid => (
              <motion.div
                key={grid.name}
                whileHover={{ scale: 1.03 }}
                className="rounded-lg overflow-hidden shadow-lg bg-slate-700/50 border border-slate-600 hover:border-purple-500/70"
              >
                <div className="p-5">
                  <h3 className="text-lg font-semibold text-purple-200 mb-2">{grid.name}</h3>
                  <p className="text-sm text-purple-300 mb-3 h-10">{grid.description}</p>
                  <Button variant="outline" asChild className="w-full text-pink-400 border-pink-500/50 hover:bg-pink-500/20 hover:text-pink-300">
                      <a href={grid.href} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="mr-2 h-4 w-4" /> Ouvrir la Grille
                      </a>
                  </Button>
                </div>
              </motion.div>
            ))}
        </CardContent>
      </Card>
      
      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle>Documentation et Saisie Centralisée des Supervisions</CardTitle>
          <CardDescription className="text-purple-300">Utilisez ce module pour saisir et centraliser les résultats de vos supervisions (basé sur le formulaire standard).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-purple-200">Cette section permettrait une saisie structurée des fiches de supervision directement dans la base de données de la plateforme.</p>
          {canSupervise ? (
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700">
                    <ClipboardList className="mr-2 h-4 w-4" /> Démarrer une Fiche de Supervision (Plateforme)
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[625px] glassmorphism">
                <DialogHeader>
                  <DialogTitle className="text-purple-200">Nouvelle Fiche de Supervision (Plateforme)</DialogTitle>
                  <DialogDescription className="text-purple-300">Remplissez les informations de la structure supervisée et les observations.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="structureNamePlatform" className="text-right text-purple-100">Structure</Label>
                    <Input id="structureNamePlatform" placeholder="Nom du CS/DS/Autre" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="supervisionDatePlatform" className="text-right text-purple-100">Date</Label>
                    <Input id="supervisionDatePlatform" type="date" className="col-span-3 bg-slate-700 border-slate-600 text-white" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="supervisorNamePlatform" className="text-right text-purple-100">Superviseur(s)</Label>
                    <Input id="supervisorNamePlatform" placeholder="Noms des superviseurs" className="col-span-3 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
                  </div>
                  <p className="text-sm text-muted-foreground col-span-4 mt-2">
                    Ici, des sections détaillées (ex: Planification, Logistique, Qualité des soins, Données, etc.) avec des champs spécifiques seraient disponibles pour une saisie structurée, reflétant le formulaire OMS.
                  </p>
                </div>
                <DialogFooter>
                  <Button type="button" onClick={handleSimulatedSubmit} className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                    <Send className="mr-2 h-4 w-4" /> Soumettre la Fiche
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          ) : <p className="text-muted-foreground">Vous n'avez pas les droits pour effectuer une supervision via ce module.</p>}
          
          <h3 className="text-xl font-semibold text-purple-300 pt-4 border-t border-slate-600/50">Ressources Utiles</h3>
          <Button variant="outline" asChild className="text-sky-400 border-sky-500/50 hover:bg-sky-500/20 hover:text-sky-300">
            <a href="/ACD/documents/Formulaire_OMS_Supervision.pdf" target="_blank" rel="noopener noreferrer">
                <Download className="mr-2 h-4 w-4" /> Formulaire OMS Supervision (PDF Standard)
            </a>
          </Button>
          <p className="text-sm text-muted-foreground">
            Le formulaire PDF standard de l'OMS est disponible pour consultation ou usage hors ligne. Les grilles interactives ci-dessus sont basées sur ce standard et adaptées pour chaque niveau.
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SupervisionPage;
  
import React from 'react';
import { motion } from 'framer-motion';
import ContactForm from '@/components/forms/ContactForm';
import { Mail, Phone, MapPin, User, Users, Building } from 'lucide-react';

const ContactPage = () => {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const equipeProjetNdjamena = [
    {
      icon: <User className="h-8 w-8 text-indigo-400" />,
      title: "Dr Victor Ngongalah (Chef de Section Santé)",
      detail: "vngongalah@unicef.org",
      href: "mailto:vngongalah@unicef.org",
    },
    {
      icon: <User className="h-8 w-8 text-teal-400" />,
      title: "Dr Antoine Ziao (Manager Immunisation)",
      detail: "aziao@unicef.org",
      href: "mailto:aziao@unicef.org",
    },
    {
      icon: <User className="h-8 w-8 text-cyan-400" />,
      title: "Dr Yangar Myandjingar (Spécialiste Immunisation)",
      detail: "ymyandjingar@unicef.org",
      href: "mailto:ymyandjingar@unicef.org",
    }
  ];

  const pointsFocauxMoundou = [
    {
      icon: <User className="h-8 w-8 text-green-400" />,
      title: "Dr KEBFENE Moundiné (Spécialiste Santé)",
      detail: "kmoundine@unicef.org",
      href: "mailto:kmoundine@unicef.org",
      phone: "+235 66 18 09 49",
      phoneHref: "tel:+23566180949"
    },
    {
      icon: <User className="h-8 w-8 text-lime-400" />,
      title: "Dr Gregoire Djekonbe (Chargé de Programme Immunisation)",
      detail: "gdjekonbe@unicef.org", // Email fictif, à remplacer si disponible
      href: "mailto:gdjekonbe@unicef.org"
    }
  ];


  const renderContactList = (contacts, sectionTitle, sectionIcon) => (
    <div className="mb-10">
      <div className="flex items-center mb-6">
        {sectionIcon}
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 ml-3">
          {sectionTitle}
        </h2>
      </div>
      <div className="space-y-8">
        {contacts.map((item, index) => (
          <motion.div 
            key={index} 
            className="flex items-start space-x-4 p-6 bg-slate-800/70 border border-slate-700 rounded-lg shadow-lg hover:shadow-purple-500/30 transition-shadow"
            variants={fadeIn}
          >
            <div className="flex-shrink-0 p-3 bg-slate-700/50 rounded-full">
              {item.icon}
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-100">{item.title}</h3>
              {item.href && (
                <a href={item.href} className="block text-purple-300 hover:text-purple-100 transition-colors break-all">
                  <Mail className="inline h-4 w-4 mr-1" /> {item.detail}
                </a>
              )}
              {item.phone && item.phoneHref && (
                 <a href={item.phoneHref} className="block text-purple-300 hover:text-purple-100 transition-colors break-all mt-1">
                   <Phone className="inline h-4 w-4 mr-1" /> {item.phone}
                 </a>
              )}
              {!item.href && !item.phone && !item.detail.includes('@') && ( // Pour l'adresse
                <p className="text-purple-300 break-all">{item.detail}</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div 
        className="container mx-auto max-w-5xl"
        initial="hidden"
        animate="visible"
        variants={{ visible: { transition: { staggerChildren: 0.1 }}}}
      >
        <motion.h1 
          className="text-5xl md:text-6xl font-extrabold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-400"
          variants={fadeIn}
        >
          Contactez-Nous
        </motion.h1>
        <motion.p 
          className="text-xl text-purple-200 mb-12 text-center max-w-2xl mx-auto"
          variants={fadeIn}
        >
          Nous sommes là pour vous aider. N'hésitez pas à nous envoyer un message pour toute question, suggestion ou demande de support.
        </motion.p>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <motion.div variants={fadeIn}>
            <ContactForm />
          </motion.div>
          
          <motion.div variants={fadeIn}>
            {renderContactList(equipeProjetNdjamena, "Équipe Projet (N'Djaména)", <Users className="h-10 w-10 text-purple-400" />)}
            {renderContactList(pointsFocauxMoundou, "Points Focaux (Moundou)", <Building className="h-10 w-10 text-pink-400" />)}
            
            <motion.div 
              className="mt-8 p-6 bg-slate-800/70 border border-slate-700 rounded-lg shadow-lg"
              variants={fadeIn}
            >
              <div className="flex items-center mb-3">
                <MapPin className="h-8 w-8 text-sky-400 mr-3" />
                <h3 className="text-xl font-semibold text-gray-100">Adresse (Bureau Moundou - Fictive)</h3>
              </div>
              <p className="text-purple-300">Bureau UNICEF, Moundou, Tchad</p>
            </motion.div>

             <motion.div 
                className="mt-8 p-6 bg-slate-800/70 border border-slate-700 rounded-lg shadow-lg"
                variants={fadeIn}
              >
                <h3 className="text-xl font-semibold text-gray-100 mb-3">Heures d'ouverture</h3>
                <p className="text-purple-300">Lundi - Vendredi: 08h00 - 17h00</p>
                <p className="text-purple-300">Samedi - Dimanche: Fermé</p>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default ContactPage;
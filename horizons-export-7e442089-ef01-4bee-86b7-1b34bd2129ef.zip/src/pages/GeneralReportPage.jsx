import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Download, BarChart3, Filter, FileText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const GeneralReportPage = () => {
  const [selectedLevel, setSelectedLevel] = useState('NATIONAL');
  const [reportData, setReportData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const levels = ['NATIONAL', 'PROVINCIAL', 'DISTRICT', 'ZR'];

  const generateMockData = (level) => {
    const baseCoverage = 60 + Math.random() * 20;
    const abandonRate = 5 + Math.random() * 10;
    return {
      level: level,
      periode: `Janvier - Mars ${new Date().getFullYear()}`,
      couverturePenta3: `${(baseCoverage).toFixed(1)}%`,
      couvertureRR1: `${(baseCoverage - 5 - Math.random() * 5).toFixed(1)}%`,
      tauxAbandonPenta1_3: `${abandonRate.toFixed(1)}%`,
      nombreSessionsRealisees: Math.floor(80 + Math.random() * 40),
      nombreEnfantsCibles: Math.floor(15000 + Math.random() * 5000),
      rupturesVaccins: Math.random() > 0.8 ? 'Oui (2 ZR)' : 'Non',
      recommandations: [
        `Renforcer la supervision des activités de vaccination au niveau ${level.toLowerCase()}.`,
        `Améliorer la mobilisation sociale pour réduire les abandons.`,
        `Assurer la disponibilité continue des vaccins et consommables.`,
      ],
      pointsForts: [
        `Bonne adhésion des communautés aux campagnes.`,
        `Engagement notable des agents de santé.`,
      ]
    };
  };

  const handleGenerateReport = () => {
    setIsLoading(true);
    setReportData(null);
    setTimeout(() => {
      setReportData(generateMockData(selectedLevel));
      setIsLoading(false);
      toast({
        title: "Rapport Généré (Simulation)",
        description: `Le rapport pour le niveau ${selectedLevel} est prêt à être visualisé.`,
      });
    }, 1500);
  };

  const handleDownloadPdf = () => {
    toast({
      title: "Téléchargement PDF (Bientôt Disponible)",
      description: "La fonctionnalité de téléchargement PDF sera implémentée prochainement.",
      variant: "default",
    });
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={fadeIn}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">
        Génération de Rapport Général
      </h1>
      
      <Card className="glassmorphism mb-8">
        <CardHeader>
          <CardTitle className="text-2xl text-purple-300">Paramètres du Rapport</CardTitle>
          <CardDescription className="text-purple-100">
            Sélectionnez le niveau pour lequel vous souhaitez générer un rapport de synthèse.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <div className="w-full sm:w-1/3">
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <Filter className="h-4 w-4 mr-2 opacity-70" />
                <SelectValue placeholder="Sélectionner un niveau" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                {levels.map(level => (
                  <SelectItem key={level} value={level} className="hover:bg-slate-600">
                    {level.charAt(0).toUpperCase() + level.slice(1).toLowerCase()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button 
            onClick={handleGenerateReport} 
            disabled={isLoading}
            className="w-full sm:w-auto bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white"
          >
            {isLoading ? (
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            ) : (
              <BarChart3 className="mr-2 h-5 w-5" />
            )}
            Générer le Rapport
          </Button>
        </CardContent>
      </Card>

      {isLoading && (
        <motion.div variants={fadeIn} className="text-center py-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-xl text-purple-200">Génération du rapport en cours...</p>
        </motion.div>
      )}

      {reportData && !isLoading && (
        <motion.div variants={fadeIn}>
          <Card className="glassmorphism">
            <CardHeader className="flex flex-row justify-between items-center">
              <div>
                <CardTitle className="text-3xl text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">
                  Rapport de Synthèse - Niveau {reportData.level}
                </CardTitle>
                <CardDescription className="text-purple-200">Période: {reportData.periode}</CardDescription>
              </div>
              <Button onClick={handleDownloadPdf} variant="outline" className="border-indigo-500 text-indigo-400 hover:bg-indigo-500 hover:text-white">
                <Download className="mr-2 h-4 w-4" /> Télécharger PDF (Bientôt)
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <InfoCard title="Couverture Penta3" value={reportData.couverturePenta3} />
                <InfoCard title="Couverture RR1" value={reportData.couvertureRR1} />
                <InfoCard title="Taux Abandon Penta1-3" value={reportData.tauxAbandonPenta1_3} />
                <InfoCard title="Sessions Réalisées" value={reportData.nombreSessionsRealisees.toString()} />
                <InfoCard title="Enfants Cibles" value={reportData.nombreEnfantsCibles.toLocaleString()} />
                <InfoCard title="Ruptures Vaccins" value={reportData.rupturesVaccins} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-slate-700/50">
                <SectionCard title="Points Forts" items={reportData.pointsForts} icon={<FileText className="h-6 w-6 text-green-400" />} />
                <SectionCard title="Recommandations" items={reportData.recommandations} icon={<FileText className="h-6 w-6 text-amber-400" />} />
              </div>
              
              <p className="text-sm text-muted-foreground pt-4 text-center">
                Ce rapport est une simulation basée sur des données fictives.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </motion.div>
  );
};

const InfoCard = ({ title, value }) => (
  <Card className="bg-slate-800/70 border-slate-700 shadow-lg hover:shadow-purple-500/30 transition-shadow">
    <CardHeader>
      <CardTitle className="text-lg text-purple-300">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-3xl font-bold text-gray-100">{value}</p>
    </CardContent>
  </Card>
);

const SectionCard = ({ title, items, icon }) => (
  <Card className="bg-slate-800/70 border-slate-700 shadow-lg">
    <CardHeader className="flex flex-row items-center space-x-3">
      {icon}
      <CardTitle className="text-xl text-purple-300">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <ul className="list-disc list-inside space-y-1 text-purple-100">
        {items.map((item, index) => <li key={index}>{item}</li>)}
      </ul>
    </CardContent>
  </Card>
);

export default GeneralReportPage;
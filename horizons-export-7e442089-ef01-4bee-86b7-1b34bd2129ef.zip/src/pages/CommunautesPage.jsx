import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, MessageSquare, FileText, Download, Send, Edit3, CheckSquare, Radio, Mic } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';


const SectionTitle = ({ children, icon: Icon, className = "text-purple-300" }) => (
  <h2 className={`text-2xl font-semibold ${className} mb-4 flex items-center`}>
    {Icon && <Icon className={`mr-3 h-7 w-7 ${className.replace('text-', 'text-')}`} />}
    {children}
  </h2>
);

const GuideSection = ({ title, children, level = 3, className = "text-pink-300" }) => {
  const Tag = `h${level}`;
  return (
    <div className="mb-4">
      <Tag className={`text-xl font-semibold ${className} mb-2`}>{title}</Tag>
      <div className="space-y-2 text-purple-100/90">{children}</div>
    </div>
  );
};

const FeedbackFormField = ({ label, children, htmlFor }) => (
  <div className="mb-4">
    <Label htmlFor={htmlFor} className="block text-sm font-medium text-pink-200 mb-1">{label}</Label>
    {children}
  </div>
);


const GuideMobilisationSocialeContent = () => {
  const tableDataActivitesCles = [
    { activite: "Cartographie des zones à faible couverture", responsable: "DS / DSP", frequence: "Une fois", ressources: "Données de couverture" },
    { activite: "Réunion d’engagement avec les leaders", responsable: "DSP / ONG partenaires", frequence: "Trimestrielle", ressources: "Invitations, salle" },
    { activite: "Production de supports IEC en langues locales", responsable: "Communication", frequence: "Mensuelle", ressources: "Infographies, impressions" },
    { activite: "Diffusion de messages radios", responsable: "Partenaires médias", frequence: "Hebdomadaire", ressources: "Contrats radios" },
    { activite: "Suivi des rumeurs et rétroactions", responsable: "ASC / DS", frequence: "Continu", ressources: "Fiches d’enquête, WhatsApp" },
  ];

  const tableDataRolesResponsabilites = [
    { acteur: "DSP", role: "Coordination provinciale des activités" },
    { acteur: "DS", role: "Supervision et mise en œuvre locale" },
    { acteur: "ASC / relais communautaires", role: "Sensibilisation et mobilisation de proximité" },
    { acteur: "ONG partenaires", role: "Appui technique et logistique" },
    { acteur: "UNICEF / Ministère de la Santé", role: "Orientation stratégique, formation, financement" },
  ];

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="text-3xl text-purple-200 flex items-center">
          <Users className="mr-3 h-8 w-8" /> Guide de Mobilisation Sociale pour l’Approche ACD
        </CardTitle>
        <CardDescription className="text-purple-300">
          Cadre opérationnel pour planifier, exécuter, suivre et évaluer les activités de mobilisation sociale.
        </CardDescription>
        <Button variant="outline" asChild className="mt-4 border-pink-500 text-pink-400 hover:bg-pink-500 hover:text-white w-fit">
          <a href="/ACD/documents/Guide_Mobilisation_Sociale_ACD.pdf" download="Guide_Mobilisation_Sociale_ACD.pdf">
            <Download className="mr-2 h-4 w-4" /> Télécharger le Guide (PDF)
          </a>
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <GuideSection title="1. Introduction" level={2}>
          <p>La mobilisation sociale est un pilier central de l’Approche ACD (Atteindre Chaque District), visant à renforcer l’adhésion communautaire, garantir l'accès équitable à la vaccination, et améliorer la couverture vaccinale des enfants de 0 à 23 mois. Ce guide fournit un cadre opérationnel pour planifier, exécuter, suivre et évaluer les activités de mobilisation sociale à tous les niveaux.</p>
        </GuideSection>
        <GuideSection title="2. Objectifs" level={2}>
          <GuideSection title="Objectif Général :">
            <p>Renforcer l’engagement communautaire et la demande de vaccination à travers des stratégies de mobilisation sociale intégrées et adaptées aux contextes locaux.</p>
          </GuideSection>
          <GuideSection title="Objectifs spécifiques :">
            <ul className="list-disc list-inside ml-4">
              <li>Informer les communautés cibles sur l’ACD et l’importance de la vaccination.</li>
              <li>Renforcer la participation active des leaders d’opinion et communautaires.</li>
              <li>Identifier et lever les obstacles à la vaccination (rumeurs, hésitations).</li>
              <li>Promouvoir l’adhésion communautaire durable.</li>
            </ul>
          </GuideSection>
        </GuideSection>
        <GuideSection title="3. Publics cibles" level={2}>
          <ul className="list-disc list-inside ml-4 grid grid-cols-1 md:grid-cols-2 gap-x-4">
            <li>Parents/tuteurs d’enfants de 0 à 23 mois</li>
            <li>Femmes en âge de procréer</li>
            <li>Leaders religieux et traditionnels</li>
            <li>Chefs de village/quartier</li>
            <li>Groupes de jeunes, associations de femmes</li>
            <li>Enseignants et responsables scolaires</li>
            <li>Agents communautaires (ASC, relais communautaires)</li>
          </ul>
        </GuideSection>
        <GuideSection title="4. Principes directeurs" level={2}>
           <ul className="list-disc list-inside ml-4">
              <li>Approche participative : impliquer activement les communautés.</li>
              <li>Adaptation culturelle : messages contextualisés selon les coutumes locales.</li>
              <li>Communication fondée sur les données : cibler les zones à faible couverture vaccinale.</li>
              <li>Transparence et redevabilité : retour d’information aux communautés.</li>
            </ul>
        </GuideSection>
        <GuideSection title="5. Stratégies de mobilisation sociale" level={2}>
          <GuideSection title="5.1. Sensibilisation de proximité">
            <ul className="list-disc list-inside ml-4"><li>Causeries éducatives</li><li>Visites à domicile</li><li>Forums communautaires</li><li>Projection de films éducatifs</li></ul>
          </GuideSection>
          <GuideSection title="5.2. Engagement des leaders communautaires">
            <ul className="list-disc list-inside ml-4"><li>Réunions de plaidoyer</li><li>Déclarations publiques de soutien</li><li>Implication dans les microplans ACD</li></ul>
          </GuideSection>
          <GuideSection title="5.3. Communication de masse">
            <ul className="list-disc list-inside ml-4"><li>Radios communautaires (spots, débats interactifs)</li><li>Affiches et banderoles en langues locales</li><li>Mégaphonie dans les marchés et lieux de rassemblement</li></ul>
          </GuideSection>
          <GuideSection title="5.4. Mobilisation numérique (si applicable)">
            <ul className="list-disc list-inside ml-4"><li>Messages SMS de rappel de vaccination</li><li>Groupes WhatsApp communautaires</li><li>Capsules vidéos sur les réseaux sociaux</li></ul>
          </GuideSection>
        </GuideSection>
        <GuideSection title="6. Activités clés à planifier" level={2}>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-700">
              <thead className="bg-slate-700/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Activité</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Responsable</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Fréquence</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Ressources nécessaires</th>
                </tr>
              </thead>
              <tbody className="bg-slate-800/30 divide-y divide-slate-700">
                {tableDataActivitesCles.map((item, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.activite}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.responsable}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.frequence}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.ressources}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GuideSection>
        <GuideSection title="7. Matériels et supports" level={2}>
          <ul className="list-disc list-inside ml-4 grid grid-cols-1 md:grid-cols-2 gap-x-4">
            <li>Fiches de causeries</li>
            <li>Fiches de collecte de rétroaction</li>
            <li>Posters illustrés en langues locales</li>
            <li>T-shirts et banderoles pour les relais</li>
            <li>Boîtes à images</li>
            <li>Carnets de mobilisation pour les relais communautaires</li>
          </ul>
        </GuideSection>
        <GuideSection title="8. Suivi et évaluation" level={2}>
          <GuideSection title="Indicateurs de performance :">
            <ul className="list-disc list-inside ml-4">
              <li>Nombre de causeries communautaires réalisées</li>
              <li>% de leaders impliqués dans les activités ACD</li>
              <li>Nombre de personnes sensibilisées (hommes/femmes)</li>
              <li>% de rumeurs collectées et traitées</li>
              <li>Taux d’adhésion des mères (par zone)</li>
            </ul>
          </GuideSection>
          <GuideSection title="Outils de suivi :">
            <ul className="list-disc list-inside ml-4">
              <li>Registres de mobilisation sociale</li>
              <li>Rapports mensuels de supervision</li>
              <li>Fiches de suivi de rétroaction communautaire</li>
              <li>Tableau de bord intégré au site CANVAX</li>
            </ul>
          </GuideSection>
        </GuideSection>
        <GuideSection title="9. Rôles et responsabilités" level={2}>
           <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-700">
              <thead className="bg-slate-700/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Acteurs</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-300 uppercase tracking-wider">Rôle spécifique</th>
                </tr>
              </thead>
              <tbody className="bg-slate-800/30 divide-y divide-slate-700">
                {tableDataRolesResponsabilites.map((item, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.acteur}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-100">{item.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GuideSection>
        <GuideSection title="10. Calendrier indicatif de mise en œuvre" level={2}>
          <ul className="list-disc list-inside ml-4">
              <li><strong>Mois 1:</strong> Cartographie, formation des relais</li>
              <li><strong>Mois 2:</strong> Sensibilisation pilote dans 3 districts</li>
              <li><strong>Mois 3–6:</strong> Extension, supervision, documentation</li>
              <li><strong>Mois 6:</strong> Revue communautaire participative</li>
          </ul>
        </GuideSection>
        <GuideSection title="11. Annexes" level={2}>
          <p>Les annexes (Fiches types de causeries, Grille de supervision communautaire, Exemple de fiche de rétroaction, Plan média et contrat-type de radios communautaires, Formulaire de suivi des rumeurs) sont disponibles dans la version PDF téléchargeable du guide.</p>
        </GuideSection>
      </CardContent>
    </Card>
  );
};

const FicheFeedbackCommunautaireForm = () => {
  const { toast } = useToast();
  const [feedbackData, setFeedbackData] = useState({
    province: '', district: '', localite: '', date: new Date().toISOString().slice(0,10), agentName: '', agentPhone: '',
    personGender: '', personAge: '', personGroup: '', personChildLink: '',
    heardOfCanvax: '', heardChannel: '',
    vaccinesBeneficial: '', communityConcerns: '', communityConcernsDetails: '',
    heardRumors: '', rumorDescription: '', rumorFrequency: '', rumorOrigin: '',
    communitySuggestions: '', mobilizerObservations: '',
    actionNeeded: '', transmitTo: '', actionDone: ''
  });

  const handleFeedbackChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFeedbackData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  const handleFeedbackSelectChange = (name, value) => {
     setFeedbackData(prev => ({ ...prev, [name]: value }));
  };

  const handleFeedbackSubmit = (e) => {
    e.preventDefault();
    console.log("Feedback communautaire soumis (simulation):", feedbackData);
    toast({
      title: "Feedback Soumis (Simulation)",
      description: "Votre fiche de feedback communautaire a été enregistrée (simulation).",
    });
  };

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="text-3xl text-purple-200 flex items-center">
          <MessageSquare className="mr-3 h-8 w-8" /> Fiche de Feedback Communautaire
        </CardTitle>
        <CardDescription className="text-purple-300">
          Recueillez les perceptions, préoccupations, suggestions et rumeurs autour de la vaccination.
        </CardDescription>
         <Button variant="outline" asChild className="mt-4 border-pink-500 text-pink-400 hover:bg-pink-500 hover:text-white w-fit">
          <a href="/ACD/documents/Fiche_Feedback_Communautaire.pdf" download="Fiche_Feedback_Communautaire.pdf">
            <Download className="mr-2 h-4 w-4" /> Télécharger Modèle (PDF)
          </a>
        </Button>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleFeedbackSubmit} className="space-y-6">
          <SectionTitle icon={FileText}>Informations Générales</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <FeedbackFormField label="Province" htmlFor="province"><Input id="province" name="province" value={feedbackData.province} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="District Sanitaire" htmlFor="district"><Input id="district" name="district" value={feedbackData.district} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="Localité / Village / Quartier" htmlFor="localite"><Input id="localite" name="localite" value={feedbackData.localite} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="Date" htmlFor="date"><Input id="date" name="date" type="date" value={feedbackData.date} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="Nom de l’agent enquêteur / relais" htmlFor="agentName"><Input id="agentName" name="agentName" value={feedbackData.agentName} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="Numéro de téléphone (agent)" htmlFor="agentPhone"><Input id="agentPhone" name="agentPhone" type="tel" value={feedbackData.agentPhone} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
          </div>

          <SectionTitle icon={Users}>1. Profil de la personne interrogée</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <FeedbackFormField label="Sexe" htmlFor="personGender">
              <Select name="personGender" value={feedbackData.personGender} onValueChange={(value) => handleFeedbackSelectChange('personGender', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white"><SelectItem value="homme">Homme</SelectItem><SelectItem value="femme">Femme</SelectItem></SelectContent>
              </Select>
            </FeedbackFormField>
            <FeedbackFormField label="Âge (ans)" htmlFor="personAge"><Input id="personAge" name="personAge" type="number" value={feedbackData.personAge} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" /></FeedbackFormField>
            <FeedbackFormField label="Groupe cible" htmlFor="personGroup">
               <Select name="personGroup" value={feedbackData.personGroup} onValueChange={(value) => handleFeedbackSelectChange('personGroup', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white">
                  <SelectItem value="parent">Parent</SelectItem><SelectItem value="leader">Leader communautaire</SelectItem>
                  <SelectItem value="enseignant">Enseignant</SelectItem><SelectItem value="autre_groupe">Autre</SelectItem>
                </SelectContent>
              </Select>
            </FeedbackFormField>
            <FeedbackFormField label="Lien avec enfant" htmlFor="personChildLink">
              <Select name="personChildLink" value={feedbackData.personChildLink} onValueChange={(value) => handleFeedbackSelectChange('personChildLink', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white">
                  <SelectItem value="mere">Mère</SelectItem><SelectItem value="pere">Père</SelectItem>
                  <SelectItem value="grand_parent">Grand-parent</SelectItem><SelectItem value="autre_lien">Autre</SelectItem>
                </SelectContent>
              </Select>
            </FeedbackFormField>
          </div>
          
          <SectionTitle icon={Radio}>2. Avez-vous entendu parler de la campagne ACD ou du projet CANVAX ?</SectionTitle>
           <FeedbackFormField label="" htmlFor="heardOfCanvax">
              <Select name="heardOfCanvax" value={feedbackData.heardOfCanvax} onValueChange={(value) => handleFeedbackSelectChange('heardOfCanvax', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white"><SelectItem value="oui">Oui</SelectItem><SelectItem value="non">Non</SelectItem></SelectContent>
              </Select>
            </FeedbackFormField>
          {feedbackData.heardOfCanvax === 'oui' && (
            <FeedbackFormField label="Si oui, par quel canal ?" htmlFor="heardChannel">
              <Input id="heardChannel" name="heardChannel" value={feedbackData.heardChannel} onChange={handleFeedbackChange} placeholder="Radio locale, Causerie, Leader..." className="bg-slate-700 border-slate-600" />
            </FeedbackFormField>
          )}

          <SectionTitle icon={CheckSquare}>3. Perceptions sur la vaccination</SectionTitle>
          <FeedbackFormField label="Pensez-vous que les vaccins sont bénéfiques pour les enfants ?" htmlFor="vaccinesBeneficial">
             <Select name="vaccinesBeneficial" value={feedbackData.vaccinesBeneficial} onValueChange={(value) => handleFeedbackSelectChange('vaccinesBeneficial', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white"><SelectItem value="oui">Oui</SelectItem><SelectItem value="non">Non</SelectItem><SelectItem value="ne_sait_pas">Ne sait pas</SelectItem></SelectContent>
              </Select>
          </FeedbackFormField>
          <FeedbackFormField label="Y a-t-il des inquiétudes dans votre communauté au sujet des vaccins ?" htmlFor="communityConcerns">
             <Select name="communityConcerns" value={feedbackData.communityConcerns} onValueChange={(value) => handleFeedbackSelectChange('communityConcerns', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white"><SelectItem value="oui">Oui</SelectItem><SelectItem value="non">Non</SelectItem></SelectContent>
              </Select>
          </FeedbackFormField>
          {feedbackData.communityConcerns === 'oui' && (
            <FeedbackFormField label="Si oui, lesquelles ?" htmlFor="communityConcernsDetails">
              <Textarea id="communityConcernsDetails" name="communityConcernsDetails" value={feedbackData.communityConcernsDetails} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" />
            </FeedbackFormField>
          )}

          <SectionTitle icon={Edit3}>4. Identification des rumeurs ou fausses croyances</SectionTitle>
           <FeedbackFormField label="Avez-vous entendu des rumeurs ou fausses informations concernant la vaccination ?" htmlFor="heardRumors">
             <Select name="heardRumors" value={feedbackData.heardRumors} onValueChange={(value) => handleFeedbackSelectChange('heardRumors', value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                <SelectContent className="bg-slate-700 text-white"><SelectItem value="oui">Oui</SelectItem><SelectItem value="non">Non</SelectItem></SelectContent>
              </Select>
          </FeedbackFormField>
          {feedbackData.heardRumors === 'oui' && (
            <>
              <FeedbackFormField label="Si oui, décrivez la rumeur ou le malentendu :" htmlFor="rumorDescription">
                <Textarea id="rumorDescription" name="rumorDescription" value={feedbackData.rumorDescription} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" />
              </FeedbackFormField>
              <FeedbackFormField label="Fréquence d’occurrence :" htmlFor="rumorFrequency">
                 <Select name="rumorFrequency" value={feedbackData.rumorFrequency} onValueChange={(value) => handleFeedbackSelectChange('rumorFrequency', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                    <SelectContent className="bg-slate-700 text-white">
                      <SelectItem value="rarement">Rarement</SelectItem><SelectItem value="parfois">Parfois</SelectItem><SelectItem value="tres_frequent">Très fréquent</SelectItem>
                    </SelectContent>
                  </Select>
              </FeedbackFormField>
              <FeedbackFormField label="Origine perçue (ex. radio, religieux, réseaux sociaux, etc.) :" htmlFor="rumorOrigin">
                <Input id="rumorOrigin" name="rumorOrigin" value={feedbackData.rumorOrigin} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" />
              </FeedbackFormField>
            </>
          )}
          
          <SectionTitle icon={MessageSquare}>5. Suggestions de la communauté pour améliorer la vaccination</SectionTitle>
          <FeedbackFormField label="" htmlFor="communitySuggestions">
            <Textarea id="communitySuggestions" name="communitySuggestions" value={feedbackData.communitySuggestions} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" />
          </FeedbackFormField>

          <SectionTitle icon={Edit3}>6. Observations de l’agent mobilisateur</SectionTitle>
           <FeedbackFormField label="" htmlFor="mobilizerObservations">
            <Textarea id="mobilizerObservations" name="mobilizerObservations" value={feedbackData.mobilizerObservations} onChange={handleFeedbackChange} className="bg-slate-700 border-slate-600" />
          </FeedbackFormField>

          <SectionTitle icon={Send}>7. Suivi / Actions recommandées</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FeedbackFormField label="Action nécessaire" htmlFor="actionNeeded">
              <Input id="actionNeeded" name="actionNeeded" value={feedbackData.actionNeeded} onChange={handleFeedbackChange} placeholder="Sensibilisation ciblée..." className="bg-slate-700 border-slate-600" />
            </FeedbackFormField>
            <FeedbackFormField label="À transmettre à" htmlFor="transmitTo">
              <Input id="transmitTo" name="transmitTo" value={feedbackData.transmitTo} onChange={handleFeedbackChange} placeholder="Équipe comm, District..." className="bg-slate-700 border-slate-600" />
            </FeedbackFormField>
            <FeedbackFormField label="Réalisé ?" htmlFor="actionDone">
               <Select name="actionDone" value={feedbackData.actionDone} onValueChange={(value) => handleFeedbackSelectChange('actionDone', value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600"><SelectValue placeholder="Choisir..." /></SelectTrigger>
                  <SelectContent className="bg-slate-700 text-white"><SelectItem value="oui">Oui</SelectItem><SelectItem value="non">Non</SelectItem></SelectContent>
                </Select>
            </FeedbackFormField>
          </div>

          <Button type="submit" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
            <Send className="mr-2 h-4 w-4" /> Soumettre le Feedback (Simulation)
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

const GuideEntretienCommunautaireContent = () => {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="text-3xl text-green-200 flex items-center">
          <Mic className="mr-3 h-8 w-8" /> Guide d’Entretien Communautaire – Projet CANVAX / ACD
        </CardTitle>
        <CardDescription className="text-green-300">
          Pour agents communautaires, enquêteurs, superviseurs ou partenaires techniques.
        </CardDescription>
        <Button variant="outline" asChild className="mt-4 border-green-500 text-green-400 hover:bg-green-500 hover:text-white w-fit">
          <a href="/ACD/documents/Guide_Entretien_Communautaire_ACD.pdf" download="Guide_Entretien_Communautaire_ACD.pdf">
            <Download className="mr-2 h-4 w-4" /> Télécharger le Guide (PDF)
          </a>
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <GuideSection title="📍 Objectif général :" level={2} className="text-green-300">
          <p>Recueillir les perceptions, les expériences, les obstacles, les rumeurs et les suggestions des communautés concernant les activités de vaccination dans le cadre de l’Approche ACD.</p>
        </GuideSection>

        <GuideSection title="🧩 I. Informations générales" level={2} className="text-green-300">
          <ul className="list-none space-y-1">
            <li>Localité / Village / Quartier : ................................................</li>
            <li>District Sanitaire : ................................................</li>
            <li>Province : ☐ Mandoul ☐ Moyen-Chari ☐ Mayo Kebbi Ouest</li>
            <li>Date de l’entretien : ____ / ____ / 2025</li>
            <li>Type d’entretien : ☐ Individuel ☐ Focus Group</li>
            <li>Nom de l’enquêteur / facilitateur : ................................................</li>
            <li>Nombre de participants (si focus group) : _________</li>
          </ul>
        </GuideSection>

        <GuideSection title="🗣️ II. Introduction à lire aux participants :" level={2} className="text-green-300">
          <p className="italic">Bonjour ! Nous vous remercions de participer à cette discussion. Nous menons cette enquête pour mieux comprendre comment les parents et les communautés perçoivent les services de vaccination dans votre zone. Vos réponses sont confidentielles, il n’y a pas de bonnes ou de mauvaises réponses. Vous êtes libres de participer ou de vous retirer à tout moment.</p>
        </GuideSection>

        <GuideSection title="🧶 III. Questions principales" level={2} className="text-green-300">
          <GuideSection title="1. Connaissances et informations générales" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Avez-vous entendu parler de la campagne de vaccination ACD / CANVAX dans votre communauté ?</li>
              <li>Qu’est-ce que vous en savez ? Par qui avez-vous été informé ?</li>
              <li>Avez-vous reçu des visites de sensibilisation à domicile ? Par qui ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="2. Perception des services de vaccination" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Selon vous, pourquoi est-il important de faire vacciner les enfants ?</li>
              <li>Que pensez-vous de la qualité des services de vaccination dans votre localité ?</li>
              <li>Qu’est-ce qui s’est bien passé lors des dernières activités de vaccination ?</li>
              <li>Qu’est-ce qui pourrait être amélioré ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="3. Barrières et obstacles" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Est-ce qu’il y a des raisons pour lesquelles certains enfants ne sont pas vaccinés ?</li>
              <li>Quelles sont les principales difficultés que rencontrent les parents pour faire vacciner leurs enfants ? (ex. distance, coût, désinformation)</li>
              <li>Y a-t-il des groupes ou personnes dans la communauté qui refusent ou hésitent à faire vacciner leurs enfants ? Pourquoi ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="4. Rumeurs, malentendus et fausses croyances" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Avez-vous entendu des rumeurs ou des fausses informations concernant les vaccins ou les agents vaccinateurs ?</li>
              <li>Pouvez-vous nous dire ce que vous avez entendu ?</li>
              <li>Comment ces rumeurs affectent-elles la participation à la vaccination ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="5. Engagement communautaire et rôle des leaders" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Les chefs traditionnels, religieux, enseignants ou autres leaders soutiennent-ils les activités de vaccination ?</li>
              <li>Comment leur implication pourrait-elle être renforcée ?</li>
              <li>Y a-t-il eu des actions positives menées par la communauté pour encourager la vaccination ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="6. Expériences personnelles ou témoignages" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Pouvez-vous partager une expérience (positive ou négative) liée à la vaccination de vos enfants ?</li>
              <li>Avez-vous eu des inquiétudes ou des effets secondaires après une vaccination ? Si oui, que s’est-il passé ?</li>
            </ul>
          </GuideSection>
          <GuideSection title="7. Suggestions d’amélioration" className="text-lime-300">
            <ul className="list-disc list-inside ml-4">
              <li>Que proposeriez-vous pour améliorer l’organisation des campagnes de vaccination ?</li>
              <li>Quel serait le meilleur moyen de communiquer avec les parents dans votre village/quartier ?</li>
              <li>Quels jours ou heures sont les plus adaptés pour les vaccinations dans votre communauté ?</li>
            </ul>
          </GuideSection>
        </GuideSection>

        <GuideSection title="📋 IV. Observations du facilitateur" level={2} className="text-green-300">
          <p>Noter ici les attitudes, interactions, préoccupations non verbalisées, réactions à certaines questions…</p>
          <Textarea readOnly placeholder="..................................................................................." className="bg-slate-700/50 border-slate-600 text-purple-100 h-24" />
        </GuideSection>

        <GuideSection title="✅ V. Clôture de l’entretien" level={2} className="text-green-300">
          <p className="italic">Merci pour votre participation. Vos points de vue sont très importants pour améliorer nos actions en faveur de la santé des enfants. Nous transmettrons vos messages à ceux qui organisent les campagnes.</p>
        </GuideSection>
      </CardContent>
    </Card>
  );
};

const AutresRessourcesCommunautairesContent = () => {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="text-3xl text-purple-200 flex items-center">
          <FileText className="mr-3 h-8 w-8" /> Autres Ressources Communautaires
        </CardTitle>
        <CardDescription className="text-purple-300">
          Documents et outils supplémentaires pour l'engagement communautaire.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-purple-100">Cette section sera enrichie avec d'autres outils et documents utiles pour la mobilisation sociale et l'engagement communautaire.</p>
        <Button variant="outline" asChild className="border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-white">
          <a href="/ACD/documents/Guide_Mobilisation_Communautaire.pdf" download>
            <Download className="mr-2 h-4 w-4" /> Guide Mobilisation (PDF existant)
          </a>
        </Button>
          <Button variant="outline" asChild className="border-sky-500 text-sky-400 hover:bg-sky-500 hover:text-white">
          <a href="/ACD/documents/Scripts_Radio_ACD.txt" download>
            <Download className="mr-2 h-4 w-4" /> Exemples Scripts Radio (TXT)
          </a>
        </Button>
      </CardContent>
    </Card>
  );
};


const CommunautesPage = () => {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={fadeIn}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">
        Engagement Communautaire & Mobilisation Sociale
      </h1>

      <Tabs defaultValue="guide_mobilisation" className="w-full">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-4 mb-6">
          <TabsTrigger value="guide_mobilisation">Guide Mobilisation Sociale</TabsTrigger>
          <TabsTrigger value="guide_entretien">Guide d'Entretien</TabsTrigger>
          <TabsTrigger value="feedback">Fiche de Feedback</TabsTrigger>
          <TabsTrigger value="ressources_autres">Autres Ressources</TabsTrigger>
        </TabsList>

        <TabsContent value="guide_mobilisation">
          <GuideMobilisationSocialeContent />
        </TabsContent>

        <TabsContent value="guide_entretien">
          <GuideEntretienCommunautaireContent />
        </TabsContent>

        <TabsContent value="feedback">
          <FicheFeedbackCommunautaireForm />
        </TabsContent>

        <TabsContent value="ressources_autres">
          <AutresRessourcesCommunautairesContent />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default CommunautesPage;
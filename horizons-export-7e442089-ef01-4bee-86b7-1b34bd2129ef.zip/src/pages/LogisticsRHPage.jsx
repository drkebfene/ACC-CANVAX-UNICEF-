
import React, { useState, useEffect, useContext } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Edit, PlusCircle, Download, Printer, FileText as FileTextIcon, Loader2, Trash2, Users2, Truck } from 'lucide-react';
import LogisticsRHForm from '@/components/forms/LogisticsRHForm';

const LogisticsRHPage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);
  const { toast } = useToast();

  const [logisticsData, setLogisticsData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const [selectedItem, setSelectedItem] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const fetchLogisticsData = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('logistics_rh_acd')
        .select(`*, created_by_user:users!created_by_user_id(raw_user_meta_data->>'username')`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setLogisticsData(data.map(item => ({...item, created_by_username: item.created_by_user?.username || 'N/A' })));
    } catch (error) {
      toast({ title: "Erreur de chargement des données Logistique/RH", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (supabaseUser) {
      fetchLogisticsData();
    }
  }, [supabaseUser]);

  const handleCreateNew = () => {
    setSelectedItem(null);
    setIsCreateModalOpen(true);
  };

  const handleView = (item) => {
    setSelectedItem(item);
    setIsViewModalOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedItem(item);
    setIsEditModalOpen(true);
  };
  
  const handleDelete = async (itemId) => {
    if (!window.confirm("Êtes-vous sûr de vouloir supprimer cet enregistrement Logistique/RH ?")) return;
    try {
      const { error } = await supabase.from('logistics_rh_acd').delete().eq('id', itemId);
      if (error) throw error;
      toast({ title: "Suppression Réussie", description: "L'enregistrement a été supprimé." });
      fetchLogisticsData();
    } catch (error) {
      toast({ title: "Erreur de Suppression", description: error.message, variant: "destructive" });
    }
  };

  const handleFormSubmit = async (data) => {
    if (!supabaseUser) {
      toast({ title: "Erreur", description: "Utilisateur non connecté.", variant: "destructive" });
      return;
    }
    const isUpdating = !!selectedItem?.id;

    const submissionData = { ...data, last_modified_by_user_id: supabaseUser.id };
    if (!isUpdating) {
      submissionData.created_by_user_id = supabaseUser.id;
    }

    try {
      let error;
      if (isUpdating) {
        ({ error } = await supabase.from('logistics_rh_acd').update(submissionData).eq('id', selectedItem.id));
      } else {
        ({ error } = await supabase.from('logistics_rh_acd').insert([submissionData]));
      }
      if (error) throw error;
      toast({ title: "Succès", description: `Données Logistique/RH ${isUpdating ? 'mises à jour' : 'créées'} avec succès.` });
      setIsEditModalOpen(false);
      setIsCreateModalOpen(false);
      fetchLogisticsData();
    } catch (err) {
      toast({ title: "Erreur de Soumission", description: err.message, variant: "destructive" });
    }
  };
  
  const handlePrint = () => {
    const printContents = document.getElementById('form-to-print-content')?.innerHTML;
     if(printContents) {
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = `<div class="printable-content p-4 bg-white text-black">${printContents}</div><style>@media print { body * { visibility: hidden; } .printable-content, .printable-content * { visibility: visible; color: black !important; background-color: white !important; } .printable-content { position: absolute; left: 0; top: 0; width: 100%; } .btn-group, .no-print { display: none !important; } }</style>`;
        window.print();
        document.body.innerHTML = originalContents;
        window.location.reload();
    } else {
        toast({title: "Erreur d'impression", description: "Contenu du formulaire non trouvé.", variant: "destructive"});
    }
  };

  const handleDownloadWord = () => {
    const fileName = 'Outils_Logistique_RH_Template.docx';
    const filePath = `/ACD/documents/Checklist_RH.pdf`; // Placeholder, use a .docx template
    
    const link = document.createElement('a');
    link.href = filePath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({title: "Téléchargement Word (Modèle)", description: `Modèle ${fileName} téléchargé.`});
  };
  
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'Brouillon': return 'bg-gray-500';
      case 'Soumis': return 'bg-blue-500';
      case 'Validé': return 'bg-green-500';
      default: return 'bg-slate-500';
    }
  };

  const columns = [
    { key: 'province', label: 'Province' },
    { key: 'district_sanitaire', label: 'District Sanitaire' },
    { key: 'aire_sante', label: 'Aire de Santé' },
    { key: 'date_rapport', label: 'Date Rapport', render: (date) => date ? new Date(date).toLocaleDateString() : 'N/A' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-cyan-500">
        <Truck className="inline-block h-10 w-10 mr-3" />Outils Logistique et Ressources Humaines ACD
      </h1>

      <Card className="glassmorphism">
        <CardHeader className="flex flex-row justify-between items-center">
          <CardTitle className="text-xl text-purple-300">Suivi Logistique et RH</CardTitle>
          <Button onClick={handleCreateNew} className="bg-gradient-to-r from-indigo-500 to-cyan-600 hover:from-indigo-600 hover:to-cyan-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Nouvel Enregistrement
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" /><p className="text-purple-200 mt-2">Chargement...</p></div>
          ) : logisticsData.length === 0 ? (
            <p className="text-center py-8 text-purple-200">Aucun enregistrement trouvé.</p>
          ) : (
            <Table>
              <TableCaption>Liste des enregistrements Logistique et RH.</TableCaption>
              <TableHeader>
                <TableRow>
                  {columns.map(col => <TableHead key={col.key} className="text-cyan-400">{col.label}</TableHead>)}
                  <TableHead className="text-cyan-400">Statut</TableHead>
                  <TableHead className="text-cyan-400">Créé par</TableHead>
                  <TableHead className="text-cyan-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logisticsData.map((item) => (
                  <TableRow key={item.id} className="text-sky-100">
                    {columns.map(col => <TableCell key={col.key}>{col.render ? col.render(item[col.key]) : item[col.key]}</TableCell>)}
                    <TableCell>
                      <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${getStatusBadgeColor(item.status)}`}>
                        {item.status}
                      </span>
                    </TableCell>
                    <TableCell>{item.created_by_username || 'N/A'}</TableCell>
                    <TableCell className="space-x-1">
                      <Button variant="ghost" size="icon" onClick={() => handleView(item)} title="Voir"><Eye className="h-4 w-4 text-blue-400" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(item)} title="Modifier"><Edit className="h-4 w-4 text-yellow-400" /></Button>
                      {(userRole === ROLES.ADMIN || userRole === ROLES.MSP) && (
                         <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)} title="Supprimer"><Trash2 className="h-4 w-4 text-red-400" /></Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {(isViewModalOpen || isEditModalOpen || isCreateModalOpen) && (
        <Dialog open={isViewModalOpen || isEditModalOpen || isCreateModalOpen} 
                onOpenChange={isEditModalOpen ? setIsEditModalOpen : (isCreateModalOpen ? setIsCreateModalOpen : setIsViewModalOpen)}>
          <DialogContent className="max-w-4xl h-[95vh] flex flex-col glassmorphism">
            <DialogHeader>
              <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-500">
                {isEditModalOpen ? 'Modifier' : (isCreateModalOpen ? 'Nouvel' : 'Visualiser')} Enregistrement Logistique/RH
              </DialogTitle>
            </DialogHeader>
            <div id="form-to-print-content" className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
              <LogisticsRHForm 
                onSubmit={handleFormSubmit} 
                initialData={selectedItem} 
                readOnly={isViewModalOpen} 
              />
            </div>
            <DialogFooter className="mt-auto pt-4 border-t border-slate-700 flex-wrap justify-between sm:justify-end">
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline" onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Imprimer</Button>
                <Button variant="outline" onClick={handleDownloadWord}><Download className="mr-2 h-4 w-4" /> Modèle Word</Button>
                <Button variant="outline" onClick={() => toast({title: "Bientôt disponible", description: "Le téléchargement PDF sera bientôt disponible."})}><Download className="mr-2 h-4 w-4" /> PDF (Bientôt)</Button>
              </div>
              <Button variant="secondary" onClick={() => isEditModalOpen ? setIsEditModalOpen(false) : (isCreateModalOpen ? setIsCreateModalOpen(false) : setIsViewModalOpen(false))}>
                {isViewModalOpen ? 'Fermer' : 'Annuler'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
};

export default LogisticsRHPage;
import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { UserContext, ROLES } from '@/contexts/UserContext';

const FilesPage = () => {
  const { toast } = useToast();
  const { userRole } = useContext(UserContext);
  const isAdmin = userRole === ROLES.ADMIN || userRole === 'ADMIN';


  const files = [
    { name: "Outils_Microplanification_ACD.xlsx", type: "Excel", size: "1.2MB", category: "Planification", path: "/ACD/documents/Outils_Microplanification_ACD.xlsx" },
    { name: "Cadre_Suivi_Evaluation.xlsx", type: "Excel", size: "1MB", category: "Monitoring", path: "/ACD/documents/Cadre_Suivi_Evaluation.xlsx"},
    { name: "Guide_Mobilisation_Communautaire.pdf", type: "PDF", size: "1.5MB", category: "Communautés", path: "/ACD/documents/Guide_Mobilisation_Communautaire.pdf" },
    { name: "Feuille_de_Route_DS.docx", type: "Word", size: "850KB", category: "Planification", path: "/ACD/documents/Feuille_de_Route_DS.docx" },
    { name: "Formulaire_OMS_Supervision.pdf", type: "PDF", size: "500KB", category: "Supervision", path: "/ACD/documents/Formulaire_OMS_Supervision.pdf" },
    { name: "Gabarit_Rapport_Mensuel.pptx", type: "PowerPoint", size: "2.5MB", category: "Rapports", path: "/ACD/documents/Gabarit_Rapport_Mensuel.pptx" },
    // { name: "Scripts_Radio_ACD.txt", type: "Texte", size: "10KB", category: "Communautés", path: "/ACD/documents/Scripts_Radio_ACD.txt" }, Removed as per user request to update only specific files
  ];

  const handleDownload = (fileName, filePath) => {
    toast({
      title: "Téléchargement Initié",
      description: `${fileName} est en cours de téléchargement.`,
    });
  };

  const handleUploadFile = () => {
    toast({
      title: "Fonctionnalité en développement",
      description: "La possibilité de déposer des fichiers sera bientôt disponible.",
      variant: "default"
    });
    // Actual Supabase file upload logic would go here
    // Example:
    // const fileInput = document.createElement('input');
    // fileInput.type = 'file';
    // fileInput.onchange = async (e) => {
    //   const file = e.target.files[0];
    //   if (file) {
    //     const { data, error } = await supabase.storage
    //       .from('documents') // replace with your bucket name
    //       .upload(`public/${file.name}`, file);
    //     if (error) {
    //       toast({ title: "Erreur de dépôt", description: error.message, variant: "destructive" });
    //     } else {
    //       toast({ title: "Fichier déposé", description: `${file.name} a été déposé avec succès.` });
    //       // Optionally, refresh the list of files
    //     }
    //   }
    // };
    // fileInput.click();
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="container mx-auto p-8"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500 mb-4 md:mb-0">
          Fichiers Téléchargeables
        </h1>
        {isAdmin && (
          <Button onClick={handleUploadFile} className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white">
            <Upload className="mr-2 h-4 w-4" /> Déposer un Fichier/Dossier
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {files.map((file, index) => (
          <motion.div
            key={index}
            className="p-6 rounded-lg shadow-xl bg-card glassmorphism flex flex-col justify-between hover:shadow-primary/20 transition-shadow duration-300"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <div>
              <FileText className="w-12 h-12 text-primary mb-3" />
              <h2 className="text-xl font-semibold mb-1 text-foreground">{file.name}</h2>
              <p className="text-sm text-muted-foreground mb-1">Catégorie: {file.category}</p>
              <p className="text-sm text-muted-foreground mb-1">Type: {file.type}</p>
              <p className="text-sm text-muted-foreground mb-4">Taille: {file.size}</p>
            </div>
            <Button asChild className="w-full mt-auto bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white" onClick={() => handleDownload(file.name, file.path)}>
              <a href={file.path} download={file.name}>
                <Download className="mr-2 h-4 w-4" /> Télécharger
              </a>
            </Button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default FilesPage;
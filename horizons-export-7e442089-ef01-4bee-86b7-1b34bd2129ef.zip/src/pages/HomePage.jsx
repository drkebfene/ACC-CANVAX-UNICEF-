import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, FileText, ClipboardList, BarChart2, FolderOpen, MessageCircle, Info, Users2, BarChartHorizontal, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { navItemsBase } from '@/config/navConfig';

const HomePage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);

  const fadeIn = (delay = 0) => ({
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay } }
  });

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const objectives = [
    { title: "Planification Stratégique", description: "Élaborer des micro-plans détaillés pour chaque Zone de Responsabilité (ZR).", icon: <ClipboardList className="h-10 w-10 text-purple-400" /> },
    { title: "Suivi & Évaluation", description: "Monitorer les indicateurs clés de performance et évaluer l'impact des interventions.", icon: <BarChart2 className="h-10 w-10 text-pink-400" /> },
    { title: "Supervision Active", description: "Assurer un encadrement de proximité et un soutien continu aux équipes sur le terrain.", icon: <Users2 className="h-10 w-10 text-indigo-400" /> },
    { title: "Engagement Communautaire", description: "Mobiliser les communautés pour une participation active et une appropriation des actions.", icon: <Users className="h-10 w-10 text-green-400" /> },
  ];

  const visibleNavItems = navItemsBase.filter(item => {
    if (item.isPublic || item.path === '/') return false; 
    if (!supabaseUser || !userRole) return false;
    const currentRoleValue = ROLES[userRole] || userRole;
    return item.roles.includes(currentRoleValue) || item.roles.includes(userRole);
  }).slice(0, 6); 

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-100">
      {/* Hero Section */}
      <motion.section 
        className="py-20 md:py-32 text-center bg-cover bg-center relative"
        style={{ backgroundImage: "linear-gradient(rgba(15, 23, 42, 0.8), rgba(67, 56, 202, 0.7)), url('https://images.unsplash.com/photo-1605206928030-9908a74b1693?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80')" }}
        initial="hidden"
        animate="visible"
        variants={staggerContainer}
      >
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm"></div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.h1 
            className="text-5xl md:text-7xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-300"
            variants={fadeIn()}
          >
            ACD/ACE CANVAX
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl text-purple-200 mb-10 max-w-3xl mx-auto"
            variants={fadeIn(0.2)}
          >
            Plateforme Intégrée pour la Planification, le Suivi, la Supervision et l'Engagement Communautaire des Activités de Vaccination.
          </motion.p>
          <motion.div variants={fadeIn(0.4)}>
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 px-8 text-lg shadow-xl transform hover:scale-105 transition-transform duration-300" asChild>
              <Link to={supabaseUser ? "/monitoring" : "/login"}>
                Commencer <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </motion.section>

      {/* Nos Objectifs Section */}
      <section className="py-16 md:py-24 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16 bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-pink-300"
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5 }}
          >
            Nos Objectifs Stratégiques
          </motion.h2>
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
          >
            {objectives.map((obj, index) => (
              <motion.div key={index} variants={fadeIn()}>
                <Card className="bg-slate-700/60 border-slate-600 text-gray-200 h-full flex flex-col hover:shadow-purple-500/20 hover:border-purple-500/50 transition-all duration-300 transform hover:-translate-y-1">
                  <CardHeader className="items-center text-center">
                    <div className="p-4 bg-slate-600/50 rounded-full mb-4 inline-block">
                      {obj.icon}
                    </div>
                    <CardTitle className="text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-pink-300">{obj.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center text-purple-200 flex-grow">
                    <p>{obj.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Accès Rapide aux Modules */}
      {supabaseUser && visibleNavItems.length > 0 && (
        <section className="py-16 md:py-24 bg-slate-900">
          <div className="container mx-auto px-4">
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-center mb-16 bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-pink-300"
              initial={{ opacity: 0, y: -20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5 }}
            >
              Accès Rapide aux Modules
            </motion.h2>
            <motion.div 
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
            >
              {visibleNavItems.map((item) => (
                <motion.div key={item.name} variants={fadeIn()}>
                  <Link to={item.path}>
                    <Card className="bg-slate-800/70 border-slate-700 text-gray-200 h-full group hover:bg-slate-700/90 hover:border-purple-500/70 transition-all duration-300 transform hover:scale-105">
                      <CardHeader className="flex flex-row items-center space-x-4 pb-2">
                        <div className="p-3 bg-slate-700 group-hover:bg-purple-600/30 rounded-lg transition-colors">
                          <item.icon className="h-8 w-8 text-purple-400 group-hover:text-pink-400 transition-colors" />
                        </div>
                        <CardTitle className="text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-pink-300 group-hover:from-purple-200 group-hover:to-pink-200 transition-all">
                          {item.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-purple-200 text-sm group-hover:text-purple-100 transition-colors">
                          {item.description || `Accéder au module ${item.name} pour gérer les activités.`}
                        </p>
                      </CardContent>
                      <CardFooter>
                        <Button variant="link" className="text-pink-400 group-hover:text-pink-300 transition-colors p-0">
                          Ouvrir le module <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
      )}

      {/* Mot du Spécialiste Section */}
      <section className="py-16 md:py-24 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <motion.div 
            className="grid lg:grid-cols-2 gap-12 items-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={staggerContainer}
          >
            <motion.div variants={fadeIn()}>
              <img  
                alt="Dr. KEBFENE Moundiné, Spécialiste Santé & Chef de Bureau Interimaire UNICEF Moundou" 
                className="rounded-xl shadow-2xl w-full max-w-md mx-auto lg:max-w-none object-cover h-96 lg:h-[500px]"
               src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/3d5433a264e61788dbdd4b6056377aab.jpg" />
            </motion.div>
            <motion.div variants={fadeIn(0.2)}>
              <h3 className="text-sm font-semibold uppercase text-pink-400 mb-2">Message Clé</h3>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-pink-300">
                Bienvenue sur la plateforme CANVAX dédiée à l’approche Atteindre Chaque District (ACD) dans les provinces méridionales du Tchad.
              </h2>
              <p className="text-lg text-purple-200 mb-4">
                Ce site constitue un espace opérationnel essentiel pour appuyer la mise en œuvre stratégique du projet CANVAX dans les provinces du Mandoul, du Moyen-Chari et du Mayo Kebbi Ouest. Il met à disposition des équipes de terrain, des autorités sanitaires, des partenaires techniques et des relais communautaires un ensemble intégré d’outils, de ressources, de formulaires interactifs et de données actualisées pour améliorer la planification, le suivi, la supervision et le pilotage des interventions de vaccination.
              </p>
              <p className="text-lg text-purple-200 mb-4">
                Dans un contexte marqué par des inégalités d’accès aux soins, cette plateforme traduit l’engagement fort de l’UNICEF, aux côtés du Ministère de la Santé Publique, à garantir une couverture vaccinale équitable, de qualité et fondée sur les données, même dans les zones les plus reculées.
              </p>
              <p className="text-lg text-purple-200 mb-4">
                J’encourage chaque utilisateur à s’approprier pleinement cette initiative, à en faire un levier de performance collective, au service de la santé et des droits de chaque enfant.
              </p>
              <p className="text-lg text-purple-200 mb-6">
                Avec ma confiance et mon plein appui.
              </p>
              <div>
                <p className="font-semibold text-gray-100 text-xl">Dr KEBFENE Moundiné, MD, PhD</p>
                <p className="text-purple-300">Health Specialist – Chef de Bureau intérimaire</p>
                <p className="text-purple-300">UNICEF – Bureau Sous National de Moundou</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-purple-700 via-pink-600 to-purple-700 text-center">
        <div className="container mx-auto px-4">
          <motion.h2 
            className="text-4xl md:text-5xl font-extrabold mb-6 text-white"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            Prêt à Transformer la Santé Infantile ?
          </motion.h2>
          <motion.p 
            className="text-xl text-purple-200 mb-10 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Rejoignez-nous dans cette mission vitale. Utilisez CANVAX pour optimiser vos actions et contribuer à un Tchad où chaque enfant est protégé.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-pink-600 font-semibold py-3 px-8 text-lg shadow-lg transform hover:scale-105 transition-all duration-300" asChild>
              <Link to="/contact">
                Contactez-nous pour en savoir plus
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
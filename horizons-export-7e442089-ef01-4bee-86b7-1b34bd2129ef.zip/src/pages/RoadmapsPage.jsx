import React, { useState, useEffect, useContext } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Edit, PlusCircle, Download, Printer, FileText as FileTextIcon, Loader2, Trash2 } from 'lucide-react';
import RoadmapCSForm from '@/components/forms/RoadmapCSForm';
import RoadmapDSForm from '@/components/forms/RoadmapDSForm';
import RoadmapDSPForm from '@/components/forms/RoadmapDSPForm';

const RoadmapPage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);
  const { toast } = useToast();

  const [roadmapsCS, setRoadmapsCS] = useState([]);
  const [roadmapsDS, setRoadmapsDS] = useState([]);
  const [roadmapsDSP, setRoadmapsDSP] = useState([]);
  const [isLoadingCS, setIsLoadingCS] = useState(false);
  const [isLoadingDS, setIsLoadingDS] = useState(false);
  const [isLoadingDSP, setIsLoadingDSP] = useState(false);
  
  const [selectedRoadmap, setSelectedRoadmap] = useState(null);
  const [currentRoadmapType, setCurrentRoadmapType] = useState(null); // 'CS', 'DS', or 'DSP'
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const fetchRoadmaps = async (type) => {
    let table, setIsLoading, setRoadmaps;
    switch(type) {
      case 'CS':
        table = 'roadmaps_cs'; setIsLoading = setIsLoadingCS; setRoadmaps = setRoadmapsCS;
        break;
      case 'DS':
        table = 'roadmaps_ds'; setIsLoading = setIsLoadingDS; setRoadmaps = setRoadmapsDS;
        break;
      case 'DSP':
        table = 'roadmaps_dsp'; setIsLoading = setIsLoadingDSP; setRoadmaps = setRoadmapsDSP;
        break;
      default:
        return;
    }

    setIsLoading(true);
    try {
      let query = supabase.from(table).select(`
        *,
        created_by_user:users!created_by_user_id(raw_user_meta_data->>'username')
      `).order('created_at', { ascending: false });

      if (userRole === ROLES.CS && type === 'CS') {
        query = query.eq('created_by_user_id', supabaseUser.id);
      } else if (userRole === ROLES.DS) {
        if (type === 'CS') query = query.eq('district_id', supabaseUser?.user_metadata?.district_id);
        else if (type === 'DS') query = query.eq('created_by_user_id', supabaseUser.id);
      } else if (userRole === ROLES.DSP) {
         if (type === 'CS') query = query.eq('province_id', supabaseUser?.user_metadata?.province_id);
         else if (type === 'DS') query = query.eq('province_id', supabaseUser?.user_metadata?.province_id);
         else if (type === 'DSP') query = query.eq('created_by_user_id', supabaseUser.id);
      }

      const { data, error } = await query;
      if (error) throw error;
      setRoadmaps(data.map(r => ({...r, created_by_username: r.created_by_user?.username || 'N/A' })));
    } catch (error) {
      toast({ title: `Erreur de chargement (${type})`, description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (supabaseUser) {
      fetchRoadmaps('CS');
      fetchRoadmaps('DS');
      fetchRoadmaps('DSP');
    }
  }, [supabaseUser, userRole]);

  const handleCreateNew = (type) => {
    setCurrentRoadmapType(type);
    setSelectedRoadmap(null);
    setIsCreateModalOpen(true);
  };

  const handleView = (roadmap, type) => {
    setSelectedRoadmap(roadmap);
    setCurrentRoadmapType(type);
    setIsViewModalOpen(true);
  };

  const handleEdit = (roadmap, type) => {
    setSelectedRoadmap(roadmap);
    setCurrentRoadmapType(type);
    setIsEditModalOpen(true);
  };
  
  const handleDelete = async (roadmapId, type) => {
    if (!window.confirm("Êtes-vous sûr de vouloir supprimer cette feuille de route ?")) return;
    let table;
    switch(type) {
      case 'CS': table = 'roadmaps_cs'; break;
      case 'DS': table = 'roadmaps_ds'; break;
      case 'DSP': table = 'roadmaps_dsp'; break;
      default: return;
    }
    try {
      const { error } = await supabase.from(table).delete().eq('id', roadmapId);
      if (error) throw error;
      toast({ title: "Suppression Réussie", description: "La feuille de route a été supprimée." });
      fetchRoadmaps(type);
    } catch (error) {
      toast({ title: "Erreur de Suppression", description: error.message, variant: "destructive" });
    }
  };


  const handleFormSubmit = async (data) => {
    if (!supabaseUser) {
      toast({ title: "Erreur", description: "Utilisateur non connecté.", variant: "destructive" });
      return;
    }
    let table;
    switch(currentRoadmapType) {
      case 'CS': table = 'roadmaps_cs'; break;
      case 'DS': table = 'roadmaps_ds'; break;
      case 'DSP': table = 'roadmaps_dsp'; break;
      default: return;
    }
    const isUpdating = !!selectedRoadmap?.id;

    const submissionData = {
      ...data,
      province_id: data.province || supabaseUser?.user_metadata?.province_id,
      district_id: currentRoadmapType !== 'DSP' ? (data.district_sanitaire || supabaseUser?.user_metadata?.district_id) : null,
      centre_sante_id: currentRoadmapType === 'CS' ? (data.centre_sante_aire_sante || supabaseUser?.user_metadata?.centre_sante_id) : null,
      last_modified_by_user_id: supabaseUser.id,
    };
    
    if (!isUpdating) {
        submissionData.created_by_user_id = supabaseUser.id;
    }

    try {
      let error;
      if (isUpdating) {
        ({ error } = await supabase.from(table).update(submissionData).eq('id', selectedRoadmap.id));
      } else {
        ({ error } = await supabase.from(table).insert([submissionData]));
      }
      if (error) throw error;
      toast({ title: "Succès", description: `Feuille de route ${isUpdating ? 'mise à jour' : 'créée'} avec succès.` });
      setIsEditModalOpen(false);
      setIsCreateModalOpen(false);
      fetchRoadmaps(currentRoadmapType);
    } catch (err) {
      toast({ title: "Erreur de Soumission", description: err.message, variant: "destructive" });
    }
  };
  
  const handlePrint = () => {
    const printContents = document.getElementById('form-to-print-content')?.innerHTML;
    if(printContents) {
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = `<div class="printable-content p-4">${printContents}</div><style>@media print { body * { visibility: hidden; } .printable-content, .printable-content * { visibility: visible; } .printable-content { position: absolute; left: 0; top: 0; width: 100%; } }</style>`;
        window.print();
        document.body.innerHTML = originalContents;
        window.location.reload(); 
    } else {
        toast({title: "Erreur d'impression", description: "Contenu du formulaire non trouvé.", variant: "destructive"});
    }
  };

  const handleDownloadWord = (type) => {
    let filePath, fileName;
    switch(type) {
      case 'CS': 
        filePath = '/ACD/documents/Feuille_de_Route_CS_Template.docx'; 
        fileName = 'Feuille_de_Route_CS_Template.docx';
        break;
      case 'DS': 
        filePath = '/ACD/documents/Feuille_de_Route_DS_Template.docx'; 
        fileName = 'Feuille_de_Route_DS_Template.docx';
        break;
      case 'DSP':
        filePath = '/ACD/documents/Feuille_de_Route_DSP_Template.docx';
        fileName = 'Feuille_de_Route_DSP_Template.docx';
        break;
      default: return;
    }
    
    const link = document.createElement('a');
    link.href = filePath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({title: "Téléchargement Word", description: `Modèle ${fileName} téléchargé.`});
  };
  
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'Brouillon': return 'bg-gray-500';
      case 'Soumis': return 'bg-blue-500';
      case 'Validé': return 'bg-green-500';
      default: return 'bg-slate-500';
    }
  };

  const renderRoadmapTable = (roadmaps, type, isLoading) => {
    let titleType;
    switch(type){
        case 'CS': titleType = 'Centre de Santé'; break;
        case 'DS': titleType = 'District Sanitaire'; break;
        case 'DSP': titleType = 'Provincial (DSP)'; break;
        default: titleType = '';
    }
    return (
    <Card className="glassmorphism">
      <CardHeader className="flex flex-row justify-between items-center">
        <CardTitle className="text-xl text-purple-300">Feuilles de Route - Niveau {titleType}</CardTitle>
        <Button onClick={() => handleCreateNew(type)} className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700">
          <PlusCircle className="mr-2 h-4 w-4" /> Créer Nouvelle (Niveau {type})
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" /><p className="text-purple-200 mt-2">Chargement...</p></div>
        ) : roadmaps.length === 0 ? (
          <p className="text-center py-8 text-purple-200">Aucune feuille de route trouvée pour ce niveau.</p>
        ) : (
          <Table>
            <TableCaption>Liste des feuilles de route pour le niveau {titleType}.</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="text-cyan-400">{type === 'CS' ? 'Centre de Santé' : (type === 'DS' ? 'District Sanitaire' : 'Province')}</TableHead>
                <TableHead className="text-cyan-400">Responsable</TableHead>
                <TableHead className="text-cyan-400">Date Élaboration</TableHead>
                <TableHead className="text-cyan-400">Statut</TableHead>
                <TableHead className="text-cyan-400">Créé par</TableHead>
                <TableHead className="text-cyan-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roadmaps.map((roadmap) => (
                <TableRow key={roadmap.id} className="text-sky-100">
                  <TableCell>{type === 'CS' ? roadmap.centre_sante_aire_sante : (type === 'DS' ? roadmap.district_sanitaire : roadmap.province)}</TableCell>
                  <TableCell>{roadmap.nom_responsable}</TableCell>
                  <TableCell>{new Date(roadmap.date_elaboration).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${getStatusBadgeColor(roadmap.status)}`}>
                      {roadmap.status}
                    </span>
                  </TableCell>
                  <TableCell>{roadmap.created_by_username || 'N/A'}</TableCell>
                  <TableCell className="space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => handleView(roadmap, type)} title="Voir"><Eye className="h-4 w-4 text-blue-400" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(roadmap, type)} title="Modifier"><Edit className="h-4 w-4 text-yellow-400" /></Button>
                    {(userRole === ROLES.ADMIN || userRole === ROLES.MSP) && (
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(roadmap.id, type)} title="Supprimer"><Trash2 className="h-4 w-4 text-red-400" /></Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )};
  
  let CurrentForm = RoadmapCSForm; // Default
  if (currentRoadmapType === 'DS') CurrentForm = RoadmapDSForm;
  if (currentRoadmapType === 'DSP') CurrentForm = RoadmapDSPForm;


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-sky-600">
        <FileTextIcon className="inline-block h-10 w-10 mr-3" />Feuilles de Route ACD
      </h1>

      <Tabs defaultValue="cs" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="cs">Niveau Centre de Santé (CS)</TabsTrigger>
          <TabsTrigger value="ds">Niveau District Sanitaire (DS)</TabsTrigger>
          <TabsTrigger value="dsp">Niveau Provincial (DSP)</TabsTrigger>
        </TabsList>
        <TabsContent value="cs">
          {renderRoadmapTable(roadmapsCS, 'CS', isLoadingCS)}
        </TabsContent>
        <TabsContent value="ds">
          {renderRoadmapTable(roadmapsDS, 'DS', isLoadingDS)}
        </TabsContent>
        <TabsContent value="dsp">
          {renderRoadmapTable(roadmapsDSP, 'DSP', isLoadingDSP)}
        </TabsContent>
      </Tabs>

      {(isViewModalOpen || isEditModalOpen || isCreateModalOpen) && (
        <Dialog open={isViewModalOpen || isEditModalOpen || isCreateModalOpen} 
                onOpenChange={isEditModalOpen ? setIsEditModalOpen : (isCreateModalOpen ? setIsCreateModalOpen : setIsViewModalOpen)}>
          <DialogContent className="max-w-4xl h-[95vh] flex flex-col glassmorphism">
            <DialogHeader>
              <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                {isEditModalOpen ? 'Modifier' : (isCreateModalOpen ? 'Créer Nouvelle' : 'Visualiser')} Feuille de Route - Niveau {currentRoadmapType}
                {selectedRoadmap && !isCreateModalOpen && ` : ${currentRoadmapType === 'CS' ? selectedRoadmap.centre_sante_aire_sante : (currentRoadmapType === 'DS' ? selectedRoadmap.district_sanitaire : selectedRoadmap.province)}`}
              </DialogTitle>
            </DialogHeader>
            <div id="form-to-print-content" className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
              <CurrentForm 
                onSubmit={handleFormSubmit} 
                initialData={selectedRoadmap} 
                readOnly={isViewModalOpen} 
              />
            </div>
            <DialogFooter className="mt-auto pt-4 border-t border-slate-700 flex-wrap justify-between sm:justify-end">
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline" onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Imprimer</Button>
                <Button variant="outline" onClick={() => handleDownloadWord(currentRoadmapType)}><Download className="mr-2 h-4 w-4" /> Modèle Word</Button>
                <Button variant="outline" onClick={() => toast({title: "Bientôt disponible", description: "Le téléchargement PDF sera bientôt disponible."})}><Download className="mr-2 h-4 w-4" /> PDF (Bientôt)</Button>
              </div>
              <Button variant="secondary" onClick={() => isEditModalOpen ? setIsEditModalOpen(false) : (isCreateModalOpen ? setIsCreateModalOpen(false) : setIsViewModalOpen(false))}>
                {isViewModalOpen ? 'Fermer' : 'Annuler'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
};

export default RoadmapPage;
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Target, Smile, TrendingUp, CalendarDays } from 'lucide-react';
import { Link } from 'react-router-dom';

const PlaceholderPage = ({ title = "Page en Construction" }) => {
  const isPopulationsCibles = title === "Populations Cibles";
  
  const populationData = [
    { age: "0-11 mois", description: "Nourrissons nécessitant le calendrier vaccinal de base.", icon: <Smile className="h-8 w-8 text-sky-400" /> },
    { age: "12-23 mois", description: "Jeunes enfants pour les rappels et vaccinations spécifiques.", icon: <Users className="h-8 w-8 text-green-400" /> },
    { age: "24-59 mois", description: "Enfants pour les campagnes de rattrapage et supplémentations.", icon: <Target className="h-8 w-8 text-yellow-400" /> },
    { age: "Femmes Enceintes", description: "Pour la vaccination antitétanique et autres interventions prénatales.", icon: <TrendingUp className="h-8 w-8 text-pink-400" /> },
  ];

  const pageImage = isPopulationsCibles 
    ? "https://storage.googleapis.com/hostinger-horizons-assets-prod/7e442089-ef01-4bee-86b7-1b34bd2129ef/0ee1b74518e1319bfaedecd8b526ce05.png" 
    : "https://images.unsplash.com/photo-1584974479511-eb91e18975f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80";
  
  const imageAlt = isPopulationsCibles 
    ? "Illustration des différentes tranches d'âge des enfants cibles pour la vaccination au Tchad" 
    : "Professionnel de santé africain examinant un enfant dans un contexte communautaire";


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="container mx-auto p-8 min-h-[calc(100vh-10rem)] flex flex-col justify-center"
    >
      <Card className="w-full max-w-4xl mx-auto glassmorphism shadow-2xl">
        <CardHeader className="text-center">
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 120 }}
            className="mb-6"
          >
            {isPopulationsCibles ? 
              <Users className="h-20 w-20 mx-auto text-primary" /> : 
              <CalendarDays className="h-20 w-20 mx-auto text-primary" />
            }
          </motion.div>
          <CardTitle className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">
            {title}
          </CardTitle>
          {isPopulationsCibles ? (
            <CardDescription className="text-lg text-purple-200 mt-2">
              Comprendre les groupes d'âge prioritaires pour les campagnes de vaccination au Tchad.
            </CardDescription>
          ) : (
             <CardDescription className="text-lg text-purple-200 mt-2">
              Cette section est en cours de développement. Revenez bientôt pour plus de contenu !
            </CardDescription>
          )}
        </CardHeader>
        <CardContent className="text-center">
          <motion.div 
            className="my-8 rounded-xl overflow-hidden shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <img 
              src={pageImage} 
              alt={imageAlt}
              className="w-full h-auto object-contain max-h-[400px] bg-slate-800/30" 
            />
          </motion.div>

          {isPopulationsCibles && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10 text-left">
              {populationData.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="p-6 rounded-lg bg-slate-800/50 border border-slate-700 shadow-md"
                >
                  <div className="flex items-center mb-3">
                    {item.icon}
                    <h3 className="text-xl font-semibold ml-3 text-purple-300">{item.age}</h3>
                  </div>
                  <p className="text-purple-100">{item.description}</p>
                </motion.div>
              ))}
            </div>
          )}
          
          {!isPopulationsCibles && (
             <motion.p 
                className="text-purple-100 my-6 text-lg"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                Nous travaillons activement pour vous apporter de nouvelles fonctionnalités et informations. Merci pour votre patience !
            </motion.p>
          )}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: isPopulationsCibles ? 0.8 : 0.7 }}
            className="mt-12"
          >
            <Button asChild size="lg" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold px-8 py-3 text-lg">
              <Link to="/">Retour à l'Accueil</Link>
            </Button>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PlaceholderPage;
import React, { useState, useEffect, useContext } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import MicroPlanZRForm from '@/components/forms/MicroPlanZRForm';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Edit, Filter, Layers, Loader2 } from 'lucide-react';
import { Label } from '@/components/ui/label';

const ConsolidationPage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);
  const { toast } = useToast();
  const [microPlans, setMicroPlans] = useState([]);
  const [filteredPlans, setFilteredPlans] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [selectedProvince, setSelectedProvince] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');

  useEffect(() => {
    const fetchMicroPlans = async () => {
      setIsLoading(true);
      setError(null);
      try {
        let query = supabase
          .from('micro_plans_zr')
          .select(`
            *,
            created_by_user_data:users!created_by_user_id(raw_user_meta_data),
            last_modified_by_user_data:users!last_modified_by_user_id(raw_user_meta_data)
          `)
          .order('created_at', { ascending: false });

        if (userRole === ROLES.DS && supabaseUser?.user_metadata?.district_id) {
          query = query.eq('district_id', supabaseUser.user_metadata.district_id);
        } else if (userRole === ROLES.DSP && supabaseUser?.user_metadata?.province_id) {
          query = query.eq('province_id', supabaseUser.user_metadata.province_id);
        }

        const { data, error: fetchError } = await query;
        if (fetchError) throw fetchError;
        
        const formattedData = data.map(plan => ({
          ...plan,
          created_by_username: plan.created_by_user_data?.raw_user_meta_data?.username || 'N/A',
          last_modified_by_username: plan.last_modified_by_user_data?.raw_user_meta_data?.username || 'N/A',
        }));
        
        setMicroPlans(formattedData || []);
        setFilteredPlans(formattedData || []);

        const uniqueProvinces = [...new Set(data.map(p => p.province_id).filter(Boolean))];
        const uniqueDistricts = [...new Set(data.map(p => p.district_id).filter(Boolean))];
        setProvinces(uniqueProvinces.sort());
        setDistricts(uniqueDistricts.sort());

      } catch (err) {
        setError(err.message);
        console.error("Erreur lors du chargement des micro-plans:", err);
        toast({ title: "Erreur de chargement", description: `Impossible de charger les micro-plans: ${err.message}`, variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    };

    if (supabaseUser) {
      fetchMicroPlans();
    }
  }, [supabaseUser, userRole, toast]);

  useEffect(() => {
    let plans = microPlans;
    if (selectedProvince) {
      plans = plans.filter(p => p.province_id === selectedProvince);
    }
    if (selectedDistrict) {
      plans = plans.filter(p => p.district_id === selectedDistrict);
    }
    setFilteredPlans(plans);
  }, [selectedProvince, selectedDistrict, microPlans]);


  const handleViewPlan = (plan) => {
    setSelectedPlan(plan);
    setIsViewModalOpen(true);
  };

  const handleEditPlan = (plan) => {
    const canModify = 
      (userRole === ROLES.DS && plan.status === 'Soumis CS' && plan.district_id === supabaseUser?.user_metadata?.district_id) ||
      (userRole === ROLES.DSP && ['Soumis CS', 'Validé DS'].includes(plan.status) && plan.province_id === supabaseUser?.user_metadata?.province_id) ||
      userRole === ROLES.ADMIN || userRole === ROLES.MSP; 

    if (!canModify && plan.created_by_user_id !== supabaseUser.id) {
        toast({ title: "Modification non autorisée", description: "Vous n'avez pas les droits pour modifier ce plan à son statut actuel.", variant: "destructive"});
        return;
    }
    setSelectedPlan(plan);
    setIsEditModalOpen(true);
  };

  const handleUpdatePlan = async (updatedData) => {
    if (!selectedPlan || !supabaseUser) return;

    const planUpdates = {
      ...updatedData,
      last_modified_by_user_id: supabaseUser.id,
    };
    
    delete planUpdates.created_by_user_data;
    delete planUpdates.last_modified_by_user_data;
    delete planUpdates.created_by_username;
    delete planUpdates.last_modified_by_username;


    try {
      const { data, error: updateError } = await supabase
        .from('micro_plans_zr')
        .update(planUpdates)
        .eq('id', selectedPlan.id)
        .select(`
          *,
          created_by_user_data:users!created_by_user_id(raw_user_meta_data),
          last_modified_by_user_data:users!last_modified_by_user_id(raw_user_meta_data)
        `);
      
      if (updateError) throw updateError;

      toast({ title: "Mise à Jour Réussie", description: "Le micro-plan a été mis à jour." });
      
      const updatedPlanFormatted = {
        ...data[0],
        created_by_username: data[0].created_by_user_data?.raw_user_meta_data?.username || 'N/A',
        last_modified_by_username: data[0].last_modified_by_user_data?.raw_user_meta_data?.username || 'N/A',
      };

      setMicroPlans(prevPlans => prevPlans.map(p => p.id === selectedPlan.id ? updatedPlanFormatted : p));
      setIsEditModalOpen(false);
      setSelectedPlan(null);
    } catch (error) {
      console.error("Erreur lors de la mise à jour du micro-plan:", error);
      toast({ title: "Erreur de Mise à Jour", description: `Échec de la mise à jour: ${error.message}`, variant: "destructive" });
    }
  };
  
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'Brouillon': return 'bg-gray-500';
      case 'Soumis CS': return 'bg-blue-500';
      case 'Validé DS': return 'bg-yellow-500';
      case 'Validé DSP': return 'bg-green-500';
      case 'Rejeté': return 'bg-red-500';
      default: return 'bg-slate-500';
    }
  };


  if (isLoading) {
    return <div className="container mx-auto p-8 text-center"><Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" /><p className="text-xl text-purple-300 mt-4">Chargement des micro-plans...</p></div>;
  }

  if (error) {
    return <div className="container mx-auto p-8 text-center"><p className="text-xl text-red-500">Erreur: {error}</p></div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-sky-600">
        <Layers className="inline-block h-10 w-10 mr-3" />Consolidation des Micro-plans ZR
      </h1>

      <Card className="glassmorphism mb-6">
        <CardHeader>
          <CardTitle className="text-xl text-sky-300">Filtres</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <Label htmlFor="filter-province" className="text-sky-200">Province</Label>
            <Select value={selectedProvince} onValueChange={setSelectedProvince}>
              <SelectTrigger id="filter-province" className="bg-slate-700 border-slate-600 text-white"><SelectValue placeholder="Toutes les provinces" /></SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                <SelectItem value="">Toutes les provinces</SelectItem>
                {provinces.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Label htmlFor="filter-district" className="text-sky-200">District Sanitaire</Label>
            <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
              <SelectTrigger id="filter-district" className="bg-slate-700 border-slate-600 text-white"><SelectValue placeholder="Tous les districts" /></SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                <SelectItem value="">Tous les districts</SelectItem>
                {districts.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle className="text-2xl text-sky-300">Liste des Micro-plans Soumis</CardTitle>
          <CardDescription className="text-sky-100">
            Visualisez, modifiez ou validez les micro-plans des Zones de Responsabilité.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableCaption className="text-sky-200">Total des plans affichés: {filteredPlans.length}</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="text-cyan-400">Centre de Santé (ZR)</TableHead>
                <TableHead className="text-cyan-400">Créé Par</TableHead>
                <TableHead className="text-cyan-400">Dern. Modif. Par</TableHead>
                <TableHead className="text-cyan-400">Date Soumission</TableHead>
                <TableHead className="text-cyan-400">Statut</TableHead>
                <TableHead className="text-cyan-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPlans.map((plan) => (
                <TableRow key={plan.id} className="text-sky-100">
                  <TableCell>{plan.centre_de_sante}</TableCell>
                  <TableCell>{plan.created_by_username}</TableCell>
                  <TableCell>{plan.last_modified_by_username}</TableCell>
                  <TableCell>{new Date(plan.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${getStatusBadgeColor(plan.status)}`}>
                      {plan.status}
                    </span>
                  </TableCell>
                  <TableCell className="space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => handleViewPlan(plan)} title="Voir">
                      <Eye className="h-4 w-4 text-blue-400" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEditPlan(plan)} title="Modifier/Valider">
                      <Edit className="h-4 w-4 text-yellow-400" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredPlans.length === 0 && !isLoading && (
            <p className="text-center py-4 text-sky-200">Aucun micro-plan trouvé pour les filtres sélectionnés.</p>
          )}
        </CardContent>
      </Card>

      {selectedPlan && (
        <>
          <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
            <DialogContent className="max-w-3xl h-[90vh] flex flex-col glassmorphism">
              <DialogHeader><DialogTitle className="text-sky-300">Détails du Micro-plan: {selectedPlan.centre_de_sante}</DialogTitle></DialogHeader>
              <div className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
                <MicroPlanZRForm onSubmit={() => {}} initialData={selectedPlan} readOnly={true} />
              </div>
              <DialogFooter><Button variant="outline" onClick={() => setIsViewModalOpen(false)}>Fermer</Button></DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent className="max-w-3xl h-[90vh] flex flex-col glassmorphism">
              <DialogHeader><DialogTitle className="text-sky-300">Modifier/Valider Micro-plan: {selectedPlan.centre_de_sante}</DialogTitle></DialogHeader>
              <div className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
                <MicroPlanZRForm onSubmit={handleUpdatePlan} initialData={selectedPlan} />
              </div>
               <DialogFooter className="mt-auto pt-4 border-t border-slate-700">
                 <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>Annuler</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      )}
    </motion.div>
  );
};

export default ConsolidationPage;
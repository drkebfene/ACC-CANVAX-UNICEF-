
import React, { useState, useContext, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { supabase } from '@/lib/supabaseClient';

const LoginPage = () => {
  const { setUserRole, setSupabaseUser, supabaseUser } = useContext(UserContext);
  const [selectedRoleForDisplay, setSelectedRoleForDisplay] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    if (supabaseUser) {
      navigate(location.state?.from?.pathname || '/');
    }
  }, [supabaseUser, navigate, location.state]);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: 'Champs manquants',
        description: 'Veuillez entrer votre email et mot de passe.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
      });

      if (error) {
        toast({
          title: 'Erreur de connexion',
          description: error.message || "Les informations d'identification sont incorrectes.",
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }

      if (data.user) {
        const userAppRole = data.user.user_metadata?.app_role;
        if (userAppRole && ROLES[userAppRole]) {
          setUserRole(userAppRole);
          localStorage.setItem('userRole', userAppRole);
          setSupabaseUser(data.user); // Ensure supabaseUser is set in context

          toast({
            title: 'Connexion réussie!',
            description: `Bienvenue, ${data.user.email}. Rôle: ${ROLES[userAppRole]}.`,
          });
          navigate(location.state?.from?.pathname || '/');
        } else {
           await supabase.auth.signOut(); // Sign out user if role is not valid or not found
           setUserRole(null);
           setSupabaseUser(null);
           localStorage.removeItem('userRole');
          toast({
            title: 'Erreur de Rôle',
            description: 'Rôle utilisateur non défini ou invalide. Veuillez contacter l\'administrateur.',
            variant: 'destructive',
          });
        }
      } else {
         toast({
          title: 'Erreur de connexion',
          description: 'Utilisateur non trouvé ou informations incorrectes.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Erreur inattendue',
        description: error.message || 'Une erreur est survenue lors de la connexion.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-12 flex justify-center items-center min-h-[calc(100vh-160px)]" // Adjusted min-height
    >
      <Card className="w-full max-w-md shadow-2xl glassmorphism border-slate-700">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-purple-400 via-pink-400 to-orange-300">
            Accès CANVAX
          </CardTitle>
          <CardDescription className="text-purple-200 pt-2">
            Entrez vos identifiants pour accéder à la plateforme.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-purple-300">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="exemple@domaine.com" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="bg-slate-700/50 border-slate-600 focus:border-pink-500"
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-purple-300">Mot de passe</Label>
              <div className="relative">
                <Input 
                  id="password" 
                  type={showPassword ? "text" : "password"} 
                  placeholder="Votre mot de passe" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  className="bg-slate-700/50 border-slate-600 focus:border-pink-500 pr-10"
                  required 
                />
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setShowPassword(!showPassword)} 
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-purple-300 hover:text-pink-400"
                  aria-label={showPassword ? "Cacher le mot de passe" : "Montrer le mot de passe"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
             {/* Le sélecteur de rôle est retiré car le rôle est déterminé par Supabase user_metadata */}
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold text-lg py-3"
              disabled={isLoading}
            >
              {isLoading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                ></motion.div>
              ) : (
                <LogIn className="mr-2 h-5 w-5" />
              )}
              {isLoading ? 'Connexion...' : 'Se Connecter'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="text-center text-sm text-purple-300">
          <p>En cas de problème, veuillez contacter l'administrateur.</p>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default LoginPage;

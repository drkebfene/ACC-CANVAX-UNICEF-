import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { ROLES } from '@/contexts/UserContext';


const AdminUsersPage = () => {
  const { toast } = useToast();
  const [usersData, setUsersData] = useState([
    { id: 1, username: 'ds.moundou', roleKey: 'DS', access: 'Saisir/Éditer' },
    { id: 2, username: 'cs.mato', roleKey: 'CS', access: 'Consulter' },
    { id: 3, username: 'unicef.user', roleKey: 'UNICEF', access: 'Exploiter' },
    { id: 4, username: 'msp.admin', roleKey: 'MSP', access: 'Exploiter' },
  ]);

  const handleAccessChange = (userId, newAccess) => {
    setUsersData(usersData.map(u => u.id === userId ? {...u, access: newAccess} : u));
    toast({ title: "Droits modifiés", description: `Les droits de l'utilisateur ont été mis à jour.`});
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">Gestion des Utilisateurs</h1>
      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle>Liste des Utilisateurs et Droits d'Accès</CardTitle>
          <div className="flex justify-end">
            <Button><Users className="mr-2 h-4 w-4" /> Ajouter Utilisateur</Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom d'utilisateur</TableHead>
                <TableHead>Rôle</TableHead>
                <TableHead>Droits d'Accès</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {usersData.map(user => (
                <TableRow key={user.id}>
                  <TableCell>{user.username}</TableCell>
                  <TableCell>{ROLES[user.roleKey]}</TableCell>
                  <TableCell>
                    <Select value={user.access} onValueChange={(value) => handleAccessChange(user.id, value)}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Consulter">Consulter</SelectItem>
                        <SelectItem value="Saisir/Éditer">Saisir/Éditer</SelectItem>
                        <SelectItem value="Exploiter">Exploiter</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon"><Settings className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminUsersPage;
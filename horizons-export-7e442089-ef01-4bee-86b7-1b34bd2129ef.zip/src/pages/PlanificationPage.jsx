
import React, { useContext, useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Edit3, FileType, Save, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';
import MicroPlanZRForm from '@/components/forms/MicroPlanZRForm';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabaseClient';

const PlanificationPage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);
  const { toast } = useToast();
  const canEdit = userRole && [ROLES.CS, ROLES.DS, ROLES.DSP, ROLES.DV, ROLES.ADMIN, ROLES.MSP].includes(ROLES[userRole]);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const handleDownloadTool = (format, toolName, isPlaceholder = false) => {
    let filePath = `/ACD/documents/${toolName}`;
    let message = `L'outil ${toolName} sera téléchargé.`;

    if (isPlaceholder && toolName !== 'Canevas_MicroPlan_ZR.pdf' && toolName !== 'Checklist_RH.pdf') {
      message = `Le téléchargement pour ${toolName} (${format}) sera bientôt disponible.`;
      toast({
        title: `Téléchargement ${format} (Bientôt)`,
        description: message,
      });
      return; 
    }
    
    if (format === 'Excel' || format === 'Word' || format === 'PDF') {
       window.open(filePath, "_blank");
    } else {
      message = `Le format ${format} pour ${toolName} n'est pas directement supporté pour le téléchargement.`;
    }
    
    toast({
      title: `Téléchargement ${format}`,
      description: message,
    });
  };
  
  const handleFormSubmit = async (data) => {
    if (!supabaseUser) {
      toast({ title: "Erreur d'authentification", description: "Vous devez être connecté pour soumettre un plan.", variant: "destructive" });
      return;
    }

    const planData = {
      ...data,
      created_by_user_id: supabaseUser.id,
      last_modified_by_user_id: supabaseUser.id,
      status: 'Soumis CS', // Default status on creation by CS
      // Assuming district_id and province_id might come from user profile or selection in a more complex form
      district_id: supabaseUser.user_metadata?.district_id || data.districtSanitaire, 
      province_id: supabaseUser.user_metadata?.province_id || data.regionSanitaire,
    };
    
    try {
      const { error } = await supabase.from('micro_plans_zr').insert([planData]);
      if (error) throw error;
      
      toast({ title: "Soumission Réussie", description: "Les données du micro-plan ZR ont été enregistrées avec succès." });
      setIsFormOpen(false);
    } catch (error) {
      console.error("Erreur lors de la soumission du micro-plan ZR:", error);
      toast({ title: "Erreur de Soumission", description: `Échec de l'enregistrement du micro-plan: ${error.message}`, variant: "destructive" });
    }
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">Planification & Ressources</h1>
      <Tabs defaultValue="microplanification" className="w-full">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 mb-6">
          <TabsTrigger value="microplanification">Microplanification</TabsTrigger>
          <TabsTrigger value="budgetisation">Budgétisation</TabsTrigger>
          <TabsTrigger value="logistique">Logistique & RH</TabsTrigger>
        </TabsList>

        <TabsContent value="microplanification">
          <Card className="glassmorphism">
            <CardHeader>
              <CardTitle>Outils de Microplanification ACD</CardTitle>
              <CardDescription>Planifiez vos activités au niveau District et Centre de Santé. Remplissez en ligne ou téléchargez les outils.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-3 text-purple-300">Canevas Micro-plan Zone de Responsabilité (Centre de Santé)</h3>
                <p className="text-purple-200 mb-3">Utilisez ce formulaire pour détailler le plan de votre Zone de Responsabilité. Vous pouvez remplir en ligne ou télécharger les modèles.</p>
                <div className="flex flex-wrap gap-4">
                  {canEdit && (
                    <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
                      <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-blue-500 to-sky-600 hover:from-blue-600 hover:to-sky-700 text-white">
                          <Edit3 className="mr-2 h-4 w-4" /> Remplir Micro-plan ZR en ligne
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl h-[90vh] flex flex-col glassmorphism">
                        <DialogHeader>
                          <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                            Canevas de Micro-plan Zone de Responsabilité (ZR)
                          </DialogTitle>
                        </DialogHeader>
                        <div className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
                          <MicroPlanZRForm onSubmit={handleFormSubmit} />
                        </div>
                        <DialogFooter className="mt-auto pt-4 border-t border-slate-700">
                           <Button variant="outline" onClick={() => setIsFormOpen(false)}>Annuler</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  )}
                  <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Canevas_MicroPlan_ZR.xlsx', true)} className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                    <Download className="mr-2 h-4 w-4" /> Canevas ZR (Excel - Bientôt)
                  </Button>
                  <Button variant="outline" onClick={() => handleDownloadTool('PDF', 'Canevas_MicroPlan_ZR.pdf', false)} className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white">
                    <FileType className="mr-2 h-4 w-4" /> Canevas ZR (PDF)
                  </Button>
                  <Button variant="outline" onClick={() => handleDownloadTool('Word', 'Canevas_MicroPlan_ZR.docx', true)} className="border-sky-500 text-sky-400 hover:bg-sky-500 hover:text-white">
                    <FileType className="mr-2 h-4 w-4" /> Canevas ZR (Word - Bientôt)
                  </Button>
                </div>
              </div>
              
              <div className="mt-8 pt-6 border-t border-slate-700/50">
                 <h3 className="text-xl font-semibold mb-3 text-purple-300">Outils de Microplanification ACD (Niveaux Supérieurs)</h3>
                <div className="flex flex-wrap gap-4">
                    <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Outils_Microplan_DS.xlsx', true)} className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                      <Download className="mr-2 h-4 w-4" /> District Sanitaire (Excel - Bientôt)
                    </Button>
                    <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Outils_Microplan_DSP.xlsx', true)} className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                      <Download className="mr-2 h-4 w-4" /> Délégation Provinciale (Excel - Bientôt)
                    </Button>
                    <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Outils_Microplan_National.xlsx', true)} className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                      <Download className="mr-2 h-4 w-4" /> Niveau National (Excel - Bientôt)
                    </Button>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-slate-700/50">
                 <h3 className="text-xl font-semibold mb-3 text-purple-300">Autres Outils de Planification Générale</h3>
                <div className="flex flex-wrap gap-4">
                    <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Outils_Microplanification_ACD.xlsx')} className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                    <Download className="mr-2 h-4 w-4" /> Outils Planification Gén. (Excel)
                    </Button>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-slate-700/50">
                 <h3 className="text-xl font-semibold mb-3 text-purple-300">Formulaires de Saisie des Indicateurs ACD</h3>
                 <p className="text-purple-200 mb-3">Utilisez ce formulaire HTML interactif pour la saisie mensuelle des indicateurs clés de l'ACD.</p>
                <div className="flex flex-wrap gap-4">
                    <Button asChild className="bg-gradient-to-r from-blue-500 to-sky-600 hover:from-blue-600 hover:to-sky-700 text-white">
                        <a href="/ACD/Formulaire_Collecte_Indicateurs_ACD.html" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-2 h-4 w-4" /> Formulaire Saisie Indicateurs (HTML)
                        </a>
                    </Button>
                </div>
              </div>

            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budgetisation">
           <Card className="glassmorphism">
            <CardHeader>
              <CardTitle>Budgétisation des Activités ACD</CardTitle>
              <CardDescription>Estimez et suivez les coûts associés à la mise en œuvre de l'ACD.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-purple-200">Outils pour l'élaboration et le suivi budgétaire. Modèles de budget et formulaires de rapportage financier.</p>
              <Button onClick={() => toast({ title: "Fonctionnalité en développement", description: "La création de budget en ligne sera bientôt disponible."})} className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white"><FileText className="mr-2 h-4 w-4" /> Créer un Budget (Bientôt)</Button>
              <Button variant="outline" onClick={() => handleDownloadTool('Excel', 'Modele_Budget.xlsx', true)} className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white"><Download className="mr-2 h-4 w-4" /> Modèle Budget (Excel - Bientôt)</Button>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="logistique">
           <Card className="glassmorphism">
            <CardHeader>
              <CardTitle>Logistique et Ressources Humaines</CardTitle>
              <CardDescription>Planification des vaccins, matériel et personnel.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-purple-200">Gestion des stocks de vaccins, chaîne du froid, matériel de sensibilisation et déploiement des équipes.</p>
              <Button onClick={() => toast({ title: "Fonctionnalité en développement", description: "Le plan logistique en ligne sera bientôt disponible."})} className="bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white"><FileText className="mr-2 h-4 w-4" /> Plan Logistique (Bientôt)</Button>
              <Button variant="outline" onClick={() => handleDownloadTool('PDF', 'Checklist_RH.pdf', false)} className="border-yellow-500 text-yellow-400 hover:bg-yellow-500 hover:text-white"><Download className="mr-2 h-4 w-4" /> Checklist RH (PDF)</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default PlanificationPage;
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

import { MapPin, Layers, Search, PlayCircle, Image as ImageIcon, AlertTriangle, UploadCloud, BarChart, CalendarDays, Users, FileText as FileTextIcon, Brain, Activity, Share2, AlignLeft, Zap, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const SatScanResultsMapLayer = ({ clusters }) => {
  const map = useMap();

  useEffect(() => {
    if (clusters && clusters.length > 0) {
      const bounds = L.latLngBounds(clusters.map(c => c.coordinates));
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [clusters, map]);

  if (!clusters || clusters.length === 0) return null;

  return (
    <>
      {clusters.map(cluster => (
        <Circle
          key={cluster.id}
          center={cluster.coordinates}
          pathOptions={{ color: cluster.color || 'red', fillColor: cluster.fillColor || '#f03', fillOpacity: 0.4 }}
          radius={cluster.radius || 20000} 
        >
          <Popup>
            <strong>Cluster {cluster.id}: {cluster.location}</strong><br />
            P-value: {cluster.pValue}<br />
            Risque Relatif: {cluster.relativeRisk}<br />
            Période: {cluster.startDate} - {cluster.endDate}
          </Popup>
        </Circle>
      ))}
    </>
  );
};

const CartographieTab = ({ defaultPosition, exampleHighRiskZone, satScanResults }) => (
  <Card className="glassmorphism">
    <CardHeader>
      <CardTitle className="text-2xl text-cyan-300 flex items-center"><MapPin className="mr-3 h-7 w-7" /> Cartographie Interactive</CardTitle>
      <CardDescription className="text-cyan-100">
        Visualisez les données de vaccination, les cas de maladies, et les infrastructures sanitaires sur une carte interactive.
      </CardDescription>
    </CardHeader>
    <CardContent>
      <div className="mb-4 p-4 border border-yellow-500/50 bg-yellow-900/20 rounded-md text-yellow-200">
        <AlertTriangle className="inline h-5 w-5 mr-2" />
        <strong>Note:</strong> La carte ci-dessous utilise Leaflet avec OpenStreetMap. L'intégration de données dynamiques et de couches spécifiques (taux de couverture, cas, etc.) nécessite une connexion à une base de données géospatiales (ex: Supabase avec PostGIS) et des développements supplémentaires.
      </div>
      <MapContainer center={defaultPosition} zoom={6} style={{ height: '500px', width: '100%' }} className="rounded-lg shadow-xl border border-slate-700">
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Marker position={[12.1361, 15.0557]}>
          <Popup>
            N'Djamena, Tchad.<br /> Capitale et plus grande ville.
          </Popup>
        </Marker>
        <Circle center={exampleHighRiskZone} pathOptions={{ color: 'purple', fillColor: '#A020F0', fillOpacity:0.3 }} radius={50000}>
            <Popup>Zone d'intérêt (Exemple)</Popup>
        </Circle>
        {satScanResults && <SatScanResultsMapLayer clusters={satScanResults.clusters} />}
      </MapContainer>
      <div className="mt-6 space-y-2">
        <Button variant="outline" className="border-cyan-500 text-cyan-400 hover:bg-cyan-500 hover:text-white">
          <Layers className="mr-2 h-4 w-4" /> Gérer les Couches (Simulé)
        </Button>
        <Input type="text" placeholder="Rechercher un lieu..." className="max-w-xs inline-flex ml-2 bg-slate-700 border-slate-600 text-white placeholder-slate-400" />
        <Button variant="ghost" size="icon" className="ml-1"><Search className="h-5 w-5 text-cyan-400" /></Button>
      </div>
    </CardContent>
  </Card>
);

const SatScanTab = ({ satScanParams, handleSatScanParamChange, handleSatScanSelectChange, handleRunSatScan, isLoadingSatScan, satScanResults }) => (
  <Card className="glassmorphism">
    <CardHeader>
      <CardTitle className="text-2xl text-sky-300 flex items-center"><BarChart className="mr-3 h-7 w-7" /> Analyse de Clusters (Simulation SatScanR/R)</CardTitle>
      <CardDescription className="text-sky-100">
        Configurez et lancez des analyses pour détecter des clusters spatiaux, temporels ou spatio-temporels de cas de maladies.
      </CardDescription>
    </CardHeader>
    <CardContent>
      <div className="mb-6 p-4 border border-red-500/50 bg-red-900/20 rounded-md text-red-200">
        <AlertTriangle className="inline h-5 w-5 mr-2" />
        <strong>Avertissement Important:</strong> L'exécution réelle de SatScan, SatScanR, ou de scripts R nécessite un environnement serveur et une API dédiée. Ce module simule l'interface de configuration et les résultats. <strong>Aucune analyse réelle n'est effectuée dans le navigateur.</strong>
      </div>
      
      <form onSubmit={handleRunSatScan} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="analysisType" className="text-sky-200">Type d'Analyse</Label>
            <Select name="analysisType" value={satScanParams.analysisType} onValueChange={(value) => handleSatScanSelectChange('analysisType', value)}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                <SelectItem value="purely_spatial">Purement Spatiale (SatScan)</SelectItem>
                <SelectItem value="purely_temporal">Purement Temporelle (SatScan/R)</SelectItem>
                <SelectItem value="spatio_temporal">Spatio-temporelle (SatScan)</SelectItem>
                <SelectItem value="temporal_modeling_r">Modélisation Temporelle (R)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="scanAreas" className="text-sky-200">Scanner pour Zones de (SatScan)</Label>
              <Select name="scanAreas" value={satScanParams.scanAreas} onValueChange={(value) => handleSatScanSelectChange('scanAreas', value)}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                <SelectItem value="high_rates">Taux Élevés</SelectItem>
                <SelectItem value="low_rates">Taux Faibles</SelectItem>
                <SelectItem value="both">Les Deux</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Label htmlFor="timePrecision" className="text-sky-200"><CalendarDays className="inline mr-1 h-4 w-4"/> Précision Temporelle</Label>
            <Select name="timePrecision" value={satScanParams.timePrecision} onValueChange={(value) => handleSatScanSelectChange('timePrecision', value)}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-slate-700 text-white">
                <SelectItem value="day">Jour</SelectItem>
                <SelectItem value="week">Semaine</SelectItem>
                <SelectItem value="month">Mois</SelectItem>
                <SelectItem value="year">Année</SelectItem>
              </SelectContent>
            </Select>
          </div>
            <div>
            <Label htmlFor="startDate" className="text-sky-200">Date de Début</Label>
            <Input type="date" name="startDate" value={satScanParams.startDate} onChange={handleSatScanParamChange} className="bg-slate-700 border-slate-600 text-white" />
          </div>
          <div>
            <Label htmlFor="endDate" className="text-sky-200">Date de Fin</Label>
            <Input type="date" name="endDate" value={satScanParams.endDate} onChange={handleSatScanParamChange} className="bg-slate-700 border-slate-600 text-white" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Label htmlFor="caseFile" className="text-sky-200"><AlertTriangle className="inline mr-1 h-4 w-4 text-yellow-400"/> Fichier des Cas (.cas, .csv)</Label>
            <Input type="file" name="caseFile" onChange={handleSatScanParamChange} className="bg-slate-700 border-slate-600 text-white file:text-sky-300" accept=".cas,.csv" />
          </div>
          <div>
            <Label htmlFor="populationFile" className="text-sky-200"><Users className="inline mr-1 h-4 w-4"/> Fichier Population (.pop, .csv)</Label>
            <Input type="file" name="populationFile" onChange={handleSatScanParamChange} className="bg-slate-700 border-slate-600 text-white file:text-sky-300" accept=".pop,.csv" />
          </div>
          <div>
            <Label htmlFor="coordinatesFile" className="text-sky-200"><MapPin className="inline mr-1 h-4 w-4"/> Fichier Coordonnées (.geo, .csv)</Label>
            <Input type="file" name="coordinatesFile" onChange={handleSatScanParamChange} className="bg-slate-700 border-slate-600 text-white file:text-sky-300" accept=".geo,.csv" />
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Les fichiers doivent être au format attendu par SatScan ou R. Le téléchargement est simulé.</p>

        <Button type="submit" disabled={isLoadingSatScan} className="bg-gradient-to-r from-sky-500 to-cyan-600 hover:from-sky-600 hover:to-cyan-700 text-white">
          {isLoadingSatScan ? <UploadCloud className="mr-2 h-5 w-5 animate-pulse" /> : <PlayCircle className="mr-2 h-5 w-5" />}
          {isLoadingSatScan ? 'Analyse en cours (Simulation)...' : 'Lancer l\'Analyse (Simulation)'}
        </Button>
      </form>

      {satScanResults && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-8 p-6 bg-slate-700/50 rounded-lg border border-slate-600">
          <h3 className="text-xl font-semibold text-sky-200 mb-4">Résultats de l'Analyse (Simulation)</h3>
          <p className="text-sky-300 mb-2"><strong>Résumé:</strong> {satScanResults.summary}</p>
          <div className="my-4 rounded-md shadow-lg h-64 w-full bg-slate-800 flex items-center justify-center text-slate-500">
            <p>Visualisation cartographique des clusters (voir onglet Cartographie)</p>
          </div>
          <h4 className="text-lg font-medium text-sky-200 mt-4 mb-2">Clusters Détectés:</h4>
          <ul className="list-disc list-inside text-sky-300 space-y-1">
            {satScanResults.clusters.map(cluster => (
              <li key={cluster.id}>
                <strong>Cluster {cluster.id}:</strong> {cluster.location} (P-value: {cluster.pValue}, RR: {cluster.relativeRisk}, Période: {cluster.startDate} - {cluster.endDate})
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </CardContent>
  </Card>
);

const AnalyseQualitativeTab = ({ qualitativeText, setQualitativeText, handleQualitativeAnalysis, isLoadingQualitative, qualitativeAnalysisResults }) => (
  <Card className="glassmorphism">
    <CardHeader>
      <CardTitle className="text-2xl text-purple-300 flex items-center"><Brain className="mr-3 h-7 w-7" /> Analyses de Données</CardTitle>
      <CardDescription className="text-purple-100">
        Explorez les données quantitatives et qualitatives pour des insights approfondis.
      </CardDescription>
    </CardHeader>
    <CardContent>
      <Tabs defaultValue="qualitative_textuelle" className="w-full">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-2 mb-6">
          <TabsTrigger value="statistiques">Analyses Statistiques</TabsTrigger>
          <TabsTrigger value="qualitative_textuelle">Analyses Qualitatives Textuelles</TabsTrigger>
        </TabsList>

        <TabsContent value="statistiques">
          <Card className="bg-slate-800/30 border-slate-700">
            <CardHeader>
              <CardTitle className="text-xl text-indigo-300 flex items-center"><Activity className="mr-2 h-6 w-6" />Analyses Statistiques Uni et Multivariées</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-indigo-100 mb-4">
                Cette section est destinée à l'intégration future d'outils d'analyses statistiques descriptives, inférentielles (uni et multivariées).
                L'implémentation de telles analyses nécessite des capacités backend ou des bibliothèques de calcul statistique avancées.
              </p>
              <div className="p-4 border border-yellow-500/50 bg-yellow-900/20 rounded-md text-yellow-200 mb-4">
                <AlertTriangle className="inline h-5 w-5 mr-2" />
                <strong>Fonctionnalité en développement :</strong> Les outils d'analyse statistique seront ajoutés ultérieurement.
              </div>
              <div className="p-4 border border-blue-500/50 bg-blue-900/20 rounded-md text-blue-200">
                <Code className="inline h-5 w-5 mr-2" />
                <strong>Intégration R :</strong> L'utilisation de bibliothèques R open source (ex: `dplyr`, `ggplot2`, `lme4`) via un backend (ex: OpenCPU, Plumber API) est envisagée pour des analyses statistiques robustes.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="qualitative_textuelle">
           <Card className="bg-slate-800/30 border-slate-700">
            <CardHeader>
                 <CardTitle className="text-xl text-pink-300 flex items-center"><FileTextIcon className="mr-2 h-6 w-6" />Analyses Qualitatives Textuelles (Sémantique, Lexicale, Thématique)</CardTitle>
                 <CardDescription className="text-pink-100">Analysez les feedbacks, notes d'entretiens pour identifier thèmes, sentiments, mots fréquents, etc.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6 p-4 border border-red-500/50 bg-red-900/20 rounded-md text-red-200">
                <AlertTriangle className="inline h-5 w-5 mr-2" />
                <strong>Avertissement Important:</strong> L'analyse textuelle avancée (NLP) nécessite des bibliothèques et un traitement backend. Ce module simule l'interface et les résultats.
              </div>
              <div className="mb-6 p-4 border border-green-500/50 bg-green-900/20 rounded-md text-green-200">
                <Zap className="inline h-5 w-5 mr-2" />
                <strong>IA Générative :</strong> L'intégration future d'IA Générative (via API de modèles de langage) pourrait permettre la synthèse automatique de textes, la génération de résumés thématiques, et l'aide à l'interprétation des données qualitatives.
              </div>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="qualitativeText" className="text-pink-200">Collez votre texte ici (feedbacks, notes d'entretien, etc.) :</Label>
                  <Textarea
                    id="qualitativeText"
                    value={qualitativeText}
                    onChange={(e) => setQualitativeText(e.target.value)}
                    rows={8}
                    placeholder="Saisissez ou collez le texte à analyser..."
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 mt-1"
                  />
                </div>
                <Button onClick={handleQualitativeAnalysis} disabled={isLoadingQualitative} className="bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white">
                  {isLoadingQualitative ? <UploadCloud className="mr-2 h-5 w-5 animate-pulse" /> : <PlayCircle className="mr-2 h-5 w-5" />}
                  {isLoadingQualitative ? 'Analyse en cours...' : 'Analyser le Texte (Simulation)'}
                </Button>
              </div>

              {qualitativeAnalysisResults && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-8 p-6 bg-slate-700/50 rounded-lg border border-slate-600">
                  <h3 className="text-xl font-semibold text-pink-200 mb-4">Résultats de l'Analyse Qualitative (Simulation)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h4 className="text-lg font-medium text-pink-300 mb-2 flex items-center"><Share2 className="mr-2 h-5 w-5" />Nuage de Mots (Exemple)</h4>
                      <img-replace src={qualitativeAnalysisResults.wordCloudImage} alt="Nuage de mots simulé" className="rounded-md shadow-lg border border-slate-600" />
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-pink-300 mb-2 flex items-center"><Layers className="mr-2 h-5 w-5" />Thèmes Clés Émergents (Analyse Thématique)</h4>
                      <ul className="list-disc list-inside text-pink-100 space-y-1">
                        {qualitativeAnalysisResults.keyThemes.map(theme => <li key={theme}>{theme}</li>)}
                      </ul>
                      <h4 className="text-lg font-medium text-pink-300 mt-4 mb-2 flex items-center"><Brain className="mr-2 h-5 w-5" />Analyse de Sentiment (Analyse Sémantique)</h4>
                      <div className="space-y-1 text-pink-100">
                        <p>Positif: <span className="font-semibold text-green-400">{(qualitativeAnalysisResults.sentiment.positive * 100).toFixed(0)}%</span></p>
                        <p>Neutre: <span className="font-semibold text-yellow-400">{(qualitativeAnalysisResults.sentiment.neutral * 100).toFixed(0)}%</span></p>
                        <p>Négatif: <span className="font-semibold text-red-400">{(qualitativeAnalysisResults.sentiment.negative * 100).toFixed(0)}%</span></p>
                      </div>
                    </div>
                  </div>
                  <div className="mb-6">
                      <h4 className="text-lg font-medium text-pink-300 mb-2 flex items-center"><AlignLeft className="mr-2 h-5 w-5" />Exemples de Verbatims</h4>
                      <div className="space-y-2 text-sm text-pink-100/90 italic p-3 bg-slate-800/50 rounded-md border border-slate-600">
                          <p>"L'accès au centre de santé est vraiment difficile pendant la saison des pluies."</p>
                          <p>"Nous avons bien reçu l'information sur la campagne vaccinale, mais les horaires n'étaient pas pratiques."</p>
                          <p>"Les agents vaccinateurs étaient très professionnels et gentils avec les enfants."</p>
                      </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-lg font-medium text-pink-300 mb-2 flex items-center"><FileTextIcon className="mr-2 h-5 w-5" />Mots Fréquents (Analyse Lexicale)</h4>
                      <ul className="list-disc list-inside text-pink-100 columns-2">
                        {qualitativeAnalysisResults.frequentWords.map(fw => <li key={fw.word}>{fw.word} ({fw.count})</li>)}
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-pink-300 mb-2 flex items-center"><Share2 className="mr-2 h-5 w-5 transform rotate-90" />Dendrogramme (Simulation d'analyse thématique hiérarchique)</h4>
                      <img-replace alt="Dendrogramme simulé" className="rounded-md shadow-lg border border-slate-600 object-contain max-h-48" />
                    </div>
                  </div>
                </motion.div>
              )}
            </CardContent>
           </Card>
        </TabsContent>
      </Tabs>
    </CardContent>
  </Card>
);

const TeledetectionTab = () => (
   <Card className="glassmorphism">
    <CardHeader>
      <CardTitle className="text-2xl text-teal-300 flex items-center"><ImageIcon className="mr-3 h-7 w-7" /> Télédétection & Imagerie Satellitaire</CardTitle>
      <CardDescription className="text-teal-100">
        Analyse d'images satellitaires pour le suivi environnemental, l'identification des zones inaccessibles, ou l'évolution de l'habitat.
      </CardDescription>
    </CardHeader>
    <CardContent>
      <div className="mb-6 p-4 border border-red-500/50 bg-red-900/20 rounded-md text-red-200">
        <AlertTriangle className="inline h-5 w-5 mr-2" />
        <strong>Avertissement Important:</strong> L'accès et le traitement d'images satellitaires en temps réel nécessitent des API et des infrastructures spécialisées (ex: Google Earth Engine, Sentinel Hub) qui ne sont pas intégrées ici. Ce module est une simulation conceptuelle.
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div>
          <h3 className="text-xl font-semibold text-teal-200 mb-3">Image Satellite Récente (Exemple)</h3>
          <img-replace alt="Exemple d'image satellite d'une région rurale avec des cours d'eau" className="rounded-lg shadow-xl border border-slate-600 w-full h-auto max-h-[400px] object-cover" />
          <p className="text-xs text-muted-foreground mt-1">Source: Image statique (simulation de télédétection)</p>
        </div>
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-teal-200">Outils d'Analyse (Simulation)</h3>
          <Button variant="outline" className="w-full border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-white">Comparer avec Image Précédente</Button>
          <Button variant="outline" className="w-full border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-white">Détecter Changements d'Usage du Sol</Button>
          <Button variant="outline" className="w-full border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-white">Identifier Zones Inondables</Button>
          <Select>
            <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white"><SelectValue placeholder="Choisir un indice (NDVI, NDWI...)" /></SelectTrigger>
            <SelectContent className="bg-slate-700 text-white">
              <SelectItem value="ndvi">NDVI (Végétation)</SelectItem>
              <SelectItem value="ndwi">NDWI (Eau)</SelectItem>
              <SelectItem value="ndbi">NDBI (Constructions)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </CardContent>
  </Card>
);


const SpatialAnalysisPage = () => {
  const { toast } = useToast();
  const [isLoadingSatScan, setIsLoadingSatScan] = useState(false);
  const [satScanResults, setSatScanResults] = useState(null);
  const [qualitativeText, setQualitativeText] = useState('');
  const [qualitativeAnalysisResults, setQualitativeAnalysisResults] = useState(null);
  const [isLoadingQualitative, setIsLoadingQualitative] = useState(false);

  const [satScanParams, setSatScanParams] = useState({
    analysisType: 'purely_spatial',
    scanAreas: 'high_rates',
    timePrecision: 'day',
    startDate: '',
    endDate: '',
    caseFile: null,
    populationFile: null,
    coordinatesFile: null,
  });
  
  const defaultPosition = [10.2667, 17.9167]; 
  const exampleHighRiskZone = [9.52, 18.38];


  const handleSatScanParamChange = (e) => {
    const { name, value, type, files } = e.target;
    setSatScanParams(prev => ({
      ...prev,
      [name]: type === 'file' ? files[0] : value
    }));
  };
  
  const handleSatScanSelectChange = (name, value) => {
     setSatScanParams(prev => ({ ...prev, [name]: value }));
  };

  const handleRunSatScan = (e) => {
    e.preventDefault();
    setIsLoadingSatScan(true);
    setSatScanResults(null);

    toast({
      title: "Analyse SatScan (Simulation)",
      description: "Lancement de l'analyse SatScan en cours... L'exécution réelle nécessite un backend.",
    });

    setTimeout(() => {
      setIsLoadingSatScan(false);
      setSatScanResults({
        clusters: [
          { id: 1, location: "Moundou (Logone Occidental)", pValue: 0.002, relativeRisk: 3.5, startDate: "2025-01-15", endDate: "2025-02-05", coordinates: [8.5833, 16.0667], radius: 30000, color: 'red', fillColor: '#ff3333' },
          { id: 2, location: "Sarh (Moyen-Chari)", pValue: 0.045, relativeRisk: 1.8, startDate: "2025-03-01", endDate: "2025-03-20", coordinates: [9.15, 18.3833], radius: 25000, color: 'orange', fillColor: '#ffaa33' },
        ],
        summary: "Deux clusters statistiquement significatifs détectés. Le cluster principal à Moundou présente un risque relatif élevé.",
      });
      toast({
        title: "Résultats SatScan (Simulation)",
        description: "L'analyse simulée est terminée.",
      });
    }, 3000);
  };

  const handleQualitativeAnalysis = () => {
    if (!qualitativeText.trim()) {
      toast({ title: "Texte manquant", description: "Veuillez saisir du texte pour l'analyse.", variant: "destructive" });
      return;
    }
    setIsLoadingQualitative(true);
    setQualitativeAnalysisResults(null);
    toast({
      title: "Analyse Qualitative (Simulation)",
      description: "Lancement de l'analyse textuelle... Ceci est une simulation.",
    });

    setTimeout(() => {
      setIsLoadingQualitative(false);
      setQualitativeAnalysisResults({
        wordCloudImage: "https://images.unsplash.com/photo-1600097489380-939fd5551680?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=60",
        keyThemes: ["Accès aux services", "Qualité des soins", "Information et sensibilisation", "Rumeurs et désinformation", "Rôle des leaders"],
        sentiment: { positive: 0.6, neutral: 0.25, negative: 0.15 },
        frequentWords: [
          { word: "vaccin", count: 25 }, { word: "enfants", count: 20 }, { word: "santé", count: 18 },
          { word: "communauté", count: 15 }, { word: "difficile", count: 12 }, { word: "information", count: 10 }
        ],
        verbatims: [
            "L'accès au centre de santé est vraiment difficile pendant la saison des pluies.",
            "Nous avons bien reçu l'information sur la campagne vaccinale, mais les horaires n'étaient pas pratiques.",
            "Les agents vaccinateurs étaient très professionnels et gentils avec les enfants."
        ],
        dendrogramImage: "https://images.unsplash.com/photo-1543286386-71314a0045I1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=60", 
      });
      toast({
        title: "Résultats Analyse Qualitative (Simulation)",
        description: "L'analyse textuelle simulée est terminée.",
      });
    }, 2500);
  };
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={fadeIn}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-cyan-500 to-sky-600">
        Analyses Avancées
      </h1>

      <Tabs defaultValue="cartographie" className="w-full">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-4 mb-6">
          <TabsTrigger value="cartographie">Cartographie</TabsTrigger>
          <TabsTrigger value="spatio_temporelle">Analyse Spatio-temporelle</TabsTrigger>
          <TabsTrigger value="donnees">Analyses de Données</TabsTrigger>
          <TabsTrigger value="teledetection">Télédétection</TabsTrigger>
        </TabsList>

        <TabsContent value="cartographie">
          <CartographieTab defaultPosition={defaultPosition} exampleHighRiskZone={exampleHighRiskZone} satScanResults={satScanResults} />
        </TabsContent>

        <TabsContent value="spatio_temporelle">
          <SatScanTab 
            satScanParams={satScanParams} 
            handleSatScanParamChange={handleSatScanParamChange} 
            handleSatScanSelectChange={handleSatScanSelectChange}
            handleRunSatScan={handleRunSatScan}
            isLoadingSatScan={isLoadingSatScan}
            satScanResults={satScanResults}
          />
        </TabsContent>

        <TabsContent value="donnees">
          <AnalyseQualitativeTab 
             qualitativeText={qualitativeText}
             setQualitativeText={setQualitativeText}
             handleQualitativeAnalysis={handleQualitativeAnalysis}
             isLoadingQualitative={isLoadingQualitative}
             qualitativeAnalysisResults={qualitativeAnalysisResults}
          />
        </TabsContent>

        <TabsContent value="teledetection">
          <TeledetectionTab />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default SpatialAnalysisPage;
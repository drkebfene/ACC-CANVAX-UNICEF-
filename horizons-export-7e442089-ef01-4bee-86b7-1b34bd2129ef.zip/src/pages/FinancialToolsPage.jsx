
import React, { useState, useEffect, useContext } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { UserContext, ROLES } from '@/contexts/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Edit, PlusCircle, Download, Printer, FileText as FileTextIcon, Loader2, Trash2, DollarSign } from 'lucide-react';
import FinancialReportACDForm from '@/components/forms/FinancialReportACDForm';
import BudgetPlanningForm from '@/components/forms/BudgetPlanningForm';

const FinancialToolsPage = () => {
  const { userRole, supabaseUser } = useContext(UserContext);
  const { toast } = useToast();

  const [financialReports, setFinancialReports] = useState([]);
  const [budgetPlans, setBudgetPlans] = useState([]);
  const [isLoadingReports, setIsLoadingReports] = useState(false);
  const [isLoadingPlans, setIsLoadingPlans] = useState(false);
  
  const [selectedItem, setSelectedItem] = useState(null);
  const [currentItemType, setCurrentItemType] = useState(null); // 'Report' or 'Plan'
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const fetchFinancialReports = async () => {
    setIsLoadingReports(true);
    try {
      const { data, error } = await supabase
        .from('financial_reports_acd')
        .select(`*, created_by_user:users!created_by_user_id(raw_user_meta_data->>'username')`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setFinancialReports(data.map(r => ({...r, created_by_username: r.created_by_user?.username || 'N/A' })));
    } catch (error) {
      toast({ title: "Erreur de chargement des rapports financiers", description: error.message, variant: "destructive" });
    } finally {
      setIsLoadingReports(false);
    }
  };

  const fetchBudgetPlans = async () => {
    setIsLoadingPlans(true);
    try {
      const { data, error } = await supabase
        .from('budget_plans_acd')
        .select(`*, created_by_user:users!created_by_user_id(raw_user_meta_data->>'username')`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setBudgetPlans(data.map(p => ({...p, created_by_username: p.created_by_user?.username || 'N/A' })));
    } catch (error) {
      toast({ title: "Erreur de chargement des plans budgétaires", description: error.message, variant: "destructive" });
    } finally {
      setIsLoadingPlans(false);
    }
  };

  useEffect(() => {
    if (supabaseUser) {
      fetchFinancialReports();
      fetchBudgetPlans();
    }
  }, [supabaseUser]);

  const handleCreateNew = (type) => {
    setCurrentItemType(type);
    setSelectedItem(null);
    setIsCreateModalOpen(true);
  };

  const handleView = (item, type) => {
    setSelectedItem(item);
    setCurrentItemType(type);
    setIsViewModalOpen(true);
  };

  const handleEdit = (item, type) => {
    setSelectedItem(item);
    setCurrentItemType(type);
    setIsEditModalOpen(true);
  };
  
  const handleDelete = async (itemId, type) => {
    if (!window.confirm(`Êtes-vous sûr de vouloir supprimer cet élément (${type}) ?`)) return;
    const table = type === 'Report' ? 'financial_reports_acd' : 'budget_plans_acd';
    try {
      const { error } = await supabase.from(table).delete().eq('id', itemId);
      if (error) throw error;
      toast({ title: "Suppression Réussie", description: `L'élément (${type}) a été supprimé.` });
      if (type === 'Report') fetchFinancialReports();
      else fetchBudgetPlans();
    } catch (error) {
      toast({ title: "Erreur de Suppression", description: error.message, variant: "destructive" });
    }
  };

  const handleFormSubmit = async (data) => {
    if (!supabaseUser) {
      toast({ title: "Erreur", description: "Utilisateur non connecté.", variant: "destructive" });
      return;
    }
    const table = currentItemType === 'Report' ? 'financial_reports_acd' : 'budget_plans_acd';
    const isUpdating = !!selectedItem?.id;

    const submissionData = { ...data, last_modified_by_user_id: supabaseUser.id };
    if (!isUpdating) {
      submissionData.created_by_user_id = supabaseUser.id;
    }

    try {
      let error;
      if (isUpdating) {
        ({ error } = await supabase.from(table).update(submissionData).eq('id', selectedItem.id));
      } else {
        ({ error } = await supabase.from(table).insert([submissionData]));
      }
      if (error) throw error;
      toast({ title: "Succès", description: `Élément (${currentItemType}) ${isUpdating ? 'mis à jour' : 'créé'} avec succès.` });
      setIsEditModalOpen(false);
      setIsCreateModalOpen(false);
      if (currentItemType === 'Report') fetchFinancialReports();
      else fetchBudgetPlans();
    } catch (err) {
      toast({ title: "Erreur de Soumission", description: err.message, variant: "destructive" });
    }
  };
  
  const handlePrint = () => {
    const printContents = document.getElementById('form-to-print-content')?.innerHTML;
    if(printContents) {
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = `<div class="printable-content p-4 bg-white text-black">${printContents}</div><style>@media print { body * { visibility: hidden; } .printable-content, .printable-content * { visibility: visible; color: black !important; background-color: white !important; } .printable-content { position: absolute; left: 0; top: 0; width: 100%; } .btn-group, .no-print { display: none !important; } }</style>`;
        window.print();
        document.body.innerHTML = originalContents;
        window.location.reload();
    } else {
        toast({title: "Erreur d'impression", description: "Contenu du formulaire non trouvé.", variant: "destructive"});
    }
  };

  const handleDownloadWord = (type) => {
    const fileName = type === 'Report' ? 'Rapport_Financier_ACD_Template.docx' : 'Plan_Budgetaire_ACD_Template.docx';
    // For now, using a generic placeholder as specific templates are not created yet.
    const filePath = `/ACD/documents/Feuille_de_Route_CS_Template.docx`; // Placeholder, replace with actual templates
    
    const link = document.createElement('a');
    link.href = filePath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({title: "Téléchargement Word (Modèle)", description: `Modèle ${fileName} téléchargé.`});
  };

  const handleDownloadExcelTemplate = () => {
    const filePath = '/ACD/documents/Budget_Suivi_Template.xlsx'; // Ensure this file exists
    const fileName = 'Budget_Suivi_Template.xlsx';
    
    const link = document.createElement('a');
    link.href = filePath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({title: "Téléchargement Modèle Excel", description: `Modèle ${fileName} téléchargé.`});
  };
  
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'Brouillon': return 'bg-gray-500';
      case 'Soumis': return 'bg-blue-500';
      case 'Validé': return 'bg-green-500';
      default: return 'bg-slate-500';
    }
  };

  const renderTable = (items, type, isLoading, title, caption, columns) => (
    <Card className="glassmorphism">
      <CardHeader className="flex flex-row justify-between items-center">
        <CardTitle className="text-xl text-purple-300">{title}</CardTitle>
        <Button onClick={() => handleCreateNew(type)} className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700">
          <PlusCircle className="mr-2 h-4 w-4" /> Créer Nouveau {type}
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" /><p className="text-purple-200 mt-2">Chargement...</p></div>
        ) : items.length === 0 ? (
          <p className="text-center py-8 text-purple-200">Aucun élément trouvé.</p>
        ) : (
          <Table>
            <TableCaption>{caption}</TableCaption>
            <TableHeader>
              <TableRow>
                {columns.map(col => <TableHead key={col.key} className="text-cyan-400">{col.label}</TableHead>)}
                <TableHead className="text-cyan-400">Statut</TableHead>
                <TableHead className="text-cyan-400">Créé par</TableHead>
                <TableHead className="text-cyan-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item) => (
                <TableRow key={item.id} className="text-sky-100">
                  {columns.map(col => <TableCell key={col.key}>{col.render ? col.render(item[col.key]) : item[col.key]}</TableCell>)}
                  <TableCell>
                    <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${getStatusBadgeColor(item.status)}`}>
                      {item.status}
                    </span>
                  </TableCell>
                  <TableCell>{item.created_by_username || 'N/A'}</TableCell>
                  <TableCell className="space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => handleView(item, type)} title="Voir"><Eye className="h-4 w-4 text-blue-400" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(item, type)} title="Modifier"><Edit className="h-4 w-4 text-yellow-400" /></Button>
                    {(userRole === ROLES.ADMIN || userRole === ROLES.MSP) && (
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id, type)} title="Supprimer"><Trash2 className="h-4 w-4 text-red-400" /></Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {type === 'Plan' && (
          <div className="mt-6 text-center">
            <Button onClick={handleDownloadExcelTemplate} variant="outline" className="border-purple-400 text-purple-300 hover:bg-purple-500 hover:text-white">
              <Download className="mr-2 h-4 w-4" /> Télécharger Modèle Excel Budget & Suivi
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
  
  const CurrentForm = currentItemType === 'Report' ? FinancialReportACDForm : BudgetPlanningForm;
  const reportColumns = [
    { key: 'province', label: 'Province' },
    { key: 'periode_couverte_debut', label: 'Début Période', render: (date) => new Date(date).toLocaleDateString() },
    { key: 'periode_couverte_fin', label: 'Fin Période', render: (date) => new Date(date).toLocaleDateString() },
  ];
  const planColumns = [
    { key: 'titre_plan', label: 'Titre du Plan' },
    { key: 'niveau_operationnel', label: 'Niveau' },
    { key: 'periode_debut', label: 'Début Période', render: (date) => date ? new Date(date).toLocaleDateString() : 'N/A' },
  ];


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-8"
    >
      <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-sky-600">
        <DollarSign className="inline-block h-10 w-10 mr-3" />Outils Financiers et Budgétaires ACD
      </h1>

      <Tabs defaultValue="reports" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="reports">Rapports Financiers</TabsTrigger>
          <TabsTrigger value="plans">Planification Budgétaire</TabsTrigger>
        </TabsList>
        <TabsContent value="reports">
          {renderTable(financialReports, 'Report', isLoadingReports, 'Rapports Financiers ACD', 'Liste des rapports financiers soumis.', reportColumns)}
        </TabsContent>
        <TabsContent value="plans">
          {renderTable(budgetPlans, 'Plan', isLoadingPlans, 'Plans Budgétaires ACD', 'Liste des plans budgétaires.', planColumns)}
        </TabsContent>
      </Tabs>

      {(isViewModalOpen || isEditModalOpen || isCreateModalOpen) && (
        <Dialog open={isViewModalOpen || isEditModalOpen || isCreateModalOpen} 
                onOpenChange={isEditModalOpen ? setIsEditModalOpen : (isCreateModalOpen ? setIsCreateModalOpen : setIsViewModalOpen)}>
          <DialogContent className="max-w-4xl h-[95vh] flex flex-col glassmorphism">
            <DialogHeader>
              <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                {isEditModalOpen ? 'Modifier' : (isCreateModalOpen ? 'Créer Nouveau' : 'Visualiser')} {currentItemType === 'Report' ? 'Rapport Financier' : 'Plan Budgétaire'}
              </DialogTitle>
            </DialogHeader>
            <div id="form-to-print-content" className="flex-grow overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-secondary">
              <CurrentForm 
                onSubmit={handleFormSubmit} 
                initialData={selectedItem} 
                readOnly={isViewModalOpen} 
              />
            </div>
            <DialogFooter className="mt-auto pt-4 border-t border-slate-700 flex-wrap justify-between sm:justify-end">
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline" onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Imprimer</Button>
                <Button variant="outline" onClick={() => handleDownloadWord(currentItemType)}><Download className="mr-2 h-4 w-4" /> Modèle Word</Button>
                <Button variant="outline" onClick={() => toast({title: "Bientôt disponible", description: "Le téléchargement PDF sera bientôt disponible."})}><Download className="mr-2 h-4 w-4" /> PDF (Bientôt)</Button>
              </div>
              <Button variant="secondary" onClick={() => isEditModalOpen ? setIsEditModalOpen(false) : (isCreateModalOpen ? setIsCreateModalOpen(false) : setIsViewModalOpen(false))}>
                {isViewModalOpen ? 'Fermer' : 'Annuler'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
};

export default FinancialToolsPage;